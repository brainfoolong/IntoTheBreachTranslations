
TILE_TOOLTIPS = {
	fire = {"Tuile Feu", "Enflamme les unit�s."},
	forest = {"Tuile For�t", "Si endommag�, la for�t s'enflamme."},
	forest_fire = {"For�t Enflamm�e", "Enflamme les unit�s. Cet incendie a �t� d�clench� lorsqu'un Tuile For�t a �t� endommag�e."},
	smoke = {"Tuile Fum�e", "Les unit�s dans la Fum�e ne peuvent pas attaquer ou r�parer."},
	electric_smoke = {"Fum�e �lectrique", "Les unit�s dans la Fum�e ne peuvent pas attaquer ou r�parer. \nL'�lectricit� endommage les unit�s ennemies."},
	emerging = { "Vek �mergeant", "Ennemi �mergeant au prochain tour. Peut �tre bloqu�."},
	critical = { "Critique", "Ce b�timent est important pour les objectifs de la mission." },
	pylon = { "Pyl�ne �lectrique", "Les Pyl�nes de Puissance � Distance connectent vos Mechs � la Grille m�me sous terre. Non peupl�e."},
	supervolcano = { "Super Volcan", "Volcan indestructible qui bloque les mouvements et les projectiles."},
	powered = { "B�timent Civil", "Votre R�seau �lectrique est r�duit lorsque les R�seaux Structures sont endommag�s." },
	evacuated = { "B�timent �vacu�", "Aucun effet quand il subit des d�g�ts." },
	building_rubble = { "D�bris de B�timent", "Aucun effet sp�cifique." },
	mnt_rubble = {"D�bris de Montagne", "Aucun effet sp�cifique." },
	ice = {"Tuile Glac�e", "Se transforme en Eau lorsqu'elle est d�truite. Doit �tre frapp� deux fois."},
	acid_ice = {"Glace A.C.I.D", "Se transforme en Tuile A.C.I.D. lorsqu'elle est d�truite, mais est actuellement hors de danger."},
	lava_ice = {"Lave Glac�e", "Se transforme en Tuile Lave lorsqu'elle est d�truite, mais est actuellement hors de danger."},
	damaged_ice = {"Tuile Glac�e Endommag�e", "Se transforme en Tuile Eau lorsqu'elle est d�truite. Un coup la d�truira."},
	chasm = {"Tuile Gouffre", "Les unit�s terrestres pouss�es seront \nd�truites."},
	ground = { "Tuile Sol", "Aucun effet sp�cifique."},
	sand = { "Tuile Sable", "Si endommag�, se transforme en Fum�e. \nLes unit�s dans la Fum�e ne peuvent pas attaquer ou r�parer." },
	mountain = { "Tuile Montagne", "Bloque les mouvements et les projectiles. Infliger des d�g�ts deux fois pour la d�truire." },
	damaged_mountain = { "Montagne Endommag�e", "Bloque les mouvements et les projectiles. Un coup la d�truira." },
	water = { "Tuile Eau", "Les unit�s ne peuvent pas attaquer dans l'Eau. La plupart des ennemis Non-Volants meurent dans l'Eau."},
	acid_water = { "Tuile A.C.I.D.", "Se comporte comme de l'Eau, mais inflige de l'A.C.I.D. aux unit�s survivantes."},
	lava = {"Tuile Lave", "Se comporte comme de l'Eau, mais inflige du Feu aux unit�s survivantes."},
	acid = { "Bassin A.C.I.D.", "Inflige A.C.I.D. sur la 1�re unit� qui marche � cet endroit."},
	frozen_acid = { "A.C.I.D. Gel�", "Les temp�ratures basses ont rendu l'A.C.I.D. inerte sur cette tuile."},
	pod = {"Pod Temporel", "D�truit si endommag� ou pi�tin� par l'ennemi. Collecter avec un Mech, ou d�fendre jusqu'� la retraite des Veks."},
	ftl_pod = {"Pod �trange", "D�truit si endommag� ou pi�tin� par l'ennemi. Collecter avec un Mech, ou d�fendre jusqu'� la retraite des Veks."},
	ftl_button = {"Objet �trange", "Vous n'�tes pas s�r de ce que cela pourrait �tre."},
	ftl_button_destroyed = {"Objet D�truit", "Vous n'�tes pas s�r de ce que c'�tait, mais c'est parti � pr�sent."},
	frozen_powered = { "B�timent Gel�", "Invincible lorsqu'il est Gel�. Tout d�g�t d�truira la glace." },
	spawning = {"�mergent", "Un Vek va �merger ici au prochain tour. Toute unit� bloquant cet endroit subira un d�g�t."},
	high_tide = {"Tuile Haute","Cette tuile deviendra de l'Eau au d�but du tour ennemi."},
	air_strike = {"Frappe A�rienne", "Des bombes seront largu�es ici, tuant instantan�ment n'importe quelle unit�."},
	old_earth_mine = {"Mine Ancienne Terre", "Toute unit� qui s'arr�te sur cet endroit d�clenchera la mine et sera tu�e."},
	freeze_mine = {"Mine Gel�e", "Toute unit� qui s'arr�te sur cet endroit sera Gel�e."},
	evacuation = {"�vacuation", "Ce b�timent sera �vacu� \nau prochain tour."},
	seismic = {"Activit� Sismique", "Cette tuile deviendra un Gouffre au d�but du tour ennemi."},
	lightning = {"Coup Foudroyant", "La foudre frappera ici, tuant n'importe quelle unit�."},
	falling_rock = {"Chute de Pierre", "Un rocher tombera ici, tuant n'importe quelle unit�."},
	tentacle_lava = {"Tentacules", "Cette unit� mourra et la tuile se transformera en Lava."},
	volcano_lava = {"Coul�e de Lave", "Cette tuile va se transformer en lave."},
	flying_rock = {"Projectile Volcanique", "Une boule de feu frappera ici, d�truisant tout ce qui est pr�sent."},
	ice_storm = {"Temp�te Glac�e", "La temp�te va Geler tout chose pr�sente."},
	grassland = {"Prairie", "Votre objectif bonus est de Terraformer les tuiles Prairie en Sable."},
	terraformed = {"Terraform�", "Cette tuile a �t� terraform�e dans le cadre de votre objectif bonus."},
	stasis = {"Robot Stase", "Ce robot va s'alimenter et prendre part au combat si son Bouclier est endommag�."},
	
	belt = {"Scarab�e Convoyeur", "Cette tuile va pousser n'importe quelle unit� dans la direction indiqu�e par le Scarab�e."},
	
	tele = {"Dalle T�l�port", "En s'arr�tant sur cette dalle, vous serez T�l�port� � la dalle correspondante. Toutes unit�s pr�sentent seront interverties."},
	
	supply_drop = { "Caisse Fourniture", "Collecter ceci avec un Mech pour soigner TOUTES les unit�s amies et restaurer TOUTES les Armes � Usage Limit�." },	
}

local STATUS_TOOLTIPS = {
	flying = {"Volant", "Les Unit�s Volantes peuvent se d�placer sur n'importe quelle tuile de terrain."},
	hp = {"Spores Vivifiants", "Le Soldat Psion fournit +1 HP � tous les Veks."},
	burrow = {"Enfouisseur", "Ce Vek se cachera sous terre apr�s avoir subi un ou plusieurs d�g�ts."},
	psionboss = { "Surcharge", "L'Abomination Psion am�liore tous les Veks. Ils gagnent +1 HP, r�g�n�ration, et explosent � leur mort."},
	tentacle = { "Ruche Cibl�e", "Le Tyran Psion fera 1 de d�g�t � toutes les unit�s alli�es � chaque tour."},
	armor_leader = {"Carapace Durcie", "Le Carapace Psion fournit de l'Armure � tous les Veks, r�duisant les d�g�ts des armes inflig�s de 1. Tous les autres d�g�ts (Pousser, Bloquer, Tir, etc.) ne sont pas affect�s."},
	armor = {"Armure Naturelle", "Les D�g�ts d'Arme sur cette unit� sont r�duits de 1. Tous les autres d�g�ts (Pousser, Bloquer, Feu, etc...) ne sont pas affect�s."},
	armor_degraded = {"Armure D�grad�e", "A.C.I.D. annule actuellement les effets d'Armure de cette unit�."},
	regen = {"R�g�n�ration", "Le Sang Psion gu�rit tous les Veks de 1 point � chaque tour."},
	explode_leader = {"Explosion D�sint�grante", "Le Souffle Psion fera exploser tous les Veks en infligeant de 1 d�g�t aux tuiles adjacentes."},
	explode = {"Explosion D�sint�grante", "Explose en mourant, infligeant 1 de d�g�t aux tuiles adjacentes."}, --was Innate Explosions
	arrow_0 = {"Scarab�e Convoyeur", "Cette unit� sera pouss�e par le Scarab�e Convoyeur dans la direction indiqu�e."},
	arrow_1 = {"Scarab�e Convoyeur", "Cette unit� sera pouss�e par le Scarab�e Convoyeur dans la direction indiqu�e."},
	arrow_2 = {"Scarab�e Convoyeur", "Cette unit� sera pouss�e par le Scarab�e Convoyeur dans la direction indiqu�e."},
	arrow_3 = {"Scarab�e Convoyeur", "Cette unit� sera pouss�e par le Scarab�e Convoyeur dans la direction indiqu�e."},
	tele_A = {"Dalle T�l�port", "Si une autre unit� utilise la dalle de t�l�portation ROUGE, cette unit� permutera de positions avec elle."},
	tele_B = {"Dalle T�l�port", "Si une autre unit� utilise la dalle de t�l�portation BLEU, cette unit� permutera de positions avec elle."},
	moving = {"Bonus D�placement", "+2 de D�placement pour UN tour."},
	grapple = {"Entrav�", "Les unit�s Entrav�s par les Veks ne peuvent pas bouger, mais elles peuvent toujours attaquer."},
	poweroff = {"Non Aliment�", "Les unit�s sans Puissance sont inactives et ne peuvent pas bouger ou attaquer."},
	massive = {"Massif", "Les unit�s massives peuvent marcher dans l'Eau (mais l'Eau emp�chera le tir)."},
	water = {"Submerg�", "Les armes ne fonctionnent pas lorsqu'elles sont submerg�es dans l'Eau."},
	acid_water = { "Submerg� dans l'A.C.I.D.", "Les Armes ne fonctionnent pas et le Mech submerg� est affect� par de l'A.C.I.D."},
	lava = { "Submerg� dans la Lave", "Les Armes ne fonctionnent pas et le Mech submerg� est en feu."},
	fire = {"Feu", "Les unit�s en feu subissent 1 de d�g�t au d�but de chaque tour."},
	forest = {"Sur la For�t", "La tuile va s'enflammer si elle subit des d�g�ts, repr�sentant un grand risque pour cette unit�."},
	sand = {"Sur le Sable", "La tuile se transforme en Fum�e si elle subit des d�g�ts, emp�chant cette unit� d'attaquer."},
	ice = {"Sur la Glace", "Si une tuile de Glace subit des d�g�ts deux fois, elle se transformera en Eau."},
	icecrack = {"Sur la Glace Endommag�e", "La Glace Endommag�e se transformera en Eau si elle subit � nouveau des d�g�ts."},
	acid = {"A.C.I.D. Corrosif", "Les d�g�ts des Armes contre cette unit� sont doubl�s. Tous les autres d�g�ts (Pousser, Bloquer, Feu, etc...) ne sont pas affect�s."},
	spawnblock = {"Bloqu� Apparition", "La nouvelle unit� ennemie ne va pas appara�tre ici, mais cette unit� subira 1 de d�g�t."},
	smoke = {"Fum�", "Les unit�s dans la Fum�e ne peuvent pas attaquer ou r�parer."},
	electric_smoke = {"Fum�e �lectrique", "Les unit�s dans la Fum�e ne peuvent pas attaquer ou r�parer. L'�lectricit� endommage les unit�s ennemies."},
	shield = {"Bouclier �nerg�tique", "Les Boucliers bloquent les d�g�ts et tous les effets n�gatifs (Feu, Cong�lation, A.C.I.D, etc...). Seuls les d�g�ts directs enl�veront le Bouclier."},
	zoltan_shield = {"Bouclier Zoltan", "Identique � un Bouclier normal, mais se r�g�n�re au d�but de chaque tour"},
	guard = {"Stable", "Ne peut �tre d�plac� par aucun effet d'Arme (Pousser, T�l�porter, etc...)."},
	frozen = {"Gel�", "Invincible mais incapable de bouger ou d'attaquer. Tout d�g�t lib�rera l'unit�."},
	kickoff = {"Pieds Boost�s", "+2 de D�placement ce tour."},
	shifty = {"�viter", "(Comp�tence Pilote) Cette unit� obtient un bonus de D�placement de Tuile apr�s avoir attaqu�."},
	youthful = {"Impulsif", "Cette unit� gagne +3 de D�placement au premier tour de chaque mission."},
	doubleshot = {"Coup Double", "(Comp�tence Pilote) Cette unit� obtient une action bonus car elle n'a pas boug�."}, 
	postmove = {"Tir et Oubli", "(Comp�tence Pilote) Cette unit� peut bouger apr�s avoir attaqu�."},
	fire_immune = {"Immunit� au Feu", "Cette unit� ne peut pas �tre en Feu"},
	smoke_immune = {"Immunit� � la Fum�e", "Cette unit� n'est pas affect�e par la Fum�e"},
	shield_heal = {"Auto-R�paration", "Si elle subit des d�g�ts, cette unit� s'appliquera un Bouclier et se pr�pare � Soigner."},
	danger = {"Danger Environnemental", "L'effet de l'Environnement affectera cet endroit au prochain tour"},
	purple = {"Unit� Alpha", "Les Unit�s Alpha sont plus puissantes que leurs homologues standard"},
	boss = {"Chef Ruche", "Ce sont les Veks les plus puissants. Immunis� � l'Eau, ils peuvent �tre plus difficiles � tuer."},

}

local PilotSkills = {
	Disable_Immunity = PilotSkill("Evasion","Mech unaffected by Webbing and Smoke."),
	Extra_XP = PilotSkill("Experienced","Gain +2 bonus XP\nper kill."),
	Self_Shield = PilotSkill("Starting Shield","Mech starts every mission with a Shield."),
	Road_Runner = PilotSkill("Maneuverable","Mech can move through enemy units."),
	Shifty = PilotSkill("�viter","After attacking, gain 1 free tile movement."),
	Deploy_Anywhere = PilotSkill("Preemptive Strike", "Deploy anywhere on the map, damaging adjacent enemies."),
	Survive_Death = PilotSkill("Vek", "Normal Pilots cannot be equipped. Loses 25 XP when the unit is disabled."),
	Pain_Immunity = PilotSkill("Cauterize", "Fire heals instead of damaging Mech."),
	Power_Repair = PilotSkill("Frenzied Repair", "Push adjacent tiles when repairing."),
	Freeze_Walk = PilotSkill("Frozen Stance", "Stopping on any liquid tile freezes it, making it safe to stand on."),
	Armored = PilotSkill("Armored", "Mech gains Armored."),
	Flying = PilotSkill("Volant", "Mech gains Flying."),
	Double_Shot = PilotSkill("Coup Double", "Mech can act twice if it does not move."),
	Post_Move = PilotSkill("Tir et Oubli", "Move again after shooting."),
	Youth_Move = PilotSkill("Impulsif", "Gain +3 Move on first turn of every mission."),
	Retaliation = PilotSkill("Retaliation", "Deal 1 damage to adjacent enemies after surviving damage."),
	TimeTravel = PilotSkill("Temporal Reset", "Gain 1 extra 'Reset Turn' every battle."),
	Mantis_Skill = PilotSkill("Mantis", "2 damage melee attack replaces Repair."),
	Rock_Skill = PilotSkill("Rockman", "+3 Health and\nImmune to Fire."),
	Zoltan_Skill = PilotSkill("Zoltan", "+1 Reactor Core.\nReduce Mech HP to 1.\nGain Shield every turn."),
}

function GetSkillInfo(skill)
	if skill == "" then return PilotSkill() end
	return PilotSkills[skill]
end

function GetTileTooltip(id)
	if TILE_TOOLTIPS[id] ~= nil then
		return TILE_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end

function GetStatusTooltip(id)
	if STATUS_TOOLTIPS[id] ~= nil then
		return STATUS_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end