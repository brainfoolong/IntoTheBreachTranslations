
TILE_TOOLTIPS = {
    fire = {"Feuer", "Steckt Einheiten in Brand."},
    forest = {"Wald", "Wenn es besch�digt wird, brennt es."},
    forest_fire = {"Waldbrand", "Setzt Einheiten in Brand. Dieses Feuer wurde durch einen besch�digten Wald entfacht."},
    smoke = {"Rauch", "Einheiten in Rauch k�nnen weder angreifen noch reparieren."},
    electric_smoke = {"Elektrischer Rauch", "Einheiten in Rauch k�nnen weder angreifen noch reparieren. \nElektrizit�t besch�digt gegnerische Einheiten."},
    emerging = {"Vek treffen ein", "Feind erscheint im n�chste Zug. Kann blockiert werden."},
    critical = {"Kritisch", "Dieses Geb�ude ist wichtig f�r Missionsziele."},
    pylon = {"Energie Pylon", "Entfernter Energie Pylon verbindet Mechs auch unterirdisch mit dem Netz. Nicht besiedelt."},
    supervolcano = {"Super Vulkan", "Unzerst�rbarer Vulkan, der Bewegung und Projektile blockiert."},
    powered = {"Zivilgeb�ude", "Das Stromnetz wird reduziert, wenn Strukturen besch�digt werden."},
    evacuated = {"Evakuiertes Geb�ude", "Keine Wirkung bei Besch�digung."},
    building_rubble = {"Bauschutt", "Kein besonderer Effekt."},
    mnt_rubble = {"Bergschutt", "Kein besonderer Effekt."},
    ice = {"Eis", "Wird bei Zerst�rung in Wasser verwandelt. Muss zweimal getroffen werden."},
    acid_ice = {"S�ureeis", "Verwandelt sich in ein S�urefeld wenn es zerst�rt, zurzeit aber sicher zum stehen."},
    lava_ice = {"Gefrorene Lava", "Wird bei der Zerst�rung zu Lava, aber momentan ist es sicher."},
    damaged_ice = {"Besch�digtes Eis", "Verwandelt sich in Wasser, wenn es zerst�rt wird. Ein Treffer wird es zerst�ren."},
    chasm = {"Abgrund", "Einheiten die darauf geschoben werden\nwerden zerst�rt."},
    ground = {"Boden", "Kein besonderer Effekt."},
    sand = {"Sand", "Wenn es besch�digt wird, wird es zu Rauch. \nEinheiten in Smoke k�nnen weder angreifen noch reparieren."},
    mountain = {"Berg", "Blockiert Bewegung und Geschosse. Besch�dige es zweimal, um es zu zerst�ren."},
    damaged_mountain = {"Besch�digter Berg", "Blockiert Bewegung und Geschosse. Ein Treffer wird es zerst�ren."},
    water = {"Wasser", "Einheiten k�nnen nicht in Wasser angreifen. Die meisten nicht fliegenden Feinde sterben in Wasser."},
    acid_water = {"S�ure", "Benimmt sich wie Wasser, aber verursacht S�ureschaden auf �berlebenden Einheiten."},
    lava = {"Lava", "Benimmt sich wie Wasser, verbrennt aber �berlebende Einheiten."},
    acid = {"S�urebad", "Verursacht S�ure auf der 1. Einheit, die auf diesen Raum tritt."},
    frozen_acid = {"Gefrorene S�ure", "Niedrige Temperaturen haben die S�ure gefrieren lassen."},
    pod = {"Zeitkapsel", "Zerst�rt, wenn sie vom Feind besch�digt oder zertrampelt wird. Sammle mit einem Mech oder verteidige es bis zum R�ckzug von Vek."},
    ftl_pod = {"Merkw�rdiger Pod", "Zerst�rt, wenn sie vom Feind besch�digt oder zertrampelt wird. Sammle mit einem Mech oder verteidige es bis zum R�ckzug von Vek."},
    ftl_button = {"Seltsames Objekt", "Du bist dir nicht sicher, was das sein k�nnte."},
    ftl_button_destroyed = {"Zerst�rtes Objekt", "Du bist dir nicht sicher, was das war, aber es ist jetzt weg."},
    frozen_powered = {"Gefrorenes Geb�ude", "Unbesiegbar wenn eingefroren. Jeder Schaden wird das Eis zerst�ren."},
    spawning = {"Eintreffend", "Vek wird hier im n�chsten Zug eintreffen. Jede Einheit, die diesen Raum blockiert, erh�lt einen Schaden."},
    high_tide = {"Flut", "Dieses Feld wird zu Beginn der gegnerischen Runde zu Wasser."},
    air_strike = {"Luftangriff", "Bomben werden hier abgeworfen und t�ten sofort jede Einheit."},
    old_earth_mine = {"Alte Erdmine", "Jede Einheit, die auf diesem Feld stoppt, wird die Mine ausl�sen und get�tet werden."},
    freeze_mine = {"Mine einfrieren", "Jede Einheit, die auf diesem Feld stoppt, wird eingefroren."},
    evacuation = {"Evakuieren", "Dieses Geb�ude wird evakuiert\nim n�chsten Zug."},
    seismic = {"Seismische Aktivit�t", "Dieses Feld wird zu Beginn des gegnerischen Spielzuges ein Abgrund."},
    lightning = {"Blitzschlag", "Ein Blitz wird hier zuschlagen und jede Einheit t�ten."},
    falling_rock = {"Fallender Stein", "Ein Stein wird hier fallen und jede Einheit t�ten."},
    tentacle_lava = {"Tentakeln", "Die Einheit wird sterben und das Feld wird zu Lava."},
    volcano_lava = {"Lavastrom", "Das Feld hier wird zu Lava."},
    flying_rock = {"Vulkanisches Projektil", "Ein Feuerball wird hier einschlagen und alles zerst�ren."},
    ice_storm = {"Eissturm", "Der Sturm bewirkt, dass alles eingefroren wird."},
    grassland = {"Wiese", "Ihr Bonusziel ist es, Gras in Sand zu verwandeln."},
    terraformed = {"Terraformiert", "Das Feld wurde als Teil deines Bonusziels terraformiert."},
    stasis = {"Stasis Bot", "Dieser Bot wird hochgefahren und tritt in den Kampf ein, wenn sein Schild besch�digt ist."},
	
    belt = {"F�rderband", "Dieses Feld dr�ckt jede Einheit in die Richtung, die auf dem Band markiert ist."},
	
    tele = {"Teleporter-Pad", "Beenden die Bewegung hier, um sich zum passenden Pad zu teleportieren. Tauscht Platz mit anderer Einheit."},
	
    supply_drop = {"Nachschub", "Sammle das mit einem Mech, um ALLE deine Einheiten zu heilen und ALLE Waffen mit begrenzter Nutzung wiederherzustellen."},
}

local STATUS_TOOLTIPS = {
    flying = {"Fliegt", "Fliegende Einheiten k�nnen sich �ber jedes Feld bewegen."},
    hp = {"Belebende Sporen", "Der Soldat Psion liefert allen Vek +1 HP."},
    burrow = {"Gr�ber", "Dieser Vek wird sich nach einem oder mehreren Besch�digungen im Untergrund verstecken."},
    psionboss = {"�berlastet", "Die Psion Abomination verbessert alle Vek. Sie gewinnen +1 HP, Regeneration und explodieren beim Tod."},
    tentacle = {"Vom Hive erfasst", "Der Psion Tyrant f�gt allen verb�ndeten Einheiten in jedem Zug 1 Schaden zu."},
    armor_leader = {"Geh�rteter Panzer", "Der Psion versorgt alle Vek mit R�stung, wodurch der Schaden ankommender Waffen um 1 verringert wird. Alle anderen Sch�den (Sto�, Blockieren, Feuer usw.) bleiben davon unber�hrt."},
    armor = {"Nat�rliche R�stung", "Waffenschaden f�r diese Einheit wird um 1 verringert. Alle anderen Sch�den (Sto�en, Blockieren, Feuer usw.) sind davon nicht betroffen."},
    armor_degraded = {"Herabgesetzte R�stung", "S�ure deaktiviert momentan die Effekte von R�stung auf dieser Einheit."},
    regen = {"Regeneration", "Der Blutpsion heilt alle Vek 1 Punkt in jedem Zug."},
    explode_leader = {"Explosiver Zerfall", "Der Explosions-Psion wird alle Vek beim Tod zum Explodieren bringen und den benachbarten Feldern 1 Schaden zuf�gen."},
    explode = {"Explosiver Zerfall", "Explodiert beim Tod und f�gt benachbarten Feldern 1 Schadenspunkt zu."},
    arrow_0 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
    arrow_1 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
    arrow_2 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
    arrow_3 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
    tele_A = {"Teleporter-Pad", "Wenn eine andere Einheit das ROTE-Teleport-Pad verwendet, tauscht diese Einheit die Positionen mit ihr aus."},
    tele_B = {"Teleporter-Pad", "Wenn eine andere Einheit das BLAUE-Teleport-Pad verwendet, tauscht diese Einheit die Positionen mit ihr aus."},
    moving = {"Bonus verschieben", "+2 Bewegung f�r einen Zug."},
    grapple = {"Festgebunden", "Einheiten, die von Vek festgebunden wurden, k�nnen sich nicht bewegen, aber sie k�nnen trotzdem angreifen."},
    poweroff = {"Nicht angetrieben", "Einheiten ohne Energie sind inaktiv und k�nnen sich nicht bewegen oder angreifen."},
    massive = {"Massiv", "Massive Einheiten k�nnen in Wasser laufen (aber Wasser verhindert das Schie�en)."},
    water = {"Versenkt", "Waffen funktionieren nicht, wenn sie in Wasser getaucht sind."},
    acid_water = {"Eingetaucht in S�ure", "Waffen funktionieren nicht und der untergetauchte Mech wird mit S�ure"},
    lava = {"In Lava eingetaucht", "Waffen funktionieren nicht und der untergetauchte Mech ist in Flammen."},
    fire = {"Feuer", "Einheiten in Feuer erleiden zu Beginn jeder Runde 1 Schaden."},
    forest = {"Auf Wald", "Feld brennt bei Kontakt mit Feuer und stellt ein gro�es Risiko f�r diese Einheit dar."},
    sand = {"Auf Sand", "Das Feld wird bei einem Schaden in Rauch verwandelt und verhindert, dass diese Einheit angreift."},
    ice = {"Auf Eis", "Wenn ein Feld zweimal Schaden nimmt, wird es zu Wasser."},
    icecrack = {"Auf besch�digtem Eis", "Besch�digtes Eis wird wieder Wasser, wenn es wieder besch�digt wird."},
    acid = {"Korrodierende S�ure.", "Waffenschaden gegen diese Einheit wird verdoppelt. Alle anderen Sch�den (Sto�, Blockieren, Feuer usw.) sind nicht betroffen."},
    spawnblock = {"Spawn blockieren", "Die neue feindliche Einheit wird hier nicht erscheinen, aber diese Einheit wird 1 Schaden erleiden."},
    smoke = {"Rauch", "Einheiten in Rauch k�nnen weder angreifen noch reparieren."},
    electric_smoke = {"Elektrischer Rauch", "Einheiten in Rauch k�nnen weder angreifen noch reparieren. Elektrizit�t besch�digt gegnerische Einheiten."},
    shield = {"Energieschild", "Schilde blockieren den Schaden und alle negativen Effekte (Feuer, Frieren, S�ure, etc.). Nur direkter Schaden wird den Schild entfernen."},
    zoltan_shield = {"Zoltan Schild", "Wie ein normaler Schild, regeneriert sich jedoch zu Beginn von jedem Zug"},
    guard = {"Stabil", "Kann nicht durch einen Waffeneffekt bewegt werden (Sto�, Teleport, etc.)."},
    frozen = {"Gefroren", "Unbesiegbar, aber unf�hig sich zu bewegen oder anzugreifen. Jeder Schaden befreit die Einheit."},
    kickoff = {"Kickoff-Booster", "+2 Bewegungen in diesem Zug."},
    shifty = {"Sidestep", "(Pilot Skill) Diese Einheit erh�lt nach dem Angreifen eine zus�tzliche Bewegung."},
    youthful = {"Treibend", "Diese Einheit erh�lt im ersten Zug jeder Mission +3 Bewegung."},
    doubleshot = {"Doppelschuss", "(Pilot Skill) Diese Einheit erh�lt eine Bonusaktion, weil sie sich nicht bewegt hat."},
    postmove = {"Schie�en und vergessen", "(Pilot Skill) Diese Einheit kann sich nach dem Schie�en bewegen."},
    fire_immune = {"Feuer Immunit�t", "Diese Einheit kann nicht auf Feuer gesetzt werden"},
    smoke_immune = {"Rauch-Immunit�t", "Einheit ist gegen Rauch immun"},
    shield_heal = {"Selbstreparierend", "Bei einer Besch�digung schirmt sich diese Einheit ab und bereitet sich auf Heilung vor."},
    danger = {"Umwelt Gefahr", "Der Umgebungseffekt beeinflusst diesen Raum in der n�chsten Runde"},
    purple = {"Alpha-Einheit", "Alpha-Einheiten sind m�chtiger als ihre Standardgegenst�cke"},
    boss = {"Schwarmf�hrer", "Dies sind die m�chtigsten Vek. Sie sind immun gegen Wasser und k�nnen schwieriger zu t�ten sein."},

}

local PilotSkills = {
    Disable_Immunity = PilotSkill("Ausweichen", "Mech unbeeinflusst von Festbinden und Rauch."),
    Extra_XP = PilotSkill("Erfahren", "Erhalte +2 Bonus XP \nper Kill."),
    Self_Shield = PilotSkill("Startschild", "Mech startet jede Mission mit einem Schild."),
    Road_Runner = PilotSkill("Wendig", "Mech kann sich durch gegnerische Einheiten bewegen."),
    Shifty = PilotSkill("Sidestep", "Nach dem Angriff erh�ltst du 1 freie Bewegung."),
    Deploy_Anywhere = PilotSkill("Pr�ventivschlag", "Stelle es irgendwo auf der Karte auf und sch�dige benachbarte Gegner."),
    Survive_Death = PilotSkill("Vek", "Normale Piloten k�nnen nicht ausger�stet werden. Verliert 25 XP, wenn die Einheit deaktiviert ist."),
    Pain_Immunity = PilotSkill("Kauterisieren", "Feuer heilt, anstatt Mech zu sch�digen."),
    Power_Repair = PilotSkill("Rasende Reparatur", "Sto�e benachbarte Felder w�hrend der Reparatur."),
    Freeze_Walk = PilotSkill("Frierender Stand", "Stoppen auf irgendeinem fl�ssigen Feld gefriert es, macht es sicher darauf zu stehen."),
    Armored = PilotSkill("Gepanzert", "Mech erhalten R�stung."),
    Flying = PilotSkill("Fliegt", "Mech erh�lt Fliegen."),
    Double_Shot = PilotSkill("Doppelschuss", "Mech kann zweimal handeln, wenn er sich nicht bewegt."),
    Post_Move = PilotSkill("Schie�en und vergessen", "Bewege dich nach dem Schie�en erneut."),
    Youth_Move = PilotSkill("Treibend", "Erhalte +3 Bewegung im ersten Zug jeder Mission."),
    Retaliation = PilotSkill("Vergeltung", "F�gt benachbarten Gegnern 1 Schadenspunkt zu, nachdem sie Schaden �berstanden haben."),
    TimeTravel = PilotSkill("Tempor�rer Reset", "Erhalte 1 zus�tzlichen 'Reset Zug' f�r jede Schlacht."),
    Mantis_Skill = PilotSkill("Gottesanbeterin", "2 Schaden Nahkampfangriff ersetzt Reparatur."),
    Rock_Skill = PilotSkill("Rockman", "+3 Gesundheit und \nImmun gegen Feuer."),
    Zoltan_Skill = PilotSkill("Zoltan", "+1 Reaktorkern. Verringert Mech HP um 1. \nErhalte Schild in jedem Zug."),
}

function GetSkillInfo(skill)
	if skill == "" then return PilotSkill() end
	return PilotSkills[skill]
end

function GetTileTooltip(id)
	if TILE_TOOLTIPS[id] ~= nil then
		return TILE_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end

function GetStatusTooltip(id)
	if STATUS_TOOLTIPS[id] ~= nil then
		return STATUS_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end