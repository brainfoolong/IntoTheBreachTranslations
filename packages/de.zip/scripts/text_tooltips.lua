
TILE_TOOLTIPS = {
    fire = {"", ""},
    forest = {"", ""},
    forest_fire = {"", ""},
    smoke = {"", ""},
    electric_smoke = {"", ""},
    emerging = {"", ""},
    critical = {"", ""},
    pylon = {"", ""},
    supervolcano = {"", ""},
    powered = {"", ""},
    evacuated = {"", ""},
    building_rubble = {"", ""},
    mnt_rubble = {"", ""},
    ice = {"", ""},
    acid = {"", ""},
    lava = {"", ""},
    damaged_ice = {"", ""},
    chasm = {"", ""},
    ground = {"", ""},
    sand = {"", ""},
    mountain = {"", ""},
    damaged_mountain = {"", ""},
    water = {"", ""},
    acid = {"", ""},
    lava = {"", ""},
    acid = {"", ""},
    frozen_acid = {"", ""},
    pod = {"", ""},
    ftl_pod = {"", ""},
    ftl_button = {"", ""},
    ftl_button_destroyed = {"", ""},
    frozen_powered = {"", ""},
    spawning = {"", ""},
    high_tide = {"", ""},
    air_strike = {"", ""},
    old_earth_mine = {"", ""},
    freeze_mine = {"", ""},
    evacuation = {"", ""},
    seismic = {"", ""},
    lightning = {"", ""},
    falling_rock = {"", ""},
    tentacle_lava = {"", ""},
    volcano_lava = {"", ""},
    flying_rock = {"", ""},
    ice = {"", ""},
    grassland = {"", ""},
    terraformed = {"", ""},
    stasis = {"", ""},

    belt = {"", ""},

    tele = {"", ""},

    supply_drop = {"", ""},
}

local STATUS_TOOLTIPS = {
    flying = {"", ""},
    hp = {"", ""},
    burrow = {"", ""},
    psionboss = {"", ""},
    tentacle = {"", ""},
    armor_leader = {"", ""},
    armor = {"", ""},
    armor_degraded = {"", ""},
    regen = {"", ""},
    explode = {"", ""},
    explode = {"", ""},
    arrow_0 = {"", ""},
    arrow_1 = {"", ""},
    arrow_2 = {"", ""},
    arrow_3 = {"", ""},
    tele_A = {"", ""},
    tele_B = {"", ""},
    moving = {"", ""},
    grapple = {"", ""},
    poweroff = {"", ""},
    massive = {"", ""},
    water = {"", ""},
    acid = {"", ""},
    lava = {"", ""},
    fire = {"", ""},
    forest = {"", ""},
    sand = {"", ""},
    ice = {"", ""},
    icecrack = {"", ""},
    acid = {"", ""},
    spawnblock = {"", ""},
    smoke = {"", ""},
    electric_smoke = {"", ""},
    shield = {"", ""},
    zoltan_shield = {"", ""},
    guard = {"", ""},
    frozen = {"", ""},
    kickoff = {"", ""},
    shifty = {"", ""},
    youthful = {"", ""},
    doubleshot = {"", ""},
    postmove = {"", ""},
    fire_immune = {"", ""},
    smoke_immune = {"", ""},
    shield_heal = {"", ""},
    danger = {"", ""},
    purple = {"", ""},
    boss = {"", ""},

}

local PilotSkills = {
    Disable_Immunity = PilotSkill("", ""),
    Extra_XP = PilotSkill("", ""),
    Self_Shield = PilotSkill("", ""),
    Road_Runner = PilotSkill("", ""),
    Shifty = PilotSkill("", ""),
    Deploy_Anywhere = PilotSkill("", ""),
    Survive_Death = PilotSkill("", ""),
    Pain_Immunity = PilotSkill("", ""),
    Power_Repair = PilotSkill("", ""),
    Freeze_Walk = PilotSkill("", ""),
    Armored = PilotSkill("", ""),
    Flying = PilotSkill("", ""),
    Double_Shot = PilotSkill("", ""),
    Post_Move = PilotSkill("", ""),
    Youth_Move = PilotSkill("", ""),
    Retaliation = PilotSkill("", ""),
    TimeTravel = PilotSkill("", ""),
    Mantis_Skill = PilotSkill("", ""),
    Rock_Skill = PilotSkill("", ""),
    Zoltan_Skill = PilotSkill("", ""),
}

function GetSkillInfo(skill)
    if skill == "" then return PilotSkill() end
    return PilotSkills[skill]
end

function GetTileTooltip(id)
    if TILE_TOOLTIPS[id] ~= nil then
        return TILE_TOOLTIPS[id]
    else
        return { id, "NOT FOUND"}
    end
end

function GetStatusTooltip(id)
    if STATUS_TOOLTIPS[id] ~= nil then
        return STATUS_TOOLTIPS[id]
    else
        return { id, "NOT FOUND"}
    end
end