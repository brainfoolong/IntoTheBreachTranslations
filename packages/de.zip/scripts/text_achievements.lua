
Achievement_Texts = {

    -------------------- Generic Achievements ----------------------

    --Titles in the hangar

    Ach_General_1 = "Siege",
    Ach_General_2 = "Metagame",
    Ach_General_3 = "Insel-Herausforderungen",
    Ach_General_4 = "Pilot-Herausforderungen",
    Ach_General_5 = "Herausforderungsl�ufe",

    ---Victory Achievements

    Ach_Global_Victory_Any_Title = "Sieg",
    Ach_Global_Victory_Any_Text = "Schlage das Spiel (beliebig lang)",

    Ach_Global_Victory_Hard_Title = "Hard Sieg",
    Ach_Global_Victory_Hard_Text = "Schlage das Spiel auf Hard (beliebig lang)",

    Ach_Global_Victory_Islands_Title = "Anpassungsf�higer Sieg",
    Ach_Global_Victory_Islands_Text = "Schlage das Spiel mindestens einmal pro L�nge (2, 3 und 4 Firmeninseln gesichert)",
    Ach_Global_Victory_Islands_Progress = "Fortschritt: $1 / 3 abgeschlossen",

    Ach_Global_Victory_Four_Title = "Squad Sieg",
    Ach_Global_Victory_Four_Text = "Schlage das Spiel mit 4 verschiedenen Squads (beliebiger L�nge)",
    Ach_Global_Victory_Four_Progress = "Fortschritt: $1 / 4 Siege",

    Ach_Global_Victory_Complete_Title = "Vollende den Sieg",
    Ach_Global_Victory_Complete_Text = "Schlage das Spiel mit allen 10 prim�ren Squads (beliebiger L�nge)",
    Ach_Global_Victory_Complete_Progress = "Fortschritt: $1 / 10 Siege",

    ---Meta Achievements

    Ach_Global_Meta_Unlock_Title = "Aufkommende Technologien",
    Ach_Global_Meta_Unlock_Text = "Schalte einen neuen Mech Squad frei",

    Ach_Global_Meta_Reputation_Title = "Freunde in hohen Pl�tzen",
    Ach_Global_Meta_Reputation_Text = "Gib 50 Reputation f�r alle Spiele aus",
    Ach_Global_Meta_Reputation_Progress = "Fortschritt: $1 Reputation ausgegeben",

    Ach_Global_Meta_Block_Title = "Unbewegliche Objekte",
    Ach_Global_Meta_Block_Text = "Blockiere 100 Vek �ber alle Spiele",
    Ach_Global_Meta_Block_Progress = "Fortschritt: $1 Vek blockiert",

    Ach_Global_Meta_Rescue_Title = "Der Erl�ser der Menschheit",
    Ach_Global_Meta_Rescue_Text = "Rette 100.000 Zivilisten in allen Spielen",
    Ach_Global_Meta_Rescue_Progress = "Fortschritt: $1 Zivilisten gerettet",

    Ach_Global_Meta_Perfect_Title = "Perfekte Strategie",
    Ach_Global_Meta_Perfect_Text = "Sammle in allen Spielen 10 Perfekte Insel Belohnungen",
    Ach_Global_Meta_Perfect_Progress = "Fortschritt: $1 Perfect Inseln",

    ------ Global Island Achievements

    Ach_Global_Island_Perfect_Title = "Perfekte Insel",
    Ach_Global_Island_Perfect_Text = "Vers�ume kein Ziel auf einer einzigen Unternehmensinsel",
    Ach_Global_Island_Perfect_Failed = "Fehlgeschlagen: $1 ist fehlgeschlagen",

    Ach_Global_Island_Building_Title = "Die Verteidiger",
    Ach_Global_Island_Building_Text = "Beende eine Firmeninsel ohne Schaden zu nehmen",
    Ach_Global_Island_Building_Failed = "Auf der aktuellen Insel fehlgeschlagen",

    Ach_Global_Island_Mechs_Title = "Unantastbar",
    Ach_Global_Island_Mechs_Text = "Beende eine Firmeninsel ohne Mech-Schaden zu nehmen (Reparierter Schaden ist immer noch Schaden)",
    Ach_Global_Island_Mechs_Failed = "Auf der aktuellen Insel fehlgeschlagen",

    Ach_Global_Island_Power_Title = "Backup-Batterien",
    Ach_Global_Island_Power_Text = "Verdiene oder kaufe 10 Netzenergie auf einer einzigen Unternehmensinsel",
    Ach_Global_Island_Power_Progress = "Fortschritt: $1 Netzenergie verdient",

    Ach_Global_Island_Rep_Title = "Der gute Samariter",
    Ach_Global_Island_Rep_Text = "Verdiene 9 Reputation von Missionen auf einer einzigen Unternehmensinsel",
    Ach_Global_Island_Rep_Progress = "Fortschritt: $1 Reputation verdient",

    ------Pilot Achievements

    Ach_Global_Pilot_Max_Title = "Feldwerbung",
    Ach_Global_Pilot_Max_Text = "Lasse einen Piloten das maximale Level erreichen",

    Ach_Global_Pilot_Three_Title = "Bester der Besten",
    Ach_Global_Pilot_Three_Text = "Halte gleichzeitig 3 Piloten auf Maximalstufe",
    Ach_Global_Pilot_Three_Progress = "Fortschritt: $1 Max. Level Piloten",

    Ach_Global_Pilot_Unlocked_Title = "Komm zusammen",
    Ach_Global_Pilot_Unlocked_Text = "Schalte 6 zus�tzliche Piloten frei",
    Ach_Global_Pilot_Unlocked_Progress = "Fortschritt: $1 Piloten",

    Ach_Global_Pilot_Final_Title = "Ich werde zu alt daf�r ...",
    Ach_Global_Pilot_Final_Text = "Lass einen einzelnen Piloten 3 Mal �ber mehrere Spiele hinweg k�mpfen",
    Ach_Global_Pilot_Final_Progress = "Fortschritt: $1 Finale K�mpfe",

    Ach_Global_Pilot_Face_Title = "Entfernte Freunde",
    Ach_Global_Pilot_Face_Text = "Begegne einem vertrauten Gesicht",

    --------Challenge Runs

    Ach_Global_Challenge_Power_Title = "Nachhaltige Energie",
    Ach_Global_Challenge_Power_Text = "Beende 3 Firmeninseln ohne unter 4 Netzenergie zu fallen",
    Ach_Global_Challenge_Power_Failed = "Fehlgeschlagen: Unter 3 Energie gefallen",

    Ach_Global_Challenge_Mods_Title = "Engineering-Ausfall",
    Ach_Global_Challenge_Mods_Text = "Beende 3 Firmeninseln, ohne eine Waffenmodifikation zu aktivieren",
    Ach_Global_Challenge_Mods_Failed = "Fehlgeschlagen: �nderung aktiviert",

    Ach_Global_Challenge_Pods_Title = "Chronophobie",
    Ach_Global_Challenge_Pods_Text = "Beende 3 Firmeninseln und zerst�re jedes gefundene Time-Pod",
    Ach_Global_Challenge_Pods_Failed = "Fehlgeschlagen: Time-Pod gesammelt",

    Ach_Global_Challenge_Perfect_Title = "Es gibt keinen Versuch",
    Ach_Global_Challenge_Perfect_Text = "Beende 3 Firmeninseln, ohne ein Ziel zu verfehlen",
    Ach_Global_Challenge_Perfect_Failed = "Fehlgeschlagen: Ziel fehlgeschlagen",

    Ach_Global_Challenge_New_Title = "Vertrauensw�rdige Ausr�stung",
    Ach_Global_Challenge_New_Text = "Beende 3 Firmeninseln ohne neue Piloten oder Waffen",
    Ach_Global_Challenge_New_Failed = "Fehlgeschlagen: Loadout ge�ndert",


    --------------------- Random Squad ---------------------------

    Ach_Random_1_Title = "Lootboxen!",
    Ach_Random_1_Text = "�ffne 5 Time-Pods in einem einzigen Spiel",
    Ach_Random_1_Progress = "Fortschritt: $1 ge�ffnet",

    Ach_Random_2_Title = "Gl�cklicher Anfang",
    Ach_Random_2_Text = "Schlage das Spiel (beliebig lang), ohne einen Reputation auszugeben",
    Ach_Random_2_Failed = "Fehlgeschlagen: Verbrauchte Reputation",

    Ach_Random_3_Title = "�ndere die Chancen",
    Ach_Random_3_Text = "Verteidigung auf 30% oder mehr erh�hen",

    ------------------------- Custom Squad -------------------------

    Ach_Custom_1_Title = "Mech-Spezialist",
    Ach_Custom_1_Text = "Schlage das Spiel mit 3 gleichen Mechs",
    Ach_Custom_1_Failed = "Unm�glich: Der aktuelle Squad erf�llt die Anforderungen nicht",

    Ach_Custom_2_Title = "Klassenspezialist",
    Ach_Custom_2_Text = "Schlage das Spiel mit 3 verschiedenen Mechs aus derselben Klasse",
    Ach_Custom_2_Failed = "Unm�glich: Der aktuelle Squad erf�llt die Anforderungen nicht",

    Ach_Custom_3_Title = "Flugspezialist",
    Ach_Custom_3_Text = "Schlage das Spiel mit 3 fliegenden Mechs",
    Ach_Custom_3_Failed = "Unm�glich: Der aktuelle Squad erf�llt die Anforderungen nicht",

    --------------- ARCHIVE SQUAD A -- PUNCH MECH ----------------
    Ach_Archive_A_1_Title = "W�ssriges Grab",
    Ach_Archive_A_1_Text = "Ertr�nke 3 Feinde in Wasser in einer einzigen Schlacht",
    Ach_Archive_A_1_Progress = "Fortschritt: $1 ertrunken",

    Ach_Archive_A_2_Title = "Rammgeschwindigkeit",
    Ach_Archive_A_2_Text = "T�te einen Feind mit einem Sto� von 5 oder mehr Feldern",

    Ach_Archive_A_3_Title = "Insel sicher",
    Ach_Archive_A_3_Text = "Beende die erste Firmeninsel",


    -------------- ARCHIVE SQUAD B -- JUDO --------------------------

    Ach_Archive_B_1_Title = "Unzerbrechlich",
    Ach_Archive_B_1_Text = "Lass Mech-R�stung in einem Kampf 5 Schaden absorbieren",
    Ach_Archive_B_1_Progress = "Fortschritt: $1 Schaden geblockt",

    Ach_Archive_B_2_Title = "Unwissende Verb�ndete",
    Ach_Archive_B_2_Text = "Lass in einem Kampf 4 Feinde durch feindliches Feuer sterben",
    Ach_Archive_B_2_Progress = "Fortschritt: $1 get�tet",

    Ach_Archive_B_3_Title = "Massenverschiebung",
    Ach_Archive_B_3_Text = "Sto�e 3 Feinde mit einem einzigen Angriff",

    ----------- RUST SQUAD A -- SMOKERS --------
    Ach_Rust_A_1_Title = "�berlastet",
    Ach_Rust_A_1_Text = "�berlaste dein Netz zweimal, indem du Energie verdienst  oder kaufst, wenn es voll ist",
    Ach_Rust_A_1_Progress = "Fortschritt: �berlastet $1 / 2",

    Ach_Rust_A_2_Title = "St�rmisches Wetter",
    Ach_Rust_A_2_Text = "Verursache 12 Schaden mit \"Elektrischer Rauch\" in einer einzigen Schlacht",
    Ach_Rust_A_2_Progress = "Fortschritt: $1 Schaden",

    Ach_Rust_A_3_Title = "Perfekte Schlacht",
    Ach_Rust_A_3_Text = "Nimm keinen Mech oder Geb�ude-Schaden in einer einzigen Schlacht (Reparierter Schaden ist immer noch Schaden)",
    Ach_Rust_A_3_Failed = "Fehlgeschlagen: $1 besch�digt",

    ----------- RUST SQUAD B -- FIRE --------
    Ach_Rust_B_1_Title = "Quantenverschr�nkung",
    Ach_Rust_B_1_Text = "Teleportiere eine Einheit 4 Felder ?weg",

    Ach_Rust_B_2_Title = "Verbrannte Erde",
    Ach_Rust_B_2_Text = "Beende einen Kampf mit 12 brennenden Feldern",
    Ach_Rust_B_2_Progress = "Fortschritt: $1 brennen",

    Ach_Rust_B_3_Title = "Das ist in Ordnung",
    Ach_Rust_B_3_Text = "Lass 5 Gegner gleichzeitig brennen",
    Ach_Rust_B_3_Progress = "Fortschritt: $1 brennen momentan",

    ----------- PINNACLE SQUAD A -- LASER --------
    Ach_Pinnacle_A_1_Title = "Komm her",
    Ach_Pinnacle_A_1_Text = "T�te einen Feind, indem du ihn in dich ziehst",

    Ach_Pinnacle_A_2_Title = "Glitzernder C-Beam",
    Ach_Pinnacle_A_2_Text = "Treffe 4 Feinde mit einem einzigen Laser",

    Ach_Pinnacle_A_3_Title = "Schildbeherrschung",
    Ach_Pinnacle_A_3_Text = "Blockiere den Schaden mit einem Schild 4 Mal in einer einzigen Schlacht",
    Ach_Pinnacle_A_3_Progress = "Fortschritt: $1 Schaden geblockt",

    ----------- PINNACLE SQUAD B -- ICE --------
    Ach_Pinnacle_B_1_Title = "Cryo-Experte",
    Ach_Pinnacle_B_1_Text = "Schie�e den Cryo-Launcher 4 Mal in einem Kampf",
    Ach_Pinnacle_B_1_Progress = "Fortschritt: $1 Schuss",

    Ach_Pinnacle_B_2_Title = "Trickschuss",
    Ach_Pinnacle_B_2_Text = "T�te 3 Feinde mit einem einzigen Angriff der Januskanone",

    Ach_Pinnacle_B_3_Title = "Pazifist",
    Ach_Pinnacle_B_3_Text = "T�te weniger als 3 Gegner in einer einzigen Schlacht",
    Ach_Pinnacle_B_3_Failed = "Fehlgeschlagen: $1 get�tet",

    ----------- DETRITUS SQUAD A -- ELECTRIC WHIP --------
    Ach_Detritus_A_1_Title = "Kettenangriff",
    Ach_Detritus_A_1_Text = "Lass den Kettenangriff durch 10 Felder ziehen",

    Ach_Detritus_A_2_Title = "Blitzkrieg",
    Ach_Detritus_A_2_Text = "Beende die ersten 2 Firmeninseln in weniger als 30 Minuten",
    Ach_Detritus_A_2_Failed = "Fehlgeschlagen: Zu langsam!",

    Ach_Detritus_A_3_Title = "Bleib dran",
    Ach_Detritus_A_3_Text = "Blockiere 4 auftauchende Vek in einer einzigen Runde",

    ---------- DETRITUS SQUAD B -- UNSTABLE --------

    Ach_Detritus_B_1_Title = "Heilung",
    Ach_Detritus_B_1_Text = "Heile in einer einzigen Schlacht 10 Mech Gesundheit",
    Ach_Detritus_B_1_Progress = "Fortschritt: $1 geheilt",

    Ach_Detritus_B_2_Title = "Unsterblich",
    Ach_Detritus_B_2_Text = "Beende 4 Firmeninseln, ohne dass ein Mech am Ende einer Schlacht zerst�rt wird",
    Ach_Detritus_B_2_Failed = "Fehlgeschlagen: Mindestens ein Mech wurde zerst�rt",

    Ach_Detritus_B_3_Title = "Overkill",
    Ach_Detritus_B_3_Text = "F�ge einer Einheit mit einem einzigen Angriff 8 Schaden zu",

    -----------------------------------------------------------------
}

--ignore me
Achievement_Generals = {
    "Global_Victory_Any", "Global_Victory_Hard", "Global_Victory_Islands", "Global_Victory_Four", "Global_Victory_Complete",
    "Global_Meta_Unlock", "Global_Meta_Reputation", "Global_Meta_Block", "Global_Meta_Rescue", "Global_Meta_Perfect",
    "Global_Island_Perfect","Global_Island_Building","Global_Island_Mechs","Global_Island_Power","Global_Island_Rep",
    "Global_Pilot_Max","Global_Pilot_Three","Global_Pilot_Unlocked","Global_Pilot_Final","Global_Pilot_Face",
    "Global_Challenge_Power","Global_Challenge_Mods","Global_Challenge_Pods","Global_Challenge_Perfect","Global_Challenge_New",
}