
Achievement_Texts = {

    -------------------- Generic Achievements ----------------------

    --Titles in the hangar

    Ach_General_1 = "",
    Ach_General_2 = "",
    Ach_General_3 = "",
    Ach_General_4 = "",
    Ach_General_5 = "",

    ---Victory Achievements

    Ach_Global_Victory_Any_Title = "",
    Ach_Global_Victory_Any_Text = "",

    Ach_Global_Victory_Hard_Title = "",
    Ach_Global_Victory_Hard_Text = "",

    Ach_Global_Victory_Islands_Title = "",
    Ach_Global_Victory_Islands_Text = "",
    Ach_Global_Victory_Islands_Progress = "",

    Ach_Global_Victory_Four_Title = "",
    Ach_Global_Victory_Four_Text = "",
    Ach_Global_Victory_Four_Progress = "",

    Ach_Global_Victory_Complete_Title = "",
    Ach_Global_Victory_Complete_Text = "",
    Ach_Global_Victory_Complete_Progress = "",

    ---Meta Achievements

    Ach_Global_Meta_Unlock_Title = "",
    Ach_Global_Meta_Unlock_Text = "",

    Ach_Global_Meta_Reputation_Title = "",
    Ach_Global_Meta_Reputation_Text = "",
    Ach_Global_Meta_Reputation_Progress = "",

    Ach_Global_Meta_Block_Title = "",
    Ach_Global_Meta_Block_Text = "",
    Ach_Global_Meta_Block_Progress = "",

    Ach_Global_Meta_Rescue_Title = "",
    Ach_Global_Meta_Rescue_Text = "",
    Ach_Global_Meta_Rescue_Progress = "",

    Ach_Global_Meta_Perfect_Title = "",
    Ach_Global_Meta_Perfect_Text = "",
    Ach_Global_Meta_Perfect_Progress = "",

    ------ Global Island Achievements

    Ach_Global_Island_Perfect_Title = "",
    Ach_Global_Island_Perfect_Text = "",
    Ach_Global_Island_Perfect_Failed = "",

    Ach_Global_Island_Building_Title = "",
    Ach_Global_Island_Building_Text = "",
    Ach_Global_Island_Building_Failed = "",

    Ach_Global_Island_Mechs_Title = "",
    Ach_Global_Island_Mechs_Text = "",
    Ach_Global_Island_Mechs_Failed = "",

    Ach_Global_Island_Power_Title = "",
    Ach_Global_Island_Power_Text = "",
    Ach_Global_Island_Power_Progress = "",

    Ach_Global_Island_Rep_Title = "",
    Ach_Global_Island_Rep_Text = "",
    Ach_Global_Island_Rep_Progress = "",

    ------Pilot Achievements

    Ach_Global_Pilot_Max_Title = "",
    Ach_Global_Pilot_Max_Text = "",

    Ach_Global_Pilot_Three_Title = "",
    Ach_Global_Pilot_Three_Text = "",
    Ach_Global_Pilot_Three_Progress = "",

    Ach_Global_Pilot_Unlocked_Title = "",
    Ach_Global_Pilot_Unlocked_Text = "",
    Ach_Global_Pilot_Unlocked_Progress = "",

    Ach_Global_Pilot_Final_Title = "",
    Ach_Global_Pilot_Final_Text = "",
    Ach_Global_Pilot_Final_Progress = "",

    Ach_Global_Pilot_Face_Title = "",
    Ach_Global_Pilot_Face_Text = "",

    --------Challenge Runs

    Ach_Global_Challenge_Power_Title = "",
    Ach_Global_Challenge_Power_Text = "",
    Ach_Global_Challenge_Power_Failed = "",

    Ach_Global_Challenge_Mods_Title = "",
    Ach_Global_Challenge_Mods_Text = "",
    Ach_Global_Challenge_Mods_Failed = "",

    Ach_Global_Challenge_Pods_Title = "",
    Ach_Global_Challenge_Pods_Text = "",
    Ach_Global_Challenge_Pods_Failed = "",

    Ach_Global_Challenge_Perfect_Title = "",
    Ach_Global_Challenge_Perfect_Text = "",
    Ach_Global_Challenge_Perfect_Failed = "",

    Ach_Global_Challenge_New_Title = "",
    Ach_Global_Challenge_New_Text = "",
    Ach_Global_Challenge_New_Failed = "",


    --------------------- Random Squad ---------------------------

    Ach_Random_1_Title = "",
    Ach_Random_1_Text = "",
    Ach_Random_1_Progress = "",

    Ach_Random_2_Title = "",
    Ach_Random_2_Text = "",
    Ach_Random_2_Failed = "",

    Ach_Random_3_Title = "",
    Ach_Random_3_Text = "",

    ------------------------- Custom Squad -------------------------

    Ach_Custom_1_Title = "",
    Ach_Custom_1_Text = "",
    Ach_Custom_1_Failed = "",

    Ach_Custom_2_Title = "",
    Ach_Custom_2_Text = "",
    Ach_Custom_2_Failed = "",

    Ach_Custom_3_Title = "",
    Ach_Custom_3_Text = "",
    Ach_Custom_3_Failed = "",

    --------------- ARCHIVE SQUAD A -- PUNCH MECH ----------------
    Ach_Archive_A_1_Title = "",
    Ach_Archive_A_1_Text = "",
    Ach_Archive_A_1_Progress = "",

    Ach_Archive_A_2_Title = "",
    Ach_Archive_A_2_Text = "",

    Ach_Archive_A_3_Title = "",
    Ach_Archive_A_3_Text = "",


    -------------- ARCHIVE SQUAD B -- JUDO --------------------------

    Ach_Archive_B_1_Title = "",
    Ach_Archive_B_1_Text = "",
    Ach_Archive_B_1_Progress = "",

    Ach_Archive_B_2_Title = "",
    Ach_Archive_B_2_Text = "",
    Ach_Archive_B_2_Progress = "",

    Ach_Archive_B_3_Title = "",
    Ach_Archive_B_3_Text = "",

    ----------- RUST SQUAD A -- SMOKERS --------
    Ach_Rust_A_1_Title = "",
    Ach_Rust_A_1_Text = "",
    Ach_Rust_A_1_Progress = "",

    Ach_Rust_A_2_Title = "",
    Ach_Rust_A_2_Text = "",
    Ach_Rust_A_2_Progress = "",

    Ach_Rust_A_3_Title = "",
    Ach_Rust_A_3_Text = "",
    Ach_Rust_A_3_Failed = "",

    ----------- RUST SQUAD B -- FIRE --------
    Ach_Rust_B_1_Title = "",
    Ach_Rust_B_1_Text = "",

    Ach_Rust_B_2_Title = "",
    Ach_Rust_B_2_Text = "",
    Ach_Rust_B_2_Progress = "",

    Ach_Rust_B_3_Title = "",
    Ach_Rust_B_3_Text = "",
    Ach_Rust_B_3_Progress = "",

    ----------- PINNACLE SQUAD A -- LASER --------
    Ach_Pinnacle_A_1_Title = "",
    Ach_Pinnacle_A_1_Text = "",

    Ach_Pinnacle_A_2_Title = "",
    Ach_Pinnacle_A_2_Text = "",

    Ach_Pinnacle_A_3_Title = "",
    Ach_Pinnacle_A_3_Text = "",
    Ach_Pinnacle_A_3_Progress = "",

    ----------- PINNACLE SQUAD B -- ICE --------
    Ach_Pinnacle_B_1_Title = "",
    Ach_Pinnacle_B_1_Text = "",
    Ach_Pinnacle_B_1_Progress = "",

    Ach_Pinnacle_B_2_Title = "",
    Ach_Pinnacle_B_2_Text = "",

    Ach_Pinnacle_B_3_Title = "",
    Ach_Pinnacle_B_3_Text = "",
    Ach_Pinnacle_B_3_Failed = "",

    ----------- DETRITUS SQUAD A -- ELECTRIC WHIP --------
    Ach_Detritus_A_1_Title = "",
    Ach_Detritus_A_1_Text = "",

    Ach_Detritus_A_2_Title = "",
    Ach_Detritus_A_2_Text = "",
    Ach_Detritus_A_2_Failed = "",

    Ach_Detritus_A_3_Title = "",
    Ach_Detritus_A_3_Text = "",

    ---------- DETRITUS SQUAD B -- UNSTABLE --------

    Ach_Detritus_B_1_Title = "",
    Ach_Detritus_B_1_Text = "",
    Ach_Detritus_B_1_Progress = "",

    Ach_Detritus_B_2_Title = "",
    Ach_Detritus_B_2_Text = "",
    Ach_Detritus_B_2_Failed = "",

    Ach_Detritus_B_3_Title = "",
    Ach_Detritus_B_3_Text = "",

    -----------------------------------------------------------------
}

--ignore me
Achievement_Generals = {
    "Global_Victory_Any", "Global_Victory_Hard", "Global_Victory_Islands", "Global_Victory_Four", "Global_Victory_Complete",
    "Global_Meta_Unlock", "Global_Meta_Reputation", "Global_Meta_Block", "Global_Meta_Rescue", "Global_Meta_Perfect",
    "Global_Island_Perfect","Global_Island_Building","Global_Island_Mechs","Global_Island_Power","Global_Island_Rep",
    "Global_Pilot_Max","Global_Pilot_Three","Global_Pilot_Unlocked","Global_Pilot_Final","Global_Pilot_Face",
    "Global_Challenge_Power","Global_Challenge_Mods","Global_Challenge_Pods","Global_Challenge_Perfect","Global_Challenge_New",
}