
local PopEvent = {
    Opening = {"Wurden gerettet!", "Ich wusste, dass sie kommen w�rden!", "Der #squad!", "Es ist der #squad!", "Jetzt werden die Vek es bekommen!", "Die Vek werden es jetzt bereuen!", "Hol mir meine Brille!\nIch will das sehen!", "H�r auf, am Fenster zu h�ngen!", "Was ist los?", "Die Mechs sind gelandet!", "#corp hat Mechs geschickt!", "Was ist das f�r ein L�rm?", "H�rst du was?", "Sind es sie?", "Sie sind hier!", "Mama, schau!", "Die Mechs!", "Papa, schau!", "Wir sind gerettet!", "Endlich!", "Hilfe ist hier!", "Sie sind gekommen!", "Die Mechs sind hier!", "Sie werden uns besch�tzen!"},
	
    Closing = {"Vielen Dank!", "Sie sind auf der Flucht!", "Die Vek laufen!", "Wurden gerettet!", "Das war erstaunlich!", "Nicht zu fassen!", "Sie haben es geschafft!", "Es ist aus!", "Wir haben gewonnen!", "Wir �berlebten!", "Sieg!", "Sie sind gegangen!", "Sie fliehen!", "Du hast sie verjagt!"},
	
    Closing_Dead = {"Vielen Dank!", "Ich kann es nicht glauben!", "Tot? Alle von ihnen?", "Sie haben sie alle get�tet?", "Sie sind alle tot!", "Wurden gerettet!", "Du hast sie ausgel�scht!", "Der #squad schlug sie!", "Die Mechs haben sie ausgel�scht!", "Sie sind gegangen!", "Keine Vek mehr!", "Amazing!", "Du hast gewonnen!", "Wir �berlebten!"},
	
    Closing_Perfect = {"Vielen Dank!", "Uns geht es allen gut!", "Alles in Ordnung?", "Der #squad hat uns gerettet!", "Drei Prost f�r den #squad!", "#corp ist gespeichert!", "Nichts wurde besch�digt!", "Die #squad sind Helden!", "Perfekter Sieg!", "Sieg!", "Hast du das gesehen?", "Ich kann es nicht glauben!"},
	
    Closing_Bad = {"Danke ... denke ich.", "Sie haben mehr geschadet als geholfen ...", "Meine Familie ... weg ...", "So viele verloren ...", "Sind sie endlich weg?", "Ist es vorbei?", "Zeit f�r den Wiederaufbau ..."},
	
    Threatened = {"Es greift uns an!", "Oh, oh.", "Ach nein!", "Macht euch bereit!", "Geh weg von den Fenstern!", "Was ist das f�r ein Schatten?", "Das sieht schlecht aus ...", "Hilfe!", "Wir sind verdammt!", "Unser Gl�ck verl�sst uns...", "Es zielt auf uns!", "Hilfe! Irgendjemand, Hilfe!", "Hilf uns, #squad!", "#squad, Hilfe!", "Wir sind bereit daf�r.", "Rette uns!", "Es kommt auf uns zu!", "Wird das Geb�ude halten?", "Hilf uns!", "Rette uns!", Odds = 50 },
	
    Killed = {"Whoa.", "Ja!", "Iss das, Vek!", "Ich kann es nicht glauben!", "Es ist tot!", "Sie haben es rausgeholt!", "Und bleib tot!", "Sie haben es get�tet!", "Es ist tot!", "Hast du das gesehen ?!", "Ausgezeichnet!", "Ja!", "Gut!", "Beeindruckend!", Odds = 50 },
	
    Shielded = {"Wir sind sicher!", "Wird das halten?", "Das wird sie aufhalten!", "Abgeschirmt!", "Wir sind abgeschirmt!", "Schild hoch!", "Endlich sicher!", "Schutz!", Odds = 50 },
	
    Frozen = {"Es ist so kalt...", "Nimm die Decken.", "Zusammen kuscheln, alle.", "Das Fenster ist vereist!", "Was ist passiert?", "F�hlt sich an wie ein Gefrierschrank!", "Es friert!", "Es ist zu kalt!", "Zumindest sind wir in Sicherheit?", Odds = 50 },
}

function GetPopulationTexts(event, count)
    
	local nullReturn = count == 1 and "" or {}
	
	if PopEvent[event] == nil then
		return nullReturn
	end
	
	if Game == nil then
        return nullReturn
    end
	
	if PopEvent[event].Odds ~= nil and random_int(100) > PopEvent[event].Odds then
		return nullReturn
	end
	
	local list = copy_table(PopEvent[event])
	
	local ret = {}
	for i = 1, count do
		if #list == 0 then
			break
		end
		
		ret[#ret+1] = random_removal(list)
	end
	
	if #ret == 0 then
		return nullReturn
	end

	local corp_name = Game:GetCorp().bark_name
	local squad_name = Game:GetSquad()
	for i,v in ipairs(ret) do
		ret[i] = string.gsub(ret[i], "#squad", squad_name)
		ret[i] = string.gsub(ret[i], "#corp", corp_name)
	end
	
	if count == 1 then
		return ret[1]
	end
	
	return ret
end