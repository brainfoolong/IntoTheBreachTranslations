
local Global_Texts = {

-----COMBAT TUTORIAL
    Tutorial_InfoButton_Text = "",
    Tutorial_InfoButton_Title = "",

    Tutorial_CombatPower_Text = "",
    Tutorial_CombatPower_Title = "",

    Tutorial_CombatAiming_Text = "",
    Tutorial_CombatAiming_Title = "",

    Tutorial_CombatMonster_Text = "",
    Tutorial_CombatMonster_Title = "",

    Tutorial_CombatMech_Text = "",
    Tutorial_CombatMech_Title = "",

    Tutorial_DeadTutorial_Title = "",
    Tutorial_DeadTutorial_Text = "",

    Tutorial_CombatGameover_Text = "",
    Tutorial_CombatGameover_Title = "",

    Tutorial_CombatUndo_Text = "",
    Tutorial_CombatUndo_Title = "",

    Tutorial_CombatPunch_Text = "",
    Tutorial_CombatPunch_Title = "",

    Tutorial_CombatPush_Text = "",
    Tutorial_CombatPush_Title = "",

    Tutorial_CombatTank_Text = "",
    Tutorial_CombatTank_Title = "",

    Tutorial_CombatComplete_Text = "",
    Tutorial_CombatComplete_Title = "",

    Tutorial_CombatBonus_Text = "",
    Tutorial_CombatBonus_Title = "",

    Tutorial_CombatWeapon_Text = "",
    Tutorial_CombatWeapon_Title = "",

    Tutorial_CombatEnd_Text = "",
    Tutorial_CombatEnd_Title = "",

--- MISSION TUTORIALS

    Tutorial_Tanks_Text = "",
    Tutorial_Tanks_Title = "",

    Tutorial_Terraform_Text = "",
    Tutorial_Terraform_Title = "",

    Tutorial_VolatileVek_Text = "",
    Tutorial_VolatileVek_Title = "",

---- STANDARTD TUTORIALS

--    Tutorial_FinalIsland_Title = "Final Mission",
    --Tutorial_FinalIsland_Text = "You may attempt the Final Mission now that you've completed two Islands. Alternatively, you can continue to secure more Islands. \n\nYour --choice should depend on how long you would like to play this timeline. The difficulty will always scale to your current progress.",

    Warning_Final = "",

    Warning_OldSave = "",

    Tutorial_PoweredPilot_Title = "",
    Tutorial_PoweredPilot_Text = "",

    Tutorial_Acid_Title = "",
    Tutorial_Acid_Text = "",

    Tutorial_Frozen_Text = "",
    Tutorial_Frozen_Title = "",

    Tutorial_Frozen_Mech_Text = "",
    Tutorial_Frozen_Mech_Title = "",

    Tutorial_Shield_Title = "",
    Tutorial_Shield_Text = "",

    Tutorial_Armor_Title = "",
    Tutorial_Armor_Text = "",

    Tutorial_Environment_Text = "",
    Tutorial_Environment_Title = "",

    Tutorial_PowerGrid_Text = "",
    Tutorial_PowerGrid_Title = "",

    Tutorial_Overpower_Text = "",
    Tutorial_Overpower_Title = "",

    Tutorial_FullOverpower_Text = "",
    Tutorial_FullOverpower_Title = "",

    Tutorial_GridDefense_Text = "",
    Tutorial_GridDefense_Title = "",

    Tutorial_Jelly_Text = "",
    Tutorial_Jelly_Title = "",

    Tutorial_Webbed_Text = "",
    Tutorial_Webbed_Title = "",

    Tutorial_IslandNewGame_Text = "",
    Tutorial_IslandNewGame_Title = "",

    Tutorial_Spawning_Text = "",
    Tutorial_Spawning_Title = "",

    Tutorial_Forest_Text = "",
    Tutorial_Forest_Title = "",

    Tutorial_Fire_Text = "",
    Tutorial_Fire_Title = "",

    Tutorial_DamagedMech_Text = "",
    Tutorial_DamagedMech_Title = "",

    Tutorial_Corroded_Text = "",
    Tutorial_Corroded_Title = "",

    Tutorial_Pod_Text = "",
    Tutorial_Pod_Title = "",

    Tutorial_PodDestroyed_Title = "",
    Tutorial_PodDestroyed_Text = "",

    Tutorial_Water_Text = "",
    Tutorial_Water_Title = "",

    Tutorial_WaterUndo_Text = "",
    Tutorial_WaterUndo_Title = "",

    Tutorial_DeadPilot_Text = "",
    Tutorial_DeadPilot_Title = "",

    Tutorial_Drowning_Text = "",
    Tutorial_Drowning_Title = "",

    Tutorial_PushDamage_Text = "",
    Tutorial_PushDamage_Title = "",

    Tutorial_PushDeath_Text = "",
    Tutorial_PushDeath_Title = "",

    Tutorial_BuildingDamage_Text = "",
    Tutorial_BuildingDamage_Title = "",

    Tutorial_Combat_Title = "",
    Tutorial_Combat_Text = "",

    Tutorial_Money_Title = "",
    Tutorial_Money_Text = "",

    Tutorial_Cores_Title = "",
    Tutorial_Cores_Text = "",

    Tutorial_Cores2_Title = "",
    Tutorial_Cores2_Text = "",

    Tutorial_Cores3_Title = "",
    Tutorial_Cores3_Text = "",

    Tutorial_Weapon_Title = "",
    Tutorial_Weapon_Text = "",

    Tutorial_Pilot_Title = "",
    Tutorial_Pilot_Text = "",

    ---Beta warning for squad unlock change

    Tutorial_OldProfile_Title = "",
    Tutorial_OldProfile_Text = "",

    ---Tutorial Large Screens
    Tutorial_Weapons = "",
    Tutorial_WeaponsText = "",
    Tutorial_Weapons_Push = "",
    Tutorial_Weapons_PushText = "",
    Tutorial_Weapons_Damage = "",
    Tutorial_Weapons_DamageText = "",
    Tutorial_Weapons_PushDamage = "",
    Tutorial_Weapons_PushDamageText = "",

    Tutorial_Art = "",
    Tutorial_ArtText = "",
    Tutorial_ArtExtra = "",

    Tutorial_Rewards = "",
    Tutorial_RewardsText = "",
    Tutorial_Rewards_Cores = "",
    Tutorial_Rewards_Power = "",
    Tutorial_Rewards_Reputation = "",
    Tutorial_Rewards_Difficulty = "",
    Tutorial_RegionName = "",

    Tutorial_Final = "",
    Tutorial_FinalText = "",
    Tutorial_Final_Scaling = "",
    Tutorial_Final_Scaling = "",
    Tutorial_Final_Scoring = "",
    Tutorial_Final_Scoring = "",

    Tutorial_StartCombat = "",
    Tutorial_DeclineCombat = "",
    Tutorial_DeclineAll = "",

    Tutorial_Dismiss = "",

    --tooltips
    TipTitle_FinalMission = "",
    TipText_FinalMission = "",


    TipTitle_Reputation = "",
    TipText_Reputation = "",
    TipTitle_Cores = "",
    TipText_Cores = "",

    TipTitle_Order = "",
    TipText_Order = "",
    TipText_Menu = "",
    TipTitle_Menu = "",

    TipText_Overlay = "",
    TipTitle_Overlay = "",

    TipText_Timer = "",
    TipTitle_Timer = "",

    TipText_ResetTurn = "",
    TipTitle_ResetTurn = "",

    TipText_ResetTurnUsed = "",
    TipTitle_ResetTurnUsed = "",

    TipText_ResetTurnExtra = "",
    TipTitle_ResetTurnExtra = "",

    TipText_ResetTurnFinal = "",
    TipTitle_ResetTurnFinal = "",

    TipText_CombatSpeed = "",
    TipTitle_CombatSpeed = "",

    TipText_Abandon = "",
    TipTitle_Abandon = "",

    TipTitle_TutorialTips = "",
    TipText_TutorialTips = "",

    TipTitle_BoardScale = "",
    TipText_BoardScale = "",

    TipTitle_DefaultRes = "",
    TipText_DefaultRes = "",

    TipTitle_AudioMuted = "",
    TipText_AudioMuted = "",

    TipTitle_Timer = "",
    TipText_Timer = "",

    TipTitle_Colorblind = "",
    TipText_Colorblind = "",

    TipTitle_LargeFont = "",
    TipText_LargeFont = "",

    TipTitle_NoLargeFont = "",
    TipText_NoLargeFont = "",

    TipTitle_Confirm = "",
    TipText_Confirm = "",

    TipTitle_Stretch = "",
    TipText_Stretch = "",

    TipTitle_NoStretch = "",
    TipText_NoStretch = "",

    TipTitle_BattleVictory = "",
    TipText_BattleVictory = "",
    TipText_BattleVictory_One = "",

    TipTitle_BattleVictory_Final = "",
    TipText_BattleVictory_Final = "",
    TipText_BattleVictory_One_Final = "",

    TipTitle_RepObj = "",
    TipText_RepObj = "",
    TipTitle_PodObj = "",
    TipText_PodObj = "",
    TipTitle_PowerObj = "",
    TipText_PowerObj = "",
    TipTitle_CoreObj = "",
    TipText_CoreObj = "",
    TipTitle_Saved = "",
    TipText_Saved = "",
    TipTitle_UpgradeReactor = "",
    TipText_UpgradeReactor = "",
    TipTitle_UndoCore = "",
    TipText_UndoCore = "",
    TipTitle_Health = "",
    TipText_Health = "",
    TipTitle_Move = "",
    TipText_Move = "",

    TipTitle_ZoltanHealth = "",
    TipText_ZoltanHealth = "",

    TipTitle_MechClass = "",
    TipText_MechClass = "",

    TipTitle_Cyborg = "",
    TipText_Cyborg = "",

    TipText_RenamePilot = "",
    TipTitle_RenamePilot = "",
    TipText_RenameMech = "",
    TipTitle_RenameMech = "",

    TipTitle_PilotMax = "",
    TipText_PilotMax = "",
    TipTitle_PilotExperience = "",
    TipText_PilotExperience = "",
    TipTitle_PilotAI = "",
    TipText_PilotAI = "",

    TipText_GridDefense = "",
    TipTitle_GridDefense = "",
    TipText_PowerGrid = "",
    TipTitle_PowerGrid = "",

    TipTitle_BuyCore = "",
    TipText_BuyCore = "",
    TipTitle_BuyPower = "",
    TipText_BuyPower = "",

    TipTitle_BuyPower_Grid = "",
    TipText_BuyPower_Grid = "",

    TipTitle_BuyPower_Full = "",
    TipText_BuyPower_Full = "",

    TipTitle_Mission_Normal = "",
    TipText_Mission_Normal = "",
    TipTitle_Mission_Hard = "",
    TipText_Mission_Hard = "",
    TipTitle_Mission_Easy = "",
    TipText_Mission_Easy = "",

    ------ ENVIRONMENTS ---------

    TipTitle_Env_BeltLine = "",
    TipText_Env_BeltLine = "",
    TipTitle_Env_BeltRandom = "",
    TipText_Env_BeltRandom = "",
    TipTitle_Env_Airstrike = "",
    TipText_Env_Airstrike = "",
    TipTitle_Env_Tides = "",
    TipText_Env_Tides = "",
    TipTitle_Env_Cataclysm = "",
    TipText_Env_Cataclysm = "",
    TipTitle_Env_Seismic = "",
    TipText_Env_Seismic = "",
    TipTitle_Env_Lightning = "",
    TipText_Env_Lightning = "",
    TipTitle_Env_SnowStorm = "",
    TipText_Env_SnowStorm = "",

    ---------- Island Descriptions


    Corp_Grass_Description = "",
    Corp_Desert_Description = "",
    Corp_Snow_Description = "",
    Corp_Factory_Description = "",

    --Order Texts
    Order_Fire = "",
    Order_Psion = "",
    Order_Tentacle = "",
    Order_Actions = "",
    Order_NPC = "",
    Order_NPC_Bots = "",
    Order_Emerge = "",
    Order_Env = "",
    Order_Smoke = "",

    ---Combat Texts
    Deploying_Mech = "",
    Deploying_Instructions = "",
    Deploying_Complete = "",
    Deploying_Confirm = "",
    Combat_Deployment = "EINSATZ",
    Deploy_Remaining = "",
    Button_Deployment_Done = "BEST�TIGEN",
    Button_Button_Pawnlist = "     Einheitenliste",
    Button_Button_Objectives = "Bonusziele     ",

    Skip_Units = "",
    Reset_Turn = "",
    Reset_TurnExtra = "",
    Reset_TurnFinal = "",
    Button_EndTurn = "",
    Button_Undo = "BEWEGUNG \nR�CKG�NGIG",
    Button_UndoTurn = "ZUG ZUR�CKSETZEN",
    Button_UndoTurnUsed = "VERBRAUCHT ZUR�CKSETZEN",

    Active_Units = "Aktive Einheiten: ",

    Objective_EnemyRetreat = "",
    Objective_EnemyRetreat2 = "",
    Objective_EnemyRetreat3 = "",

    Button_Editor_Exit = "MAP BEARBEITEN",
    Button_Done_Testing = "TEST ABGESCHLOSSEN",

    Disarm_Info = "",

    -- Skill Info
    Skill_Passive = "",
    Skill_ClassAny = "",
    Skill_ClassTechnoVek = "",
    Skill_ClassPassive = "",
    Skill_ClassPrime = "",
    Skill_ClassDeath = "",
    Skill_ClassBrute = "",
    Skill_ClassRanged = "",
    Skill_ClassScience = "",
    Skill_ClassEnemy = "",
    Skill_ClassString = "",
    Skill_ClassPassString = "",
    Skill_Damage = "",
    Skill_SelfDamage = "",
    Skill_Limited = "",

    Skill_WrongClass = "",
    Skill_CyborgOnly = "",

    --- Pilot Info
    Pilot_Special = "",
    Pilot_PowerReq = "",
    Pilot_Powered = "",
    Pilot_None = "",
    Pilot_Max = "",
    Pilot_XP = "",
    Pilot_Unknown = "",
    Pilot_UnknownText = "",
    Pilot_Skills = "",
    Pilot_Experience = "",
    Pilot_History = "",
    Pilot_History_Timelines = "",
    Pilot_History_Final = "",

    Pilot_HealthName = "",
    Pilot_HealthShort = "",
    Pilot_HealthDesc = "",

    Pilot_MoveName = "",
    Pilot_MoveShort = "",
    Pilot_MoveDesc = "",

    Pilot_GridName = "",
    Pilot_GridShort = "",
    Pilot_GridDesc = "",

    Pilot_ReactorName = "",
    Pilot_ReactorShort = "",
    Pilot_ReactorDesc = "",

    Pilot_XpString = "",
    Pilot_XpMax = "",
    Pilot_XpAI = "",

    -- Gamepad instructions`
    Gamepad_SelectUnit = "",
    Gamepad_PlaceUnit = "",
    Gamepad_MoveUnit = "",
    Gamepad_FireWeapon = "",
    Gamepad_Cancel = "",

    --Combat State Labels
    State_Tutorial = "",
    State_Gameover = "",
    State_Player = "",
    State_Enemy = "",
    State_Start = "",
    State_Complete = "",
    State_Disabled = "",
    State_Turns = "",
    State_LastTurn = "",

    --Upgrade Screen

    Upgrade_Move = "",
    Upgrade_Health = "",
    Upgrade_Install = "",
    Upgrade_Max = "",
    Upgrade_Class = "",
    Upgrade_Test = "",
    Upgrade_Armory = "",
    Upgrade_Pilot = "",
    Upgrade_Stats = "",
    Upgrade_Reactor = "",
    Upgrade_Move = "",
    Upgrade_Health = "",
    Upgrade_Weapons = "",
    Button_Upgrade_Test = "MECH TESTEN",
    Button_Upgrade_Undo = "ZUR�CKSETZEN",
    Wrong_Cost = "",
    Wrong_Class = "",
    Upgrade_Page = "",
    Upgrade_New = "",

    --Victory Screen
    Victory_RegionLost = "",
    Victory_FailedRewards = "",
    Victory_Simulation = "",
    Victory_SimulationText = "",
    Objective_Title = "",
    Objective_Title_One = "",
    Objective_Title_Final = "",
    Victory_Civilians = "",
    Victory_Title = "",
    Pod_Title = "",
    Pod_Contents = "",

    ---Store
    Store_Core = "",
    Store_Cost = "",
    Store_Equipped = "",
    Store_Purchase = "",
    Store_Sell = "",
    Store_SellTitle = "",
    Store_BuyTitle = "",
    Store_Weapons = "",
    Store_Pilots = "",
    Leave_Confirm = "",
    SellPilot_Confirm = "",
    SellWeapon_Confirm = "",

    --Rewards
    Reward_Title = "",
    Reward_Subheading = "",

    --- Misc
    Pod_Objective = "",
    Secret_Objective = "",
    Secret_Objective_Failed = "",
    Pod_Detected = "",
    Pod_Failed = "",
    Toggle_NeverAgain = "",
    Mission_Map_Deploy = "",
    Pawn_Box_Water = "",
    Pawn_Box_Acid = "",
    Pawn_Box_Smoke = "",
    Pawn_Box_Ice = "",
    Pawn_Box_Shot = "",
    Pawn_Box_Lava = "",
    Boss_Title = "Warnung: Vek Offensive",
    Boss_Text = "Vek �berlaufen zwei Regionen auf der Insel.\nThe Region die nicht gesichert wird ist f�r immer verloren.",
    Top_Power = "",
    Top_Grid = "",
    Top_Defense = "",
    Pilot_TurnOver = "",
    Pilot_Disabled = "",
    Pilot_EnemyDead = "",

    --Office
    Island_Office = "",

    --Mission Texts
    Mission_Normal = "",
    Mission_Easy = "",
    Mission_Hard = "",
    Mission_Final = "",
    Mission_Failed = "",
    Mission_None = "",

    --Confirm Box
    Button_Confirm_No = "NEIN",
    Button_Confirm_Yes = "JA",
    Confirm_Question = "Weiter?",
    Button_Confirm_Ok = "OK",

    -- Pilot News
    PilotNews_Dead = "",
    PilotNews_Revived = "",
    PilotNews_ReviveText = "",
    PilotNews_Vek = "",
    PilotNews_VekText = "",
    PilotNews_DeadText = "",
    PilotNews_Promoted = "",
    PilotNews_Skill = "",
    Button_Pilot_News_Done = "Verstanden",


    --Buttons
    Button_Continue = "WEITER",
    Button_Wait = "WARTEN",
    Button_Create = "ERSTELLEN",

    --Main Menu
    Button_Profile = "Neues Profil erstellen",
    Button_MainContinue = "Weiter",
    Button_MainCredits = "Credits",
    Button_MainNew = "Neues Spiel",
    Button_MainOptions = "Optionen",
    Button_MainProgress = "Fortschritt",
    Button_MainStats = "Statistiken",
    Button_MainAchievs = "Errungenschaften",
    Button_MainSquads = "Squads",
    Button_MainQuit = "Beenden",
    Button_MainProfile = "Profil",
    Toggle_EnableTips = "",
    NewGame_Confirm = "",
    Delete_Confirm = "",
    Warning_NoSave = "",
    Warning_FileWriteIssue = "",
    Menu_NoSave = "",
    Confirm_Header = "Aktion best�tigen",
    Warn_Header = "",
    Profile_Delete_Failed = "",
    Profile_Delete_Failed_OSX = "",


    Stats_Header = "Statistiken",
    Stats_TotalVictory = "",
    Stats_TotalLost = "",
    Stats_TotalGames = "",

    Stats_TotalTravelers = "",
    Stats_TotalKills = "",
    Stats_TotalSaved = "",
    Stats_TotalIsland = "",
    Stats_TotalPods = "",

    Stats_ScoreDefeat = "",
    Stats_ScoreVictory = "",
    Stats_ScoreScore = "",
    Stats_ScoreKills = "",
    Stats_ScoreFailed = "",
    Stats_ScoreTimer = "",

    Stats_SquadGames = "",
    Stats_SquadScore = "",
    Stats_SquadKills = "",

    Stats_PilotBattles = "",
    Stats_PilotJumps = "",
    Stats_PilotKills = "",
    Stats_Pilot_Deaths = "",

    Stats_VekDeadliest = "",
    Stats_VekDeadliestStat = "",
    Stats_VekWeakest = "",
    Stats_VekWeakestStat = "",
    Stats_VekDestruction = "",
    Stats_VekDestructionStat = "",


    Stats_ListButton = "",
    Stats_SquadButton = "",
    Stats_PilotButton = "",
    Stats_Done = "",

    Stats_ToggleGlobal = "",

    --Hangar
    Toggle_Easy = "",
    Toggle_Hard = "",
    Toggle_Normal = "",
    Hangar_None = "",
    Hangar_Custom = "",
    Hangar_Traveler = "",
    Hangar_Island_Victory = "",
    Hangar_Island_Victory_2 = "",
    Hangar_Island_Victory_3 = "",
    Hangar_Island_Victory_4 = "",
    Hangar_Island_Victory_Title = "",
    Hangar_Ach_Coins = "",
    Hangar_Locked = "",
    Hangar_Random = "",
    Hangar_Custom = "",
    Hangar_Complete = "",
    Hangar_Achievements = "",
    Hangar_Buy = "",
    Button_Hangar_Squad = "",
    Button_Hangar_Pilot = "Zeitreisenden �ndern",
    Button_Hangar_Random_Pilot = "Zuf�llig",
    Button_Hangar_Reroll = "Ausgeglichen zuordnen",
    Button_Hangar_RandomRoll = "Zuf�llig zuordnen",
    Button_Hangar_Ach = "Alle Errungenschaften anzeigen",
    Button_Hangar_Secret = "Geheimes Squad kaufen       ",
    Hangar_Total_Ach = "",
    Button_Hangar_Recustom = "Squad editieren",
    Hangar_Custom_Locked = "",
    Hangar_Custom_Locked_Title = "",
    Button_Hangar_Start = "Spiel starten",
    Hangar_Random = "",
    Hangar_Select = "",
    Hangar_Achievements = "",

    Ach_Squad = "Squad basiert",
    Ach_Global = "Global",

    Hangar_Custom = "",
    Hangar_Coins = "",
    Hangar_Pilot = "",
    Hangar_Pilot = "",
    Hangar_Traveler = "",
    Hangar_NoAbility = "",
    Hangar_NoTraveler = "",
    Randomized = "",
    Customized = "",
    RandomizedLocked = "",
    No_Weapon = "",

    TipTitle_MechColor = "",
    TipText_MechColor = "",
    TipTitle_MechName = "",
    TipText_MechName = "",
    TipTitle_PilotName = "",
    TipText_PilotName = "",
    TipTitle_PilotMech = "",
    TipText_PilotMech = "",
    TipTitle_HangarMovement = "",
    TipText_HangarMovement = "",
    TipTitle_HangarHealth = "",
    TipText_HangarHealth = "",
    TipTitle_HangarClass = "",
    TipText_HangarClass = "",
    TipTitle_HangarFlying = "",
    TipText_HangarFlying = "",
    TipTitle_HangarArmor = "",
    TipText_HangarArmor = "",

    TipTitle_HangarNormal = "",
    TipText_HangarNormal = "",
    TipTitle_HangarEasy = "",
    TipText_HangarEasy = "",
    TipTitle_HangarHard = "",
    TipText_HangarHard = "",


    TipText_LockedColor = "",
    TipTitle_LockedColor = "",

    TipTitle_Repeat = "",
    TipText_Repeat = "",

    TipTitle_ChaosRoll = "Zuf�llig zuordnen",
    TipText_ChaosRoll = "",

    TipTitle_BalancedRoll = "Ausgeglichen zuordnen",
    TipText_BalancedRoll = "",

    --Options
    Toggle_Fullscreen = "",
    Toggle_Stretch = "",
    Toggle_Timer = "",
    Button_Options_Hotkeys = "Hotkeys bearbeiten",
    Button_Options_Default = "Default Windowed",
    Button_Options_Scale = "Max Board Scale",
    Toggle_Mute = "",
    Toggle_Colorblind = "",
    Toggle_Large = "",
    Toggle_Tips = "",
    Abandon_Confirm = "Du wirst einen Piloten auf eine neue Timeline entsenden und dabei jeden Fortschritt verlieren.",
    Escape_Title = "",
    Escape_Info = "",
    Escape_Sound = "",
    Escape_Music = "",
    Escape_Speed = "",
    Toggle_Confirm = "",
    Escape_Gameplay = "",
    Escape_Video = "",
    Button_Escape_Menu = "HAUPTMEN�",
    Button_Escape_Exit_Editmode = "MAP BEARBEITEN",
    Button_Escape_Exit_Editor = "EDITOR VERLASSEN",
    Button_Escape_Options = "OPTIONEN",
    Button_Escape_Ach = "ERRUNGENSCHAFTEN",
    Button_Escape_Quit = "Speichern und Ende",
    Button_Escape_Abandon = "VERLASSE ZEITLINIE",
    Button_Escape_Continue = "WEITER",

    Mouse_Middle = "",
    Mouse_X1 = "",
    Mouse_X2 = "",

    --Opening Sequence
    Opening_1 = "",
    Opening_2 = "",
    Opening_3 = "",
    Opening_4 = "",
    Opening_5 = "",

    --Game Over
    Button_Victory_Pilot = "PILOT SENDEN",
    Button_Victory_Quit = "HAUPTMEN�",
    Button_Victory_Done = "WEITER",

    --End of Island
    Button_Select_Mission_Leave = "INSEL VERLASSEN",
    Button_Select_Mission_Store = "REPUTATION BENUTZEN",
    Button_Select_Mission_Reward = "REPUTATION ERHALTEN!",

    --Island Stuff
    Island_Environment = "",
    Island_CEO = "",
    Island_Vek = "",
    Island_Boss = "",
    Island_Unlock = "",
    Island_Unlock_Single = "",
    Island_Unlock_Mult = "",
    Island_UnlockTitle = "",

    Island_UnlockTitle = "",
    Island_1 = "",
    Island_2 = "",
    Island_3 = "",
    Island_Text = "",
    Island_Squad = "",

    --Alerts
    Alert_Cleared = "ATTACKE ABGEBROCHEN",
    Alert_Fire = "FEUERSCHADEN",
    Alert_Elec = "ELEKTRISCHER SCHADEN",
    Alert_Blocked = "BLOCKIERTER FEIND",
    Alert_Attacking = "ATTACKIERT NICHT",
    Alert_PodDestroyed = "POD DESTROYED",
    Alert_PodSecured = "POD SECURED",
    Alert_Threat = "BEDROHT",
    Alert_Healed = "EINHEIT REPARIERT",
    Alert_BlobSpawn = "TEILEN UNTERDR�CKT",
    Alert_Regen = "PSION REGENERATION",
    Alert_Tentacle = "PSION ATTACK",
    Alert_Action = "AKTION VERF�GBAR",
    Alert_Level = "LEVEL UP!",
    Alert_Warning = "WARNUNG!",
    Alert_Incoming = "POD INCOMING",
    Alert_Passive = "PASSIVBONUS",
    Alert_Resisted = "WIDERSTANDEN",
    Alert_Power = "ENERGIE VERLOREN",
    Alert_Casualties = "Verluste",
    Alert_Unused = "ENERGIE VERF�GBAR",
    Alert_NoWeapon = "KEINE WAFFE GELADEN",
    Alert_Open = "TOR �FFNEN",
    Alert_Pilot = "PILOT VERF�GBAR",
    Alert_Lost = "REGION VERLOREN",
    Alert_Secured = "REGION GESICHERT",
    Alert_Cores = "KERNE VERF�GBAR",
    Alert_PilotCores = "PILOT & ENERGIE VERF�GBAR",
    Alert_Overflow = "VERTEIDIGUNG RAUF!",
    Alert_FullOverflow = "GRID MAX!",
    Alert_Smoke = "RAUCH BLOCKIERT!",
    Alert_Water = "MECH UNTERGETAUCHT!",
    Alert_NoTarget = "KEIN ZIEL VERF�GBAR!",

    Status_Full = "",

    SquadName_Filler = "",

    TipTitle_Archive_A = "",
    TipText_Archive_A = "",

    TipTitle_Archive_B = "",
    TipText_Archive_B = "",

    TipTitle_Rust_A = "",
    TipText_Rust_A = "",

    TipTitle_Rust_B = "",
    TipText_Rust_B = "",

    TipTitle_Pinnacle_A = "",
    TipText_Pinnacle_A = "",

    TipTitle_Pinnacle_B = "",
    TipText_Pinnacle_B = "",

    TipTitle_Detritus_A = "",
    TipText_Detritus_A = "",

    TipTitle_Detritus_B = "",
    TipText_Detritus_B = "",

    TipTitle_Random = "",
    TipText_Random = "",

    TipTitle_Custom = "",
    TipText_Custom = "",

    TipTitle_Secret = "",
    TipText_Secret = "",

    ---Achievements
    Achievement_Completed = "Abgeschlossen auf Schwierigkeit $1",
    Achievement_Header = "Achievement!",
    Achievement_Header_Pilot = "Pilot gefunden!",
    Achievement_Text_Pilot = "Hangar freigeschalten",

    -----hotkeys
    Mute_Title = "",
    Mute_Description = "",

    Undo_Title = "",
    Undo_Description = "",

    Reset_Title = "",
    Reset_Description = "",

    SelectMech1_Title = "",
    SelectMech1_Description = "",

    SelectMech2_Title = "",
    SelectMech2_Description = "",

    SelectMech3_Title = "",
    SelectMech3_Description = "",

    SelectDeploy1_Title = "",
    SelectDeploy1_Description = "",

    SelectDeploy2_Title = "",
    SelectDeploy2_Description = "",

    SelectDeploy3_Title = "",
    SelectDeploy3_Description = "",

    SelectMission1_Title = "",
    SelectMission1_Description = "",

    SelectMission2_Title = "",
    SelectMission2_Description = "",

    Cycle_Title = "",
    Cycle_Description = "",

    Deselect_Title = "",
    Deselect_Title = "",
    Deselect_Description = "",

    Info_Title = "",
    Info_Description = "",

    Overlay_Title = "",
    Overlay_Description = "",

    Weapon1_Title = "",
    Weapon1_Description = "",

    Weapon2_Title = "",
    Weapon2_Description = "",

    Repair_Title = "",
    Repair_Description = "",

    EndTurn_Title = "",
    EndTurn_Description = "",

    Fullscreen_Title = "",
    Fullscreen_Description = "",


    ---------- CREDITS + VICTORY TEXT

    Credits_Studio = "",
    Credits_StudioName = "",
    Credits_Created = "",
    Credits_CreatedName = "",
    Credits_Music = "",
    Credits_MusicName = "",
    Credits_Sound = "",
    Credits_SoundName = "",

    Credits_SoundSub1 = "",
    Credits_SoundSub1Name = "",

    Credits_SoundSub2 = "",
    Credits_SoundSub2 = "",

    Credits_Writing = "",
    Credits_WritingName = "",
    Credits_Editing = "",
    Credits_EditingName = "",
    Credits_Community = "",
    Credits_CommunityName = "",
    Credits_Portraits = "",
    Credits_PortraitsName = "",
    Credits_Mechs = "",
    Credits_MechsName = "",
    Credits_QA = "",
    Credits_QAName = "",

    Credits_QASub1 = "",
    Credits_QASub1Name = "",
    Credits_QASub2 = "",
    Credits_QASub2Name = "",

    Credits_Testers = "",
    Credits_TestersName = "",
    Credits_Thanks = "",
    Credits_ThanksName = "",
    Credits_ThanksExtra = "",
    Credits_Babies = "",
    Credits_BabiesName = "",
    Credits_FinalThanks = "",

}

function GetText(id)
    if Global_Texts[id] ~= nil then
        return Global_Texts[id]
    end

    if Weapon_Texts[id] ~= nil then
        return Weapon_Texts[id]
    end

    if Achievement_Texts[id] ~= nil then
        return Achievement_Texts[id]
    end

    return "no string found"
end