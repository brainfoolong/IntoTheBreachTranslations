
local Global_Texts = {

-----COMBAT TUTORIAL
    Tutorial_InfoButton_Text = "Wenn du mit neuen Feinden konfrontiert wirst, solltest du dich �ber ihre F�higkeiten informieren. \n\nHalte $1 w�hrend du mit dem Mauszeiger �ber der Einheit bist um sie zu untersuchen",
    Tutorial_InfoButton_Title = "Einheiten untersuchen",

    Tutorial_CombatPower_Text = "Dies ist das Stromnetz. Wenn ein Geb�ude besch�digt wird, wird es reduziert. \n\nWenn es auf Null reduziert ist, verlierst du.",
    Tutorial_CombatPower_Title = "Stromnetz",

    Tutorial_CombatAiming_Text = "Wenn du mit der Waffe zielst, zeigen die ORANGEN Felder, wohin du schie�en kannst.",
    Tutorial_CombatAiming_Title = "G�ltige Ziele",

    Tutorial_CombatMonster_Text = "Jeder feindliche Angriff wird vorgewarnt. Im n�chsten Zug greift dieser die Geb�ude an. \n\nFahre mit der Maus �ber einen Gegner, um Details zu seinem Angriff zu sehen.",
    Tutorial_CombatMonster_Title = "Feindliche Angriffe",

    Tutorial_CombatMech_Text = "Das ist dein Kampfmech. Er kann jedes angrenzende Feld erreichen. \n\nKlicke auf deinen Mech, bewege ihn n�her zum Gegner und sto�e ihn.",
    Tutorial_CombatMech_Title = "Kampf Mech",
	
    Tutorial_DeadTutorial_Title = "Deaktivierter Squad",
    Tutorial_DeadTutorial_Text = "Alle deine Mechs sind deaktiviert. In normalen K�mpfen w�rden die Vek dann ihre Angriffe fortsetzen und die Mission w�rde enden. \n\nF�r dieses Tutorial wurden deine Mechs vollst�ndig repariert.",

    Tutorial_CombatGameover_Text = "Dein Stromnetz wurde auf Null reduziert. Normalerweise w�rde dies bedeuten, dass das Spiel vorbei ist. \n\nDa dies eine Simulation ist, kannst du weiterhin gegen den Vek k�mpfen.",
    Tutorial_CombatGameover_Title = "Spiel ist aus",

    Tutorial_CombatUndo_Text = "Du kannst den Feind nicht von diesem Ort aus treffen. Benutze 'Bewegung zur�cksetzen', um den Mech neu zu positionieren!",
    Tutorial_CombatUndo_Title = "Bewegung zur�cksetzen",

    Tutorial_CombatPunch_Text = "Schlage diesen Feind!",
    Tutorial_CombatPunch_Title = "",

    Tutorial_CombatPush_Text = "Der Schlag Ihres Mechs hat diese Einheit gesto�en. Sie wird jetzt einen neuen Standort angreifen! \n\nSt��e k�nnen Geb�ude vor feindlichen Angriffen sch�tzen oder sogar Gegner einander angreifen lassen.",
    Tutorial_CombatPush_Title = "Feinde sto�en",

    Tutorial_CombatTank_Text = "Das ist dein Panzer Mech. \n\nEr schie�t ein Projektil, das sich in einer geraden Linie bewegt, bis es auf ein anderes Objekt trifft.",
    Tutorial_CombatTank_Title = "Tank Mech",

    Tutorial_CombatComplete_Text = "Bei jeder Mission gewinnst du, indem du die Vek besiegst oder sie bek�mpfst, bis sie sich zur�ckziehen.",
    Tutorial_CombatComplete_Title = "Missionen abgeschlossen",

    Tutorial_CombatBonus_Text = "Missionen haben auch Bonusziele. \n\nDurch das erf�llen erh�ltst du zus�tzliche Ressourcen nach dem Kampf.",
    Tutorial_CombatBonus_Title = "Bonusziele",

    Tutorial_CombatWeapon_Text = "Klicke auf eine Waffe, um sie zu benutzen. Die Zifferntasten funktionieren auch als Schnelltasten. \n\nBewegung ist nach dem abfeuern einer Waffe gesperrt.",
    Tutorial_CombatWeapon_Title = "Waffe nutzen",

    Tutorial_CombatEnd_Text = "Wenn alle deine Mechs eine Aktion ausgef�hrt haben oder nichts mehr f�r deine Einheiten �brig ist, dr�cke diese Taste, um deinen Zug zu beenden.",
    Tutorial_CombatEnd_Title = "Letzter Zug",

--- MISSION TUTORIALS 

    Tutorial_Tanks_Text = "Die Tanks sind online und k�nnen nun kontrolliert werden!",
    Tutorial_Tanks_Title = "Alte Erdtanks",

    Tutorial_Terraform_Text = "Dieser Terraformer steht w�hrend dieser Mission unter deiner Kontrolle. \n\nVerwende ihn, um Gras zu Sand zu machen.",
    Tutorial_Terraform_Title = "Terraformer",

    Tutorial_VolatileVek_Text = "DasBonusziel in dieser Mission ist es, diesen Vek nicht sterben zu lassen.",
    Tutorial_VolatileVek_Title = "Volatiler Vek",

---- STANDARTD TUTORIALS 

--	Tutorial_FinalIsland_Title = "Final Mission",
	--Tutorial_FinalIsland_Text = "You may attempt the Final Mission now that you've completed two Islands. Alternatively, you can continue to secure more Islands. \n\nYour --choice should depend on how long you would like to play this timeline. The difficulty will always scale to your current progress.",
	
    Warning_Final = "Warnung: Diese finale Mission befindet sich noch in der Entwicklung. \n\nSie sollte mehr oder weniger spielbar sein. Viel Gl�ck!",
	
    Warning_OldSave = "Warnung: Diese Sicherungsdatei wurde von einer fr�heren Version von Into the Breach erstellt. \n\nDa das Spiel noch in der Entwicklung ist, kann ich nicht die volle R�ckw�rtskompatibilit�t f�r jedes Update garantieren und es k�nnen Probleme mit dieser Speicherung auftreten. \n\nDas hei�t, die Chancen stehen gut, dass Sie keine Probleme haben werden. Entschuldige die m�glichen Probleme!",

    Tutorial_PoweredPilot_Title = "Betriebener Pilot",
    Tutorial_PoweredPilot_Text = "Dieser Pilot ist eine intelligente Maschine und ben�tigt Reaktorenergie, um seine Spezialf�higkeit zu aktivieren.",

    Tutorial_Acid_Title = "S�ure",
    Tutorial_Acid_Text = "Diese Einheit wird mit S�ure befallen. Wenn die Verteidigung korrodiert ist, wird der ankommende Waffenschaden verdoppelt.\n\nAlle anderen Sch�den (Sto�, Feuer, Blocken usw.) sind davon nicht betroffen.",

    Tutorial_Frozen_Text = "Diese Einheit ist GEFROREN. Sie kann sich nicht bewegen oder angreifen und bleibt solange eingefroren bis es Schaden nimmt.",
    Tutorial_Frozen_Title = "Gefrorene Einheit",

    Tutorial_Frozen_Mech_Text = "Dieser Mech kann seine Reparaturfertigkeit nutzen, um sich selbst vom Eis zu befreien, aber ansonsten kann er nicht angreifen oder sich bewegen.",
    Tutorial_Frozen_Mech_Title = "Gefrorener Mech",
	
    Tutorial_Shield_Title = "Energieschilde",
    Tutorial_Shield_Text = "Dies ist ein Schild. Es wird Schaden und irgendwelche negativen Effekte (Feuer, Einfrieren, S�ure, usw.) blockieren. \n\nNur direkter Schaden entfernt den Schild. Nicht sch�digende negative Effekte haben keine Auswirkungen.",
	
    Tutorial_Armor_Title = "Gepanzerte Einheit",
    Tutorial_Armor_Text = "Diese Einheit ist gepanzert. Der gesamte ankommende Waffenschaden wird um 1 verringert.\n\nAlle anderen Sch�den (Sto�, Feuer, Blocken usw.) sind davon nicht betroffen.",

    Tutorial_Environment_Text = "Diese Mission hat einen besonderen Effekt, der in jedem Zug gilt. \n\nMauszeiger �ber das Umgebungssymbol, um weitere Informationen zu erhalten.",
    Tutorial_Environment_Title = "Umgebungseffekt",

    Tutorial_PowerGrid_Text = "Das Stromnetz verbindet jede Firmeninsel. Jeglicher Schaden, der bei Missionen entsteht, bleibt bestehen. \n\nDer Vek verursachte vor deiner Ankunft Schaden, aber es gibt M�glichkeiten, ihn es wiederherzustellen.",
    Tutorial_PowerGrid_Title = "Besch�digtes Stromnetz",

    Tutorial_Overpower_Text = "Wenn das Stromnetz voll ist, wenn es zus�tzliche Energie erh�lt, wird die Verteidigung dauerhaft erh�ht.",
    Tutorial_Overpower_Title = "�berlastetes Netz",
	
    Tutorial_FullOverpower_Text = "Du kannst dein Stromnetz nur �berlasten um zus�tzliche +25 Verteidung zu erhalten.",
    Tutorial_FullOverpower_Title = "Verteidigung maximiert",

    Tutorial_GridDefense_Text = "Dieses Geb�ude widersteht Sch�den! \n\nDie Chance eines Geb�udes, das einem Schaden standhalten kann, wird rechts neben der Stromleiste angezeigt.",
    Tutorial_GridDefense_Title = "Verteidung",

    Tutorial_Jelly_Text = "Dieser feindliche Psion bietet allen Vek einen passiven Bonus. Wenn du es t�test, wird der Bonus entfernt. \n\nW�hle Psion und fahre mit der Maus �ber sein Portr�t unten links f�r weitere Informationen.",
    Tutorial_Jelly_Title = "Vek Psion",

    Tutorial_Webbed_Text = "Diese Einheit wurde Festgebunden \n\n�ber die Statussymbole unten links nachsehen, was das bedeutet.",
    Tutorial_Webbed_Title = "Festgebundener Mech",

    Tutorial_IslandNewGame_Text = "Du kannst die Inseln, die du freigeschaltet hast, in beliebiger Reihenfolge versuchen. \n\nDie Schwierigkeit von Vek wird abh�ngig davon skaliert, wie viele Inseln du in diesem Spiel absolviert hast.",
    Tutorial_IslandNewGame_Title = "Firmeninseln",

    Tutorial_Spawning_Text = "Eine feindliche Einheit wird hier im n�chsten Zug auftauchen! \n\nDu kannst Feinde vor�bergehend vom Spawnen abhalten, aber es wird die Einheit, die blockiert, besch�digt.",
    Tutorial_Spawning_Title = "Auftauchende Feinde",

    Tutorial_Forest_Text = "Der WALD auf diesem Feld hat Schaden genommen und ihn in Brand gesetzt. \n\nWenn eine Einheit in Brand steht, wird sie sich entz�nden und in jedem Zug Schaden nehmen.",
    Tutorial_Forest_Title = "Brennende W�lder",

    Tutorial_Fire_Text = "Dieser Mech brennt! Es wird in jedem Zug Schaden verursachen. \n\nMechs k�nnen Statuseffekte REPARIEREN, k�nnen aber im selben Zug angreifen, in dem sie sich reparieren.",
    Tutorial_Fire_Title = "Brennende Mechs",

    Tutorial_DamagedMech_Text = "Eure Mechs reparieren automatisch alle Sch�den nach dem Kampf. \n\nWenn ein Mech auf 0 Gesundheit reduziert wird, stirbt der Pilot und der Mech wird f�r den Rest dieses Kampfes deaktiviert.",
    Tutorial_DamagedMech_Title = "Besch�digte Mechs",

    Tutorial_Corroded_Text = "Dieser Mech wurde mit S�ure �bergossen! Es korrodiert die R�stung der Einheit, wodurch alle eingehenden Sch�den verdoppelt werden. \n\nMechs k�nnen Statuseffekte REPARIEREN, k�nnen aber nicht im selben Zug angreifen in dem sie sich reparieren.",
    Tutorial_Corroded_Title = "Mit S�ure behaftete Mechs",

    Tutorial_Pod_Text = "Dieser Pod enth�lt Ausr�stung aus der Zukunft! \n\nDu kannst es mit deinem Mech sammeln oder einfach bis zum Ende des Kampfes verteidigen.",
    Tutorial_Pod_Title = "Time-Pods",

    Tutorial_PodDestroyed_Title = "Zerst�rte Time-Pods",
    Tutorial_PodDestroyed_Text = "Der Time-Pod auf diesem Feld wurde zerst�rt \n\nTime Pods werden zerst�rt, indem sie Schaden erleiden oder wenn ein Gegner darauf steht.",
		
    Tutorial_Water_Text = "Mechs k�nnen ihre Waffen nicht benutzen, wenn sie im Wasser stehen.",
    Tutorial_Water_Title = "Schwimmroboter",
	
    Tutorial_WaterUndo_Text = "Mechs k�nnen ihre Waffen nicht benutzen, wenn sie im Wasser stehen. \n\nDu kannst 'Bewegung r�ckg�ngig machen' verwenden, wenn Sie es neu zu positionieren.",
    Tutorial_WaterUndo_Title = "Schwimmroboter",

    Tutorial_DeadPilot_Text = "Dein Mech war deaktiviert! Sein Pilot wurde get�tet und er wird f�r den Rest der Mission nicht in der Lage sein, zu handeln.",
    Tutorial_DeadPilot_Title = "Deaktivierte Mechs",

    Tutorial_Drowning_Text = "Diese Einheit fiel ins Wasser und wurde sofort get�tet!",
    Tutorial_Drowning_Title = "Ertrinkende Einheit",

    Tutorial_PushDamage_Text = "Einheiten in andere Objekte sto�en f�gt beiden 1 zus�tzlichen Schaden zu!",
    Tutorial_PushDamage_Title = "In Objekte sto�en",

    Tutorial_PushDeath_Text = "Einheiten in andere Objekte sto�en f�gt beiden 1 zus�tzlichen Schaden zu! \n\nIn diesem Fall hat der zus�tzliche Schaden die Einheit get�tet!",
    Tutorial_PushDeath_Title = "In Objekte sto�en",

    Tutorial_BuildingDamage_Text = "Dieses Geb�ude wurde besch�digt, daher wurde Ihr Stadt Stromnetz reduziert. \n\nDas prim�re Ziel ist, dies zu verhindern!",
    Tutorial_BuildingDamage_Title = "Geb�udeschaden",

    Tutorial_Combat_Title = "Kampfsimulation",
    Tutorial_Combat_Text = "Es gibt eine Kampfsimulation, um neue Kommandanten mechanisierten K�mpfe zu erleichtern. \n\nM�chtest du die Simulation starten?",

    Tutorial_Money_Title = "Firmenreputation",
    Tutorial_Money_Text = "Wenn Regionen sicherst und Bonusziele erf�llst, wird die Reputation bei den lokalen Firmen steigen. \n\n Du kannst am Ende der Insel Reputation f�r Equipment ausgeben.",

    Tutorial_Cores_Title = "Reaktorkerne",
    Tutorial_Cores_Text = "Du hast jetzt einen Reaktorkern! �ffne den Upgrade-Bildschirm eines Mechs und installiere ihn.",

    Tutorial_Cores2_Title = "Kerninstallation",
    Tutorial_Cores2_Text = "Du kannst diesen Button verwenden, um Reaktorkerne in einem Mech zu installieren. \n\nJeder Kern erh�ht die maximale Reaktorenergie eines Mechs um eins.",

    Tutorial_Cores3_Title = "Waffenmodifikationen",
    Tutorial_Cores3_Text = "Du kannst die Reaktorenergie verwenden, um Waffenmodifikationen zu aktivieren. \n\nKlicke auf eine Mod, um sie zu aktivieren. Du kannst klicken, um die Energie wieder zu entfernen, wenn du sie woanders verwenden willst.",

    Tutorial_Weapon_Title = "Neue Waffe",
    Tutorial_Weapon_Text = "Du hast gerade eine neue Waffe bekommen! Du kannst sie im Upgrade-Bildschirm ausr�sten.",

    Tutorial_Pilot_Title = "Neuer Pilot",
    Tutorial_Pilot_Text = "Du hast gerade einen neuen Piloten erhalten! Im Upgrade-Bildschirm zuweisen.",
	
	---Beta warning for squad unlock change
	
    Tutorial_OldProfile_Title = "Altes Profil",
    Tutorial_OldProfile_Text = "Das Spiel wurde aktualisiert und �ltere Beta-Profile k�nnen nach diesen �nderungen auf einige Kuriosit�ten sto�en. \n\nDeine Errungenschaten Coins k�nnten jetzt aufgrund von Preis�nderungen zuvor freigeschalteter Mechs negativ sein. Das Spiel funktioniert, du brauchst nur mehr Erfolge, um die Gewinnzone zu erreichen.\n\nWenn du gerade ein Spiel laufen hast, wird es m�glicherweise nicht korrekt geladen. Ich hoffe, es funktioniert immer noch, aber ich entschuldige mich, wenn es nicht funktioniert.",
		
	---Tutorial Large Screens
    Tutorial_Weapons = "WAFFENEFFEKTE",
    Tutorial_WeaponsText = "Wenn du mit einer Waffe zielst oder einen feindlichen Angriff untersuchst, zeigen die Symbole genau, was passieren wird.",
    Tutorial_Weapons_Push = "STOSSEN",
    Tutorial_Weapons_PushText = "Ein Pfeil auf einem Feld bedeutet, dass eine Einheit auf dieses Feld gesto�en wird",
    Tutorial_Weapons_Damage = "SCHADEN",
    Tutorial_Weapons_DamageText = "Eine Zahl auf einem Feld bedeutet, dass die Einheit auf diesem Feld besch�digt wird",
    Tutorial_Weapons_PushDamage = "STOSSEN + SCHADEN",
    Tutorial_Weapons_PushDamageText = "Manche Waffen k�nnen mehrere Effekte auf einem einzigen Feld verursachen",
	
    Tutorial_Art = "ARTILLERIE MECH",
    Tutorial_ArtText = "Artilleriewaffen k�nnen �ber Hindernisse wie Berge schie�en, daf�r aber nicht auf angrenzende Felder.",
    Tutorial_ArtExtra = "Die Waffe des Artillerie-Mechs besch�digt nur Einheiten auf dem mittlerem Feld, w�hrend Einheiten auf angrenzenden Feldern gesto�en werden.",
	
    Tutorial_Rewards = "MISSIONSBELOHNUNG",
    Tutorial_RewardsText = "Jede Mission hat verschiedene potentielle Belohnungen f�r das Erreichen von Bonuszielen. \n    Du wirst nicht in der Lage sein, jede Mission auf der Insel zu machen, also w�hle sorgf�ltig!",
    Tutorial_Rewards_Cores = "Energiekerne: Wird benutzt, um deine Mechs zu verbessern.",
    Tutorial_Rewards_Power = "STROMNETZ: Stellt das Stromnetz wieder her. \nWenn dein Stromnetz Null erreicht, verlierst du.",
    Tutorial_Rewards_Reputation = "FIRMENREPUTATION: Verwendet, um Gegenst�nde zu kaufen, sobald die Insel sicher ist.",
    Tutorial_Rewards_Difficulty = "ACHTUNG: Missionen mit mehr potentieller Belohnung haben zus�tzliche Gefahren!",
    Tutorial_RegionName = "Safeguard Valley",
	
    Tutorial_Final = "FINAL MISSION",
    Tutorial_FinalText = "Nach der Sicherung von zwei Firmeninseln kann die finale Mission abgeschlossen werden.",
    Tutorial_Final_ScalingTitle = "Schwierigkeit",
    Tutorial_Final_Scaling = "Die Schwierigkeit dieses Kampfes skaliert zu deinem aktuellen Fortschritt. Jetzt zu k�mpfen, wird genauso eine Herausforderung sein, wie wenn es nach der Sicherung weiterer Inseln versucht wird",
    Tutorial_Final_ScoringTitle = "Zivilisten",
    Tutorial_Final_Scoring = "Sichere mehr Inseln vor der finalen Mission um mehr Zivilisten zu retten und deine Punktzahl zu erh�hen.",
	
    Tutorial_StartCombat = "Starte die Simulation",
    Tutorial_DeclineCombat = "Ablehnen",
    Tutorial_DeclineAll = "Nein, ich wei�, was ich mache (alle zuk�nftigen Tutorial-Tipps ausblenden)",
	
    Tutorial_Dismiss = "(Klicken um zu Verwerfen)",
	
	--tooltips
    TipTitle_FinalMission = "Finale Mission",
    TipText_FinalMission = "Du kannst die Endmission zu jedem Zeitpunkt abschlie�en, nachdem du zwei Firmneninseln gesichert hast.\n\nDie Schwierigkeit der Mission skaliert zu deinem aktuellen Fortschritt.",

	
    TipTitle_Reputation = "Firmenreputation",
    TipText_Reputation = "Benutze Reputation, um Nachschub zu kaufen, sobald eine Insel gesichert ist.",
    TipTitle_Cores = "Reaktorkerne",
    TipText_Cores = "Wird f�r das Upgrade von Mechs verwendet. \n\n�ffne den Mech-Upgrade-Bildschirm, indem du auf ein beliebiges Mech-Symbol auf der linken Seite klickst.",
	
    TipTitle_Order = "Angriffsfolge",
    TipText_Order = "Bewege die Maus hier hin oder halte ALT gedr�ckt, um die Reihenfolge anzuzeigen, in der die Feinde angreifen.",
    TipText_Menu = "Spielmen� [ESC]",
    TipTitle_Menu = "�ffne das Spielmen�",
	
    TipText_Overlay = "Zeigt die Reihenfolge an, in der die Aktionen w�hrend des gegnerischen Zuges ausgef�hrt werden. Schnelltaste: [$1]",
    TipTitle_Overlay = "Angriffsfolge",
	
    TipText_TimerBattle = "Wie lange spielst du gerade dein aktuelles Spiel? \n\nDu kannst dies im Men� Optionen ausblenden.",
    TipTitle_TimerBattle = "Spielzeit",
	
    TipText_ResetTurn = "Gehe zur�ck in der Zeit bis zum Beginn des aktuellen Zuges. Verf�gbar nach mindestens einer Aktion. \n\nDu kannst das nur einmal pro Kampf tun.",
    TipTitle_ResetTurn = "Zug zur�ck",
	
    TipText_ResetTurnUsed = "Du kannst das nur einmal pro Kampf benutzen.",
    TipTitle_ResetTurnUsed = "Benutzte Z�ge zur�cksetzen",
	
    TipText_ResetTurnExtra = "Gehe zur�ck in der Zeit bis zum Beginn des aktuellen Zuges. Verf�gbar nach mindestens einer Aktion. \n\nDein Pilot 'Temporaler Reset' gibt dir einen zus�tzlichen Reset pro Kampf. Du hast 2 �brig.",
    TipTitle_ResetTurnExtra = "Zug zur�ck",
	
    TipText_ResetTurnFinal = "Gehe zur�ck in der Zeit bis zum Beginn des aktuellen Zuges. Verf�gbar nach mindestens einer Aktion. \n\nDu hast nur noch einen Reset.",
    TipTitle_ResetTurnFinal = "Zug zur�ck",
	
    TipText_CombatSpeed = "�ndert, wie schnell gegnerische Einheiten am Zug sind. \n\nVerlangsame es wenn du ein neuer Spieler bist um den Aktionen besser folgen zu k�nnen. Mit der Zeit kannst du es schneller einstellen.",
    TipTitle_CombatSpeed = "Kampfgeschwindigkeit",
	
    TipText_Abandon = "Beende den Versuch und sende einen Pilot zur�ck, um es erneut zu versuchen.",
    TipTitle_Abandon = "Zeitlinie verlassen",
	
    TipTitle_TutorialTips = "Tutorial Tipps",
    TipText_TutorialTips = "Zeigen Sie w�hrend des Spiels relevante Tutorial-Popups an. \n\nEmpfehlenswert f�r neue Spieler.",
	
    TipTitle_BoardScale = "Max. Boardskala",
    TipText_BoardScale = "Maximale Skalierung das Kampfboards anpassen.\n\nDies kann n�tzlich sein, um die Skalierung f�r gr��ere Monitore zu verringern.\n\nDie Standardskalierung f�r das aktuelle Fenster ist: $1",
	
    TipTitle_DefaultRes = "Standardfenster",
    TipText_DefaultRes = "Stellen Sie das Spiel auf seinem Standard 720p-Fenster wieder her. Empfohlen f�r das Streaming.",
	
    TipTitle_AudioMuted = "",
    TipText_AudioMuted = "Ton ist derzeit stummgeschaltet",
		
    TipTitle_Timer = "Spieltimer UI",
    TipText_Timer = "F�ge Spieltimer zur Benutzeroberfl�che hinzu. \n\nHilfreich f�r Speedrunning oder den 'Blitzkrieg' Erfolg",
	
    TipTitle_Colorblind = "Farbenblinder Modus",
    TipText_Colorblind = "�ndert einige Farben und f�gt zus�tzliche Symbole hinzu, um farbblinde Spieler zu unterst�tzen. \n\nLass uns wissen, ob du etwas verbessert haben m�chtest.",
	
    TipTitle_LargeFont = "Gr��ere Schriftarten",
    TipText_LargeFont = "Erh�ht die Gr��e von QuickInfos, Dialogen und anderen kritischen Texten.",
	
    TipTitle_NoLargeFont = "Gr��ere Schriftarten nicht verf�gbar",
    TipText_NoLargeFont = "Ihre aktuelle Fensteraufl�sung ist zu klein, um gr��ere Schriftarten zu unterst�tzen.",
	
    TipTitle_Confirm = "Best�tigung Zugende",
    TipText_Confirm = "Erhalte eine Best�tigung, wenn du versuchst, deinen Zug zu beenden und Einheiten noch zum agieren verf�gbar sind.",
	
    TipTitle_Stretch = "Stretch-Skalierung",
    TipText_Stretch = "Stretche Bilder und UI f�r Anpassung an gr��ere Aufl�sungen. \n\nHilfreich f�r 1440p oder mehr , wenn die Benutzeroberfl�che zu klein ist, aber Bilder und Text m�glicherweise etwas unscharf werden.",
	
    TipTitle_Limit = "Frame Limit",
    TipText_Limit = "Limitiere FPS zu 60\n\nEmpfohlen f�r die meisten Systeme.",
	
    TipTitle_Shake = "Deaktiviere Screen Shake",
    TipText_Shake = "Verhindere das sch�tteln des Boards / UI.\n\nPassiert meistens im Kampf wenn etwas Schaden macht.",
	
    TipTitle_Coords = "Gitterkoordinaten Overlay",
    TipText_Coords = "F�gt Board Koordinaten hinzu.\n\nGut f�r Streaming oder bei anderen Formen des Sharings.",
	
    TipTitle_NoStretch = "Stretch Skalierung nicht verf�gbar",
    TipText_NoStretch = "Ihre Videotreiber unterst�tzen die daf�r notwendigen Voraussetzungen nicht. \n\nBitte aktualisieren Sie oder wenden Sie sich an den Support, wenn Sie diese Funktion ben�tigen.",
	
    TipTitle_BattleVictory = "Kampfsieg",
    TipText_BattleVictory = "Alle Gegner werden sich in $1 Z�gen zur�ckziehen",
    TipText_BattleVictory_One = "Alle Gegner werden sich in einem Zug zur�ckziehen",
	
    TipTitle_BattleVictory_Final = "Letzter Sieg",
    TipText_BattleVictory_Final = "Die Bombe explodiert in $1 Z�gen",
    TipText_BattleVictory_One_Final = "Die Bombe wird im n�chsten Zug explodieren",
	
    TipTitle_RepObj = "Reputationsziel",
    TipText_RepObj = "Gew�hrt Firmenreputation, wird benutzt um Equipment zu kaufen.",
    TipTitle_PodObj = "Time-Pod",
    TipText_PodObj = "Der Inhalt eines Time-Pods k�nnte f�r die bevorstehenden K�mpfe n�tzlich sein.",
    TipTitle_PowerObj = "Leistungsziel",
    TipText_PowerObj = "Stellt die Stromversorgung des Stromnetzes wieder her",
    TipTitle_CoreObj = "Reaktorkern Ziel",
    TipText_CoreObj = "Ein Reaktorkern als Belohnung, mit dem Mechs aufger�stet werden.",
    TipTitle_Saved = "Gerettete Menschen",
    TipText_Saved = "Die Anzahl der Personen, die du in dieser Zeitlinie gespeichert hast \n\nH�here Schwierigkeiten haben mehr Menschen pro Geb�ude im Kampf.",
    TipTitle_UpgradeReactor = "Mech-Reaktor",
    TipText_UpgradeReactor = "Du kannst die Reaktorenergie nutzen, um deine Waffen zu verbessern oder zus�tzliche Waffen zu aktivieren. \n\nReaktorkerne installieren, um den Reaktor eines Mechs zu verbessern.",
    TipTitle_UndoCore = "Kerninstallation r�ckg�ngig machen",
    TipText_UndoCore = "Aktuelle Core-Installationen r�ckg�ngig machen.",
    TipTitle_Health = "Mech Gesundheit",
    TipText_Health = "",
    TipTitle_Move = "Mech-Bewegung",
    TipText_Move = "",
	
    TipTitle_ZoltanHealth = "Zoltans Gesundheit",
    TipText_ZoltanHealth = "Der Zoltan Pilot verhindert, dass die HP dieses Mechs erh�ht wird",
	
    TipTitle_MechClass = "Mech-Klasse",
    TipText_MechClass = "Die Mech-Klasse bestimmt, welche Waffenarten sie effizient einsetzen kann. \n\nWaffen, die nicht in derselben Klasse sind, kosten 1 zus�tzliche Reaktorenergie.",
	
    TipTitle_Cyborg = "Cyborg-Klasse",
    TipText_Cyborg = "Cyborgs ben�tigen 1 zus�tzliche Reaktorenergie, um alle Nicht-Cyborg-Waffen oder Passive einzusetzen.",
	
    TipText_RenamePilot = "Klicken um diesen Pilot umzubenennen.",
    TipTitle_RenamePilot = "Pilot umbenennen",
    TipText_RenameMech = "Klicken um diesen Mech umzubenennen.",
    TipTitle_RenameMech = "Mech umbenennen",
	
    TipTitle_PilotMax = "Maximales Level",
    TipText_PilotMax = "Dieser Pilot hat alle seine F�higkeiten freigeschaltet!",
    TipTitle_PilotExperience = "Pilot Erfahrung",
    TipText_PilotExperience = "Sobald dieser Pilot genug Erfahrung im Kampf gesammelt hat, werden mehr Fertigkeiten freigeschaltet.",
    TipTitle_PilotAI = "Normaler KI Pilot",
    TipText_PilotAI = "Grundlegende KI-Piloten arbeiten bereits mit maximaler Effizienz und erhalten keine Erfahrung im Kampf. \n\nFinde �berlegene menschliche Piloten oder fortgeschrittene KI-Piloten, um die grundlegende KI zu ersetzen.",
	
    TipText_GridDefense = "Die prozentuale Chance, dass ein Geb�ude einem Schaden standh�lt. \n\nHol dir Energie, wenn dein Stromnetz voll ist, um seine Verteidigung zu verbessern.",
    TipTitle_GridDefense = "Verteidung",
    TipText_PowerGrid = "Du verlierst, wenn dies Null erreicht. \n\nReduziert sich jedes Mal, wenn ein Geb�ude mit Strom im Kampf besch�digt wird.",
    TipTitle_PowerGrid = "Stromnetz",
	
    TipTitle_BuyCore = "Reaktorkern",
    TipText_BuyCore = "Reaktorkerne werden verwendet, um deine Mechs zwischen den Missionen zu verbessern.",
    TipTitle_BuyPower = "Netzleistung",
    TipText_BuyPower = "Repariere Sch�den an deinem Stromnetz. \n\nWenn das Stromnetz voll ist, wird es die Verteidigung dauerhaft erh�hen.",
	
    TipTitle_BuyPower_Grid = "�berlaste Netzleistung",
    TipText_BuyPower_Grid = "Dein Stromnetz ist voll. Zus�tzliche Energie wird die Verteidigung permanent verbessern. \n\nDer Bonus verringert sich, je h�her der Verteidigung ist, bis zu einem Maximum von +25.",
	
    TipTitle_BuyPower_Full = "Volle Netzleistung",
    TipText_BuyPower_Full = "Das Stromnetz und die Verteidigung haben beide ihren maximalen Wert. \n\nDu kannst keine zus�tzliche Energie kaufen.",
	
    TipTitle_Mission_Normal = "Standard Vek Bedrohung",
    TipText_Mission_Normal = "Keine speziellen Zus�tze f�r diese Mission",
    TipTitle_Mission_Hard = "Hohe Vek Bedrohung",
    TipText_Mission_Hard = "Ein zus�tzlicher Alpha Vek wird beim Start der Mission anwesend sein",
    TipTitle_Mission_Easy = "Verteidigungsgitter aktiv",
    TipText_Mission_Easy = "Einige Geb�ude beginnen mit einem kostenlosem Schild",
	
	------ ENVIRONMENTS ---------
	
    TipTitle_Env_BeltLine = "F�rderb�nder",
    TipText_Env_BeltLine = "F�rderb�nder werden die Einheiten auf der Karte verschieben",
    TipTitle_Env_BeltRandom = "F�rderb�nder",
    TipText_Env_BeltRandom = "F�rderb�nder werden die Einheiten auf der Karte verschieben",
    TipTitle_Env_Airstrike = "Luftschl�ge",
    TipText_Env_Airstrike = "Ein Bomber zielt regelm��ig auf Bereiche der Karte",
    TipTitle_Env_Tides = "Flutwellen",
    TipText_Env_Tides = "Die Karte wird nach und nach mit Wasser �berflutet",
    TipTitle_Env_Cataclysm = "Kataklysmische Erdbeben",
    TipText_Env_Cataclysm = "Die Karte wird sich allm�hlich in eine massive Kluft aufl�sen",
    TipTitle_Env_Seismic = "Seismische Aktivit�t",
    TipText_Env_Seismic = "Felder versinken regelm��ig in und ziehen Einheiten in die Tiefe",
    TipTitle_Env_Lightning = "Gewitter",
    TipText_Env_Lightning = "Gef�hrliche Blitze werden die Karte bedrohen und alles t�ten, was sie treffen",
    TipTitle_Env_SnowStorm = "Eissturm",
    TipText_Env_SnowStorm = "Gro�e Bereiche der Karte werden regelm��ig einfrieren",
	
	---------- Island Descriptions
	
		
    Corp_Grass_Description = "Diese Museumsinsel stellt die alte Erde so wieder her, wie sie war, bevor die Ozeane stiegen und die Menschheit beinahe ausl�schten.",
    Corp_Desert_Description = "Terraforming-Spezialisten, R. S. T. nutzten ihre Umwelt gegen die Vek und zerst�rte dabei fast ihre Insel.",
    Corp_Snow_Description = "Pinnacle Robotics k�mpft Krieg an zwei Fronten, einen gegen die Vek, den anderen gegen seine eigenen f�hlenden Waffen.",
    Corp_Factory_Description = "Detritus Tech kann jede Materie in ihre Basiselemente zerlegen. Ihre Fabrikst�dte sind der M�llentsorgung und dem Recycling gewidmet.",
	
	--Order Texts
    Order_Fire = "Feuerschaden",
    Order_Psion = "Psion regenerieren",
    Order_Tentacle = "Psion Tentakel",
    Order_Actions = "Feindliche Aktionen",
    Order_NPC = "NPC-Aktionen",
    Order_NPC_Bots = "NPC Bot Aktionen",
    Order_Emerge = "Feinde treffen ein",
    Order_Env = "Umgebung",
    Order_Smoke = "Sturm Rauch",
	
	---Combat Texts
    Deploying_Mech = "Bereitstellung von $1",
    Deploying_Instructions = "W�hle einen Ort in der gelben Dropzone",
    Deploying_Complete = "Aufstellung abgeschlossen",
    Deploying_Confirm = "Du kannst deine Platzierungen noch vor dem best�tigen �ndern",
    Combat_Deployment = "EINSATZ",
    Deploy_Remaining = "Restliche Einheiten:",
    Button_Deployment_Done = "BEST�TIGEN",
    Button_Button_Pawnlist = "     Einheitenliste",
    Button_Button_Objectives = "Bonusziele     ",
	
    Skip_Units = "Du hast noch Einheiten die agieren k�nnen. Sie werden ihren Zug auslassen.",
    Reset_Turn = "Geh zur�ck in die Zeit bis zum Start deines Zuges?\n\nEnergielimits bedeuten, dass du das nur einmal pro Kampf tun kannst.",
    Reset_TurnExtra = "Geh zur�ck in die Zeit bis zum Start deines Zuges?\n\nDein 'Temporaler Reset' Pilot bedeutet, dass du das zweimal in diesem Kampf machen kannst.",
    Reset_TurnFinal = "Geh zur�ck in die Zeit bis zum Start deines Zuges?\n\nDu hast nur noch einen Reset.",
    Button_EndTurn = "Letzter Zug",
    Button_Undo = "BEWEGUNG \nR�CKG�NGIG",
    Button_UndoTurn = "ZUG ZUR�CKSETZEN",
    Button_UndoTurnUsed = "VERBRAUCHT ZUR�CKSETZEN",
	
    Active_Units = "Aktive Einheiten: ",
	
    Objective_EnemyRetreat = "Sieg in",
    Objective_EnemyRetreat2 = "runden",
    Objective_EnemyRetreat3 = "runde",
	
    Button_Editor_Exit = "MAP BEARBEITEN",
    Button_Done_Testing = "TEST ABGESCHLOSSEN",
	
    Disarm_Info = "[ Rechtsklick ] \noder \n [ $1 ] \nzum Entwaffnen",
	
	-- Skill Info
    Skill_Passive = "PASSIV",
    Skill_ClassAny = "Irgendetwas",
    Skill_ClassTechnoVek = "Cyborg",
    Skill_ClassPassive = "Passiv",
    Skill_ClassPrime = "Prime",
    Skill_ClassDeath = "Im Todesfall",
    Skill_ClassBrute = "Rohe Gewalt",
    Skill_ClassRanged = "Fernkampf",
    Skill_ClassScience = "Wissenschaft",
    Skill_ClassEnemy = "Feind",
    Skill_ClassString = "$1 Klassenwaffe",
    Skill_ClassPassString = "Passiver Effekt",
    Skill_Damage = "Besch�digung: ",
    Skill_SelfDamage = "Eigenschaden: ",
    Skill_Limited = "Verwendet pro Kampf: ",
	
    Skill_WrongClass = "�Keine passende Mech-Klasse. \n 1 Energie Strafe gilt.",
    Skill_CyborgOnly = "Nicht-Cyborg-Waffe",
	
	--- Pilot Info
    Pilot_Special = "Besonders",
    Pilot_PowerReq = "Ben�tigt $1 Energie",
    Pilot_Powered = "Angetrieben",
    Pilot_None = "Keiner",
    Pilot_Max = "Maximales Level",
    Pilot_XP = "$1 / $2 xp",
    Pilot_Unknown = "Unbekannte F�higkeit",
    Pilot_UnknownText = "Sammle Erfahrung, um diese F�higkeit freizuschalten.",
    Pilot_Skills = "F�higkeiten",
    Pilot_Experience = "Erfahrung",
    Pilot_History = "Geschichte",
    Pilot_History_Timelines = "Vorherige Zeitleisten: $1",
    Pilot_History_Final = "Finalk�mpfe: $1",
	
    Pilot_HealthName = "Gesundheitsbonus",
    Pilot_HealthShort = "+2 Mech HP",
    Pilot_HealthDesc = "Pilotierte Mech-Gesundheit wird um 2 erh�ht.",
	
    Pilot_MoveName = "Bonus verschieben",
    Pilot_MoveShort = "+1 Mech Bewegung",
    Pilot_MoveDesc = "Pilotierte Mech-Bewegung wird um 1 erh�ht.",
	
    Pilot_GridName = "Gitter-Verteidigungsbonus",
    Pilot_GridShort = "+3 Gitter DEF",
    Pilot_GridDesc = "Gitter Verteidigung um 3 erh�ht. Dies wirkt sich auf die Chance aus, im Kampf Geb�udeschaden zu widerstehen.",
	
    Pilot_ReactorName = "Reaktor Bonus",
    Pilot_ReactorShort = "+1 Mech Reaktor",
    Pilot_ReactorDesc = "Pilotierter Mech Reaktor um 1 erh�ht.",
	
    Pilot_XpString = "$1 / $2 xp",
    Pilot_XpMax = "Maximales Level",
    Pilot_XpAI = "Mechs k�nnen sich selbst steuern, aber es ist besser, einen spezialisierten Piloten zu haben.",
	
	-- Gamepad instructions`
    Gamepad_SelectUnit = "W�hle Einheit",
    Gamepad_PlaceUnit = "Einheit platzieren",
    Gamepad_MoveUnit = "Einheit verschieben",
    Gamepad_FireWeapon = "Feuerwaffe",
    Gamepad_Cancel = "Schuss abbrechen",
	
	--Combat State Labels
    State_Tutorial = "SIMULATION BEGINNT",
    State_Gameover = "SPIEL IST AUS",
    State_Player = "SPIELER AM ZUG",
    State_Enemy = "FEIND AM ZUG",
    State_Start = "MISSION STARTET",
    State_Complete = "MISSION KOMPLETT",
    State_Disabled = "MECHS DEAKTIVIERT",
    State_Turns = "$1 Zuege noch",
    State_LastTurn = "Fertig",
	
	--Upgrade Screen
	
    Upgrade_MoveLabel = "+1 Bewegung",
    Upgrade_HealthLabel = "+2 Gesundheit",
    Upgrade_Install = "INSTALLIEREN",
    Upgrade_Max = "MAXIMIERT",
    Upgrade_Class = "Mech-Klasse: $1",
    Upgrade_Test = "Verwenden den virtuellen Simulator, um Mech Loadouts zu testen",
    Upgrade_Armory = "LAGER",
    Upgrade_Pilot = "PILOT",
    Upgrade_Stats = "STATISTIKEN",
    Upgrade_Reactor = "REAKTOR",
    Upgrade_Move = "Bewegung:",
    Upgrade_Health = "Gesundheit:",
    Upgrade_Weapons = "WAFFEN",
    Button_Upgrade_Test = "MECH TESTEN",
    Button_Upgrade_Undo = "ZUR�CKSETZEN",
    Wrong_Cost = "Kosten eine zus�tzliche \n          Energie um es zu benutzen",
    Wrong_Class = "Falsche Klasse",
    Upgrade_Page = "Seite $1 von $2",
    Upgrade_New = "NEU!",
	
	--Victory Screen
    Victory_RegionLost = "Region verloren",
    Victory_FailedRewards = "Keine Belohnungen f�r eine fehlgeschlagene Mission.",
    Victory_Simulation = "Simulation abgeschlossen",
    Victory_SimulationText = "Herzlichen Gl�ckwunsch zu deinerersten erfolgreichen Mission, Commander! Ich bin zuversichtlich, dass du nach so viel Training den Planeten retten kannst.",
    Objective_Title = "Bonusziele",
    Objective_Title_One = "Bonus-Ziel",
    Objective_Title_Final = "Hauptziel",
    Victory_Civilians = "Zivilisten gesch�tzt",
    Victory_Title = "Region gesichert",
    Pod_Title = "POD ERHOLTE SICH",
    Pod_Contents = "Pod Inhalt:",
	
	---Store
    Store_Core = "Reaktorkern",
    Store_Cost = "Kosten: $1",
    Store_Equipped = "Ausgestattet",
    Store_Purchase = "Erwerbe Ausr�stung mit        Reputation",
    Store_Sell = "Spenden Waffen und Piloten f�r        Reputation",
    Store_SellTitle = "SPENDEN",
    Store_BuyTitle = "ERWERBEN",
    Store_Weapons = "Waffen",
    Store_Pilots = "Piloten",
    Leave_Confirm = "Deine unbenutzte Firmenreputation wird verloren gehen, wenn du jetzt gehst.",
    SellPilot_Confirm = "Bist du sicher, dass Sie diesen Pilot der Insel dauerhaft zuweisen m�chten?\n(Gew�hrt Reputation)",
    SellWeapon_Confirm = "M�chtest du diese Waffe wirklich spenden?\n(Gew�hrt Reputation)",
	
	--Rewards
    Reward_Title = "Perfekte Insel!",
    Reward_Subheading = "W�hle eine kostenlose Belohnung aus",
	
	--- Misc
    Pod_Objective = "Sch�tzen den Time-Pod",
    Secret_Objective = "Sch�tze den seltsamen Pod",
    Secret_Objective_Failed = "Sch�tze den seltsamen Pod (fehlgeschlagen)",
    Pod_Detected = "Time-Pod erkannt",
    Pod_Failed = "Sch�tzen den Time-Pod (fehlgeschlagen)",
    Toggle_NeverAgain = "Frag nicht wieder",
    Mission_Map_Deploy = "Starte die Mission",
    Pawn_Box_Water = "Wasser \nProtokolliert",
    Pawn_Box_Acid = "Wasser \nProtokolliert",
    Pawn_Box_Smoke = "Rauch \nBlockierend",
    Pawn_Box_Ice = "Eis \nBlockierend",
    Pawn_Box_Shot = "Nur\nBonusbewegung",
    Pawn_Box_Lava = "Lava \nBlockierend",
    Boss_Title = "Warnung: Vek Offensive",
    Boss_Text = "Vek �berlaufen zwei Regionen auf der Insel.\nThe Region die nicht gesichert wird ist f�r immer verloren.",
    Top_Power = "ENERGIE",
    Top_Grid = "NETZ",
    Top_Defense = "ABWEHR",
    Pilot_TurnOver = "Zug vorbei",
    Pilot_Disabled = "Deaktiviert",
    Pilot_EnemyDead = "Get�tet",
	
	--Office
    Island_Office = "$1 Hauptb�ro",
	
	--Mission Texts
    Mission_Normal = "Vek Bedrohung entdeckt!",
    Mission_Easy = "Abwehrschilde aktiv!",
    Mission_Hard = "Hohe Bedrohung erkannt!",
    Mission_Final = "Das letzte Gefecht",
    Mission_Failed = "Region von Vek zerst�rt",
    Mission_None = "Keine Vek erkannt",
	
	--Confirm Box
    Button_Confirm_No = "NEIN",
    Button_Confirm_Yes = "JA",
    Confirm_Question = "Weiter?",
    Button_Confirm_Ok = "OK",
	
	-- Pilot News
    PilotNews_Dead = "VERSTORBENE",
    PilotNews_Revived = "WIEDERBELEBT",
    PilotNews_ReviveText = "Das medizinische Notfallmaterial konnte $1 vor dem Tod retten!",
    PilotNews_Vek = "REGENERIERT",
    PilotNews_VekText = "$1 hat sich vom Rande des Todes erholt! Der Aufwand zum Regenerieren hat XP gekostet.",
    PilotNews_DeadText = "$1 starb, nachdem er im Kampf gegen die Kreaturen schweren Schaden genommen hatte.",
    PilotNews_Promoted = "BEF�RDERT",
    PilotNews_Skill = "Neue F�higkeit freigeschaltet:",
    Button_Pilot_News_Done = "Verstanden",
	
	
	--Buttons
    Button_Continue = "WEITER",
    Button_Wait = "WARTEN",
    Button_Create = "ERSTELLEN",
	
	--Main Menu
    Button_Profile = "Neues Profil erstellen",
    Button_MainContinue = "Weiter",
    Button_MainCredits = "Credits",
    Button_MainNew = "Neues Spiel",
    Button_MainOptions = "Optionen",
    Button_MainProgress = "Fortschritt",
    Button_MainStats = "Statistiken",
    Button_MainAchievs = "Erfolge",
    Button_MainSquads = "Squads",
    Button_MainQuit = "Beenden",
    Button_MainProfile = "Profil",
    Toggle_EnableTips = "Aktivieren Tutorial-Tipps",
    NewGame_Confirm = "Du hast gerade ein Spiel offen.  Wenn du ein neues startest wird es dauerhaft gel�scht.",
    Delete_Confirm = "Du wirst alle Spielfortschritte und Freischaltungen verlieren. Das kann nicht r�ckg�ngig gemacht werden.",
    Warning_NoSave = "\"Into the Breach\" scheint keinen Dateizugriff zu haben, um den Fortschritt zu speichern. \n\nBitte beenden Sie das Programm und pr�fen Sie, ob Ihre Anti-Virus-Software es blockiert. \n\nWenn das Problem weiterhin besteht, senden Sie uns eine E-Mail an contact@subsetgames.com",
    Warning_FileWriteIssue = "\"Into the Breach\" kann m�glicherweise den Fortschritt nicht retten. \n\nBitte beenden Sie das Programm und pr�fen Sie, ob Ihre Anti-Virus-Software es blockiert. \n\nWenn das Problem weiterhin besteht, senden Sie uns eine E-Mail an contact@subsetgames.com",
    Warning_SaveFileCorrupted = "Dein Speicherstand scheint kaputt zu sein. Bitte kontaktiere uns auf contact@subsetgames.com wenn du willst das wir eine Wiederherstellung probieren.\n\nEs tut uns sehr leid!",
    Warning_ProfileCorrupted = "Deine Profildatei scheint kaputt zu sein. Bitte kontaktiere uns auf contact@subsetgames.com wenn du willst das wir eine Wiederherstellung probieren.\n\nEs tut uns sehr leid!",
    Menu_NoSave = "WARNUNG: Es liegt ein Schreibfehler vor und dein Fortschritt kann nicht gespeichert werden.",
    Confirm_Header = "Aktion best�tigen",
    Warn_Header = "Warnung!",
    Profile_Delete_Failed = "Ihre Profildaten konnten nicht vollst�ndig gel�scht werden. Es kann nur gelesen werden, oder es kann zus�tzliche Dateien in seinem Ordner haben. Du kannst es manuell von hier l�schen: \n\n",
    Profile_Delete_Failed_OSX = "Ihre Profildaten konnten nicht gel�scht werden. Dies ist ein bekanntes Problem in OS X. \n\nSie k�nnen Ihre Profildaten manuell von diesem Speicherort l�schen: \n\n",
	
	
    Stats_Header = "Statistiken",
    Stats_TotalVictory = "Siege:",
    Stats_TotalLost = "Zeitlinie verloren:",
    Stats_TotalGames = "Gesamtanzahl der Spiele:",
	
    Stats_TotalTravelers = "Zeitreisende Gesamt:",
    Stats_TotalKills = "Feinde get�tet gesamt:",
    Stats_TotalSaved = "Gerettete Zivilisten gesamt:",
    Stats_TotalIsland = "Gesicherte Inseln:",
    Stats_TotalPods = "Geerntete Pods:",
	
    Stats_ScoreDefeat = "Besiegt",
    Stats_ScoreVictory = "$1 Insel-Sieg!",
    Stats_ScoreScore = "Zivilisten gerettet:",
    Stats_ScoreKills = "Gesamtkills:",
    Stats_ScoreFailed = "Fehlgeschlagene Ziele:",
    Stats_ScoreTimer = "Spielzeit:",
	
    Stats_SquadGames = "Gesamtanzahl der Spiele:",
    Stats_SquadScore = "Highscore:",
    Stats_SquadKills = "Gesamtkills:",
	
    Stats_PilotBattles = "K�mpfe:",
    Stats_PilotJumps = "Zeitspr�nge:",
    Stats_PilotKills = "Gesamtkills:",
    Stats_Pilot_Deaths = "Tode gesamt:",
	
    Stats_VekDeadliest = "T�dlichster Feind",
    Stats_VekDeadliestStat = "Get�tete Mechs:",
    Stats_VekWeakest = "Am einfachsten",
    Stats_VekWeakestStat = "Anzahl get�tet:",
    Stats_VekDestruction = "Meist zerst�rerisch",
    Stats_VekDestructionStat = "Gitterschaden:",
	
	
    Stats_ListButton = "Zur�ck zur Liste",
    Stats_SquadButton = "Squad wechseln",
    Stats_PilotButton = "Pilot �ndern",
    Stats_Done = "Schlie�en",
	
    Stats_ToggleGlobal = "Nach ausgew�hltem Squad filtern",
	
	--Hangar
    Toggle_Easy = "Einfach",
    Toggle_Hard = "Hard",
    Toggle_Normal = "Normal",
    Hangar_None = "Keiner",
    Hangar_CustomSquad = "Finale Auswahl:",
    Hangar_Traveler_Heading = "Zeitreisender",
    Hangar_Island_Victory = "Medaillen werden basierend darauf vergeben, wie viele Firmeninseln vor Abschluss der finalen Insel gesichert sind.",
    Hangar_Island_Victory_2 = "2 Insel Sieg: $1",
    Hangar_Island_Victory_3 = "3 Insel Sieg: $1",
    Hangar_Island_Victory_4 = "4 Insel Sieg: $1",
    Hangar_Island_Victory_Title = "Siegmedaillen",
    Hangar_Ach_Coins = "Hinweis: Erfolge bringen dir Coins, um neue Mech Squads freizuschalten!",
    Hangar_Locked = "Gesperrt",
    Hangar_Randomized = "Zufaelliges Squad",
    Hangar_Custom = "Squad anpassen",
    Hangar_Complete = "Beende mehr Inseln um das freizuschalten!",
    Hangar_Achievements = "Verdiene mehr Coins!",
    Hangar_Buy = "Klicken um zu kaufen!",
    Button_Hangar_Squad = "Squad wechseln",
    Button_Hangar_Pilot = "Zeitreisenden �ndern",
    Button_Hangar_Random_Pilot = "Zuf�llig",
    Button_Hangar_Reroll = "Ausgeglichen zuordnen",
    Button_Hangar_RandomRoll = "Zuf�llig zuordnen",
    Button_Hangar_Ach = "Erfolge anzeigen",
    Button_Hangar_Secret = "Geheimes Squad kaufen       ",
    Hangar_Total_Ach = "Coins verdient",
    Button_Hangar_Recustom = "Squad editieren",
    Hangar_Custom_Locked = "Schalte den Squad \"$1\" frei, um diesen Mech zu benutzen",
    Hangar_Custom_Locked_Title = "Gesperrter Mech",
    Button_Hangar_Start = "Starten",
    Hangar_Random = "Zuf�lliger Mech",
    Hangar_Select = "Squadauswahl",
    Hangar_Achievements_Title = "Erfolge",
	
    Ach_Squad = "Squad basiert",
    Ach_Global = "Global",
	
    Hangar_Custom = "Squad anpassen",
    Hangar_Coins = "Erfolge bringen Coins! Benutze Coins fuer neue Squads!",
    Hangar_Pilot_Unlock = "Finde neue Piloten im Spiel um sie hier freizuschalten!",
    Hangar_Pilot = "Pilotenauswahl",
    Hangar_Traveler = "Letzter \nReisender",
    Hangar_NoAbility = "Keine besondere F�higkeit",
    Hangar_NoTraveler = "Letzter Pilot nicht verf�gbar",
    Randomized = "Erstelle einen zuf�lligen Squad mit freigeschalteten Mechs.",
    Customized = "Erstelle einen eigenen Squad mit freigeschalteten Mechs.",
    RandomizedLocked = "Zuwenig Mechs freigeschalten!",
    No_Weapon = "Keine Waffe",
	
    TipTitle_MechColor = "",
    TipText_MechColor = "Klicken Sie, um Mech Farbe zu �ndern",
    TipTitle_MechName = "",
    TipText_MechName = "Klicken Sie, um Mech umzubenennen",
    TipTitle_PilotName = "",
    TipText_PilotName = "Klicke um Pilot umzubenennen",
    TipTitle_PilotMech = "",
    TipText_PilotMech = "Klicke hier, um das Start-Mech f�r den Zeitreisenden zu �ndern",
    TipTitle_HangarMovement = "Bewegung",
    TipText_HangarMovement = "Wie viele Felder kann dieser Mech sich in jedem Zug bewegen.",
    TipTitle_HangarHealth = "Gesundheit",
    TipText_HangarHealth = "Wie viel Schaden dieser Mech erleiden, bevor er deaktiviert wird.",
    TipTitle_HangarClass = "Mech-Klasse",
    TipText_HangarClass = "Die Mech-Klasse bestimmt, welche Waffen sie ohne eine Energiestrafe benutzen kann.",
    TipTitle_HangarFlying = "Fliegt",
    TipText_HangarFlying = "Fliegende Einheiten k�nnen sich �ber jedes Feld bewegen.",
    TipTitle_HangarArmor = "Gepanzert",
    TipText_HangarArmor = "Waffenschaden f�r diese Einheit wird um 1 verringert. Alle anderen Sch�den (Sto�en, Blockieren, Feuer usw.) sind davon nicht betroffen.",
	
    TipTitle_HangarNormal = "Normal",
    TipText_HangarNormal = "Entwickelt, um neuen und erfahrenen Spielern eine interessante Herausforderung zu bieten.",
    TipTitle_HangarEasy = "Einfacher Modus",
    TipText_HangarEasy = "Verringerte gegnerische Spawn-Raten.\n\nAnzahl um 50% reduziert.",
    TipTitle_HangarHard = "Hard Modus",
    TipText_HangarHard = "Erh�hte Spawn-Raten und mehr Alpha Vek.\n\nAnzahl wird um 50% erh�ht.",
	
	
    TipText_LockedColor = "Schalte den Squad '$1' frei, um diese Farbe zu verwenden",
    TipTitle_LockedColor = "Gesperrte Farbe",
	
    TipTitle_Repeat = "Passive Ausr�stung wiederholen",
    TipText_Repeat = "Dein Mechsquad kann nicht mehrere Kopien derselben passiven Ausr�stung haben. \n\nDu kansst immer noch mit dem Squad spielen, aber die zus�tzlichen Kopien der passiven Ausr�stung werden entfernt.",
	
    TipTitle_ChaosRoll = "Zuf�llig zuordnen",
    TipText_ChaosRoll = "Rein zuf�lliger Squad. Keine Einschr�nkungen f�r Klasse, Waffen oder Mech.",
	
    TipTitle_BalancedRoll = "Ausgeglichen zuordnen",
    TipText_BalancedRoll = "Leicht eingeschr�nktes zuf�lliges Squad.\n\nAlle Mechs sind einzigartig und nicht aus derselben Klasse. Mechs haben nicht mehr als 4 Waffen insgesamt.",
	
	--Options
    Toggle_Fullscreen = "Vollbild",
    Toggle_Framelimit = "Frame Limit",
    Toggle_Screenshake = "Deaktiviere Screen Shake",
    Toggle_Grid = "Gitterkoordinaten",
    Toggle_Stretch = "Stretch-Skalierung",
    Toggle_Timer = "Spieltimer UI",
    Button_Options_Hotkeys = "Hotkeys bearbeiten",
    Button_Options_Default = "Default Windowed",
    Button_Options_Scale = "Max Board Skalierung: $1",
    Toggle_Mute = "Ton stummschalten",
    Toggle_Colorblind = "Farbenblinder Modus",
    Toggle_Large = "Gr��ere Schriftarten",
    Toggle_Tips = "Tutorial Tipps",
    Abandon_Confirm = "Du wirst einen Piloten auf eine neue Timeline entsenden und dabei jeden Fortschritt verlieren.",
    Escape_Title = "MEN�",
    Escape_Info = "INFO",
    Escape_Sound = "Effektlautst�rke",
    Escape_Music = "Musiklautst�rke",
    Escape_Speed = "Kampfgeschwindigkeit",
    Toggle_Confirm = "Best�tigung Zugende",
    Escape_Gameplay = "Gameplay",
    Escape_Video = "Ton + Video",
    Button_Escape_Menu = "HAUPTMEN�",
    Button_Escape_Exit_Editmode = "MAP BEARBEITEN",
    Button_Escape_Exit_Editor = "EDITOR VERLASSEN",
    Button_Escape_Options = "OPTIONEN",
    Button_Escape_Ach = "ERFOLGE",
    Button_Escape_Quit = "Speichern und Ende",
    Button_Escape_Abandon = "VERLASSE ZEITLINIE",
    Button_Escape_Continue = "WEITER",
	
    Mouse_Middle = "Mittlere Maustaste",
    Mouse_X1 = "Maus 4",
    Mouse_X2 = "Maus 5",
	
	--Opening Sequence
    Opening_1 = "Menschheit: Zerst�rt      ",
    Opening_2 = "Vek Bedrohung: Unaufhaltsam",
    Opening_3 = "Mission: Fehlgeschlagen              ",
    Opening_4 = "�ffne einen Breach.        ",
    Opening_5 = "Zeit zur�ckzugehen und es erneut zu versuchen.",
	
	--Game Over
    Button_Victory_Pilot = "PILOT SENDEN",
    Button_Victory_Quit = "HAUPTMEN�",
    Button_Victory_Done = "WEITER",
	
	--End of Island
    Button_Select_Mission_Leave = "INSEL VERLASSEN",
    Button_Select_Mission_Store = "REPUTATION BENUTZEN",
    Button_Select_Mission_Reward = "REPUTATION ERHALTEN!",
	
	--Island Stuff
    Island_Environment = "UMGEBUNG",
    Island_CEO = "CEO",
    Island_Vek = "VEK:",
    Island_Boss = "F�HRENDER:",
    Island_Unlock = "Zum freischalten schlie�e $1 $2 ab!",
    Island_Unlock_Single = "Insel",
    Island_Unlock_Mult = "Inseln",
    Island_UnlockTitle = "Insel freigeschaltet!",
	
    Island_UnlockTitle = "Insel freigeschaltet!",
    Island_1 = "Eine Insel",
    Island_2 = "Zwei Inseln",
    Island_3 = "Drei Inseln",
    Island_Text = "Weil du $1 abgeschlossen hast\n\n\n\n\nIn zuk�nftigen Spielen kannst du entsperrte Inseln in beliebiger Reihenfolge besuchen.",
    Island_Squad = "Neues Squad verf�gbar, beim Start eines neuen Spiels!",
	
	--Alerts
    Alert_Cleared = "ATTACKE ABGEBROCHEN",
    Alert_Fire = "FEUERSCHADEN",
    Alert_Elec = "ELEKTRISCHER SCHADEN",
    Alert_Blocked = "BLOCKIERTER FEIND",
    Alert_Attacking = "ATTACKIERT NICHT",
    Alert_PodDestroyed = "POD DESTROYED",
    Alert_PodSecured = "POD SECURED",
    Alert_Threat = "BEDROHT",
    Alert_Healed = "EINHEIT REPARIERT",
    Alert_BlobSpawn = "TEILEN UNTERDR�CKT",
    Alert_Regen = "PSION REGENERATION",
    Alert_Tentacle = "PSION ATTACK",
    Alert_Action = "AKTION VERF�GBAR",
    Alert_Level = "LEVEL UP!",
    Alert_Warning = "WARNUNG!",
    Alert_Incoming = "POD INCOMING",
    Alert_Passive = "PASSIVBONUS",
    Alert_Resisted = "WIDERSTANDEN",
    Alert_Power = "ENERGIE VERLOREN",
    Alert_Casualties = "Verluste",
    Alert_Unused = "ENERGIE VERF�GBAR",
    Alert_NoWeapon = "KEINE WAFFE GELADEN",
    Alert_Open = "TOR �FFNEN",
    Alert_Pilot = "PILOT VERF�GBAR",
    Alert_Lost = "REGION VERLOREN",
    Alert_Secured = "REGION GESICHERT",
    Alert_Cores = "KERNE VERF�GBAR",
    Alert_PilotCores = "PILOT & ENERGIE VERF�GBAR",
    Alert_Overflow = "VERTEIDIGUNG RAUF!",
    Alert_FullOverflow = "GRID MAX!",
    Alert_Smoke = "RAUCH BLOCKIERT!",
    Alert_Water = "MECH UNTERGETAUCHT!",
    Alert_NoTarget = "KEIN ZIEL VERF�GBAR!",
	
    Status_Full = "Einige Effekte sind wegen Platzmangels nicht aufgef�hrt",
	
    SquadName_Filler = "Zeitreisende",
	
    TipTitle_Archive_A = "Rift Walkers",
    TipText_Archive_A = "Dies waren die allerersten Mechs, die gegen die Vek k�mpften. Sie sind effizient und zuverl�ssig.",
	
    TipTitle_Archive_B = "Stahl Judaica",
    TipText_Archive_B = "Diese Mechs sind auf Positionsmanipulationen spezialisiert, um die Vek gegeneinander zu richten.",
	
    TipTitle_Rust_A = "Verrostete Hulks",
    TipText_Rust_A = "R. S. T. Wettermanipulatoren erm�glichen es diesen Mechs, Rauchst�rme �berall zu nutzen.",
	
    TipTitle_Rust_B = "Flammenbehemoths",
    TipText_Rust_B = "Unverwundbar f�r Flammen, zielen diese Mechs darauf ab, jede Bedrohung zu Asche zu verbrennen.",
	
    TipTitle_Pinnacle_A = "Zenith-Wache",
    TipText_Pinnacle_A = "Die Beam-Technologie von Detritus und die Pinnacle Shield-Technologie bilden eine leistungsstarke Kombination.",
	
    TipTitle_Pinnacle_B = "Gefrorene Titanen",
    TipText_Pinnacle_B = "Diese Titanen sind auf den Cryo Launcher angewiesen, eine m�chtige Waffe, die ein erfahrenen Piloten braucht.",
	
    TipTitle_Detritus_A = "Blitzkrieg",
    TipText_Detritus_A = "R. S. T. Ingenieure entwarfen dieses Squad auf Basis der Vernichtungskraft von Blitzen.",
	
    TipTitle_Detritus_B = "Gef�hrliche Mechs",
    TipText_Detritus_B = "Diese Mechs verursachen spektakul�re Sch�den, aber sie verlassen sich auf Nanobots, die tote Vek brauchen, um am Leben zu bleiben.",
	
    TipTitle_Random = "Zuf�lliger Squad",
    TipText_Random = "Erstelle einen zuf�lliges Squad aus allen Mechs, die du freigeschaltet hast.",
	
    TipTitle_Custom = "Squad anpassen",
    TipText_Custom = "Erstelle einen benutzerdefinierten Squad mit einem der Mechs, die du freigeschaltet hast.",
	
    TipTitle_Secret = "Geheime Truppe",
    TipText_Secret = "Die letzte Hoffnung der Menschheit ist eine Mischung aus Machine und Vek, die geschaffen wurde, um die Erde zu verteidigen.",
	
	---Achievements
    Achievement_Completed = "Abgeschlossen auf Schwierigkeit $1",
    Achievement_Header = "Achievement!",
    Achievement_Header_Pilot = "Pilot gefunden!",
    Achievement_Text_Pilot = "Hangar freigeschalten",
	
	-----hotkeys
    Mute_Title = "Stummschalten",
    Mute_Description = "Deaktivieren alle T�ne",
	
    Undo_Title = "Bewegung r�ckg�ngig",
    Undo_Description = "Mach die letzte Bewegung mit einem Mech r�ckg�ngig",
	
    Reset_Title = "Zug zur�ck",
    Reset_Description = "Falls verf�gbar, auf den Start des Zuges zur�cksetzen",
	
    SelectMech1_Title = "W�hle Mech 1",
    SelectMech1_Description = "W�hle deinen ersten Mech (basierend auf der Listenreihenfolge)",
	
    SelectMech2_Title = "W�hle Mech 2",
    SelectMech2_Description = "W�hle deinen zweiten Mech aus (basierend auf der Listenreihenfolge)",
	
    SelectMech3_Title = "W�hle Mech 3",
    SelectMech3_Description = "W�hle deinen dritten Mech aus (basierend auf der Listenreihenfolge)",
	
    SelectDeploy1_Title = "W�hle Bereit 1",
    SelectDeploy1_Description = "W�hle die eingesetzte Einheit deines ersten Mechs aus",
	
    SelectDeploy2_Title = "W�hle Bereit 2",
    SelectDeploy2_Description = "W�hle die eingesetzte Einheit deines zweiten Mechs aus",
	
    SelectDeploy3_Title = "W�hle Bereit 3",
    SelectDeploy3_Description = "W�hle die eingesetzte Einheit deines dritten Mechs aus",
	
    SelectMission1_Title = "W�hle Missionseinheit 1 aus",
    SelectMission1_Description = "W�hle die Missionseinheit, die du momentan kontrollierst (falls verf�gbar)",
	
    SelectMission2_Title = "W�hle Missionseinheit 2",
    SelectMission2_Description = "W�hle die zweite Missionseinheit aus, die du momentan kontrollierst (falls verf�gbar)",
	
    Cycle_Title = "Zykluseinheiten",
    Cycle_Description = "Wechseln Sie zur n�chsten verf�gbaren aktiven, kontrollierten Einheit",
	
    Deselect_Title = "Waffen entwaffnen",
    Deselect_Title = "Waffen entwaffnen",
    Deselect_Description = "Aktuelle Selektion aufheben",
	
    Info_Title = "Infofenster",
    Info_Description = "Halte gedr�ckt, um eine Einheit unter dem Mauszeiger zu untersuchen",
	
    Overlay_Title = "Angriffsfolge zeigen",
    Overlay_Description = "Halte gedr�ckt, um die aktuelle Angriffsfolge f�r gegnerischen Einheiten anzuzeigen",
	
    Weapon1_Title = "Waffe 1",
    Weapon1_Description = "Schalte oder deaktiviere die erste Waffe, die auf einer Einheit installiert ist",
	
    Weapon2_Title = "Waffe 2",
    Weapon2_Description = "Schalte oder deaktiviere die zweite Waffe, die auf einer Einheit angebracht ist",
	
    Repair_Title = "Reparatur",
    Repair_Description = "Aktiviere deine Mech-Reparatur-F�higkeit (falls verf�gbar)",
	
    EndTurn_Title = "Letzter Zug",
    EndTurn_Description = "Beenden deinen Zug oder best�tige das Ende der Aufstellung",
	
    Fullscreen_Title = "Vollbild umschalten",
    Fullscreen_Description = "Schaltet den Vollbildmodus um",
	
	
	---------- CREDITS + VICTORY TEXT
	
    Credits_Studio = "A game from:",
    Credits_StudioName = "SUBSET GAMES",
    Credits_Created = "Created by:",
    Credits_CreatedName = "Justin Ma and Matthew Davis",
    Credits_Music = "Music:",
    Credits_MusicName = "Ben Prunty",
    Credits_Sound = "Sound:",
    Credits_SoundName = "Power Up Audio",
	
    Credits_SoundSub1 = "Sound Designers:",
    Credits_SoundSub1Name = "Joey Godard\nJeff Tangsoc\nKevin Regamey\nCole Verderber",
	
    Credits_SoundSub2 = "Sound Library:",
    Credits_SoundSub2Name = "",

    Credits_Writing = "Writing:",
    Credits_WritingName = "Chris Avellone",
    Credits_Editing = "Additional Editing:",
    Credits_EditingName = "Alison Waller",
    Credits_Community = "Community Management:",
    Credits_CommunityName = "Isla Schanuel",
    Credits_Portraits = "Portrait Concept Art:",
    Credits_PortraitsName = "Polina Hristova",
    Credits_Mechs = "Mech Concept Art:",
    Credits_MechsName = "Gareth Davies",
    Credits_QA = "QA Testing:",
    Credits_QAName = "The Research Centaur UX+QA",
	
    Credits_QASub1 = "Test Manager:",
    Credits_QASub1Name = "Jay Fernandes",
    Credits_QASub2 = "QA Specialists:",
    Credits_QASub2Name = "Matthew Barnes\nLucia Aldana",
	
    Credits_Testers = "Thank you to our amazing community testers:",
    Credits_TestersName = "5thHorseman\nAlfie275\nchewbacca77\nDarthcaboose\nDiscord\nFynn\nJoni\nKieve\nLem\nNick Patrick\nRick Edmonds\nSleeper Service\n",
    Credits_Thanks = "Special thank you for their advice and support:",
    Credits_ThanksName = "Maria\nAlison\nMichael Nielsen\nEstelle Tigani\nAllison Thrower\nBryan\nIlona Koleda\nEsther Oh",
    Credits_ThanksExtra = "and the rest of our family, friends,\nand fellow indie developers",
    Credits_Babies = "Production Babies:",
    Credits_BabiesName = "Fox and Willow",
    Credits_FinalThanks = "Thank you for playing!",
	
}

function GetText(id)
	if Global_Texts[id] ~= nil then
		return Global_Texts[id]
	end
	
	if Weapon_Texts[id] ~= nil then
		return Weapon_Texts[id]
	end
	
	if Achievement_Texts[id] ~= nil then
		return Achievement_Texts[id]
	end
	
	return "no string found"
end