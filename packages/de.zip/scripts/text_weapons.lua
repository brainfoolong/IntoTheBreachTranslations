
Weapon_Texts = {

-------------------------------------------------------------------------------------------------------------------------
--------------- ENEMY WEAPONS -------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

SpiderlingAtk1_Name = "Winzige Mandibeln",
SpiderlingAtk1_Description = "Schwacher Angriff gegen ein einzelnes Ziel.", 

SpiderlingAtk2_Name = "Winzige Mandibeln",
SpiderlingAtk2_Description = "Schwacher Angriff gegen ein einzelnes Ziel.", 

ScorpionAtk1_Name = "Stechender Spinneret",
ScorpionAtk1_Description = "Web das Ziel, vorbereitend, es zu erstechen.", 

ScorpionAtk2_Name = "G�ring Spinneret",
ScorpionAtk2_Description = "Web das Ziel, vorbereitend, es zu erstechen.", 

Burrower_Atk_Name = "Stacheliger Panzer",
Burrower_Atk_Description = "Slam gegen 3 Felder in einer Reihe.", 

Burrower_Atk2_Name = "Messerpanzer",
Burrower_Atk2_Description = "Slam gegen 3 Felder in einer Reihe.", 

HornetAtk1_Name = "Stinger",
HornetAtk1_Description = "Erstich das Ziel.", 

HornetAtk2_Name = "Feuere Stinger ab",
HornetAtk2_Description = "Stich 2 Felder vor der Einheit.", 

CrabAtk1_Name = "Explosive Vertreibungen",
CrabAtk1_Description = "Artillerieangriff auf 2 Felder starten.", 

CrabAtk2_Name = "Explosive Vertreibungen",
CrabAtk2_Description = "Artillerieangriff auf 2 Felder starten.", 

ScarabAtk1_Name = "Spuckende Dr�sen",
ScarabAtk1_Description = "Schie�e eine Artillerie auf ein einzelnes Feld.", 

ScarabAtk2_Name = "Spuckende Dr�sen",
ScarabAtk2_Description = "Schie�e einen m�chtigen Artillerieschuss auf ein einzelnes Feld.", 

CentipedeAtk1_Name = "Saures Erbrechen",
CentipedeAtk1_Description = "Starten Sie eine volatile Masse von Goo, f�gt nahen Einheiten S�ureschaden zu.", 

CentipedeAtk2_Name = "�tzendes Erbrechen",
CentipedeAtk2_Description = "Starten Sie eine volatile Masse von Goo, f�gt nahen Einheiten S�ureschaden zu.", 

LeaperAtk1_Name = "Rei�z�hne",
LeaperAtk1_Description = "Fange das Ziel, bereite einen Biss vor.", 

LeaperAtk2_Name = "Gesch�rfte Z�hne",
LeaperAtk2_Description = "Fange das Ziel, bereite einen Biss vor.", 

FireflyAtk1_Name = "Beschleunigender Thorax",
FireflyAtk1_Description = "Starte eine volatile Masse von Goo.", 

FireflyAtk2_Name = "Verbesserter Thorax",
FireflyAtk2_Description = "Starte eine volatile Masse von Goo.", 

BeetleAtk1_Name = "Zangen",
BeetleAtk1_Description = "St�rme vorw�rts auf Schaden und schiebe das Ziel.", 

BeetleAtk2_Name = "Gesch�rfte Zangen",
BeetleAtk2_Description = "St�rme vorw�rts auf Schaden und schiebe das Ziel.", 

DiggerAtk1_Name = "Grabende Sto�z�hne",
DiggerAtk1_Description = "Erstelle eine defensive Felswand, bevor du angrenzende Felder angreifst.", 

DiggerAtk2_Name = "Grabende Sto�z�hne",
DiggerAtk2_Description = "Erstelle eine defensive Felswand, bevor du angrenzende Felder angreifst.", 

BlobberAtk1_Name = "Wabbernder Blob",
BlobberAtk1_Description = "Wirf einen klebrigen Klecks, der explodiert.", 

BlobberAtk2_Name = "Volatiler Blob",
BlobberAtk2_Description = "Wirf einen massiven Blob, der explodiert.", 

BlobAtk1_Name = "Instabile Eingeweide",
BlobAtk1_Description = "Explodiert, t�tet sich selbst und besch�digt angrenzende Felder. T�te es zuerst, um es zu stoppen.", 

BlobAtk2_Name = "Volatile Eingeweide",
BlobAtk2_Description = "Explodiert, t�tet sich selbst und besch�digt angrenzende Felder. T�te es zuerst, um es zu stoppen.", 

SpiderAtk1_Name = "Kleine Nachkommen",
SpiderAtk1_Description = "Wirf ein klebriges Ei, aus dem ein Spinnentier schl�pft.", 

SpiderAtk2_Name = "Gro�e Nachkommen",
SpiderAtk2_Description = "Wirf ein klebriges Ei, aus dem ein Spinnentier schl�pft.", 

SpiderlingHatch1_Name = "Spinnendes Ei",
SpiderlingHatch1_Description = "In Spiderling eintauchen.", 

WebeggHatch1_Name = "Spinnendes Ei",
WebeggHatch1_Description = "In Spiderling eintauchen.", 

Jelly_Health_Tooltip_Name = "Belebende Sporen",
Jelly_Health_Tooltip_Description = "Alle anderen Vek erhalten +1 HP, solange der Psion lebt.", 

Jelly_Explode_Tooltip_Name = "Explosiver Zerfall",
Jelly_Explode_Tooltip_Description = "Alle anderen Vek explodieren beim Tod, f�gen angrenzenden Feldern 1 Schaden hinzu.", 

Jelly_Lava_Tooltip_Name = "Vom Hive erfasst",
Jelly_Lava_Tooltip_Description = "Alle Spielereinheiten erhalten 1 Schaden am Ende von jedem Zug.",

Jelly_Armor_Tooltip_Name = "Geh�rteter Panzer",
Jelly_Armor_Tooltip_Description = "Alle anderen Veks haben ankommenden Waffenschaden um 1 verringert.", 

Jelly_Regen_Tooltip_Name = "Regeneration",
Jelly_Regen_Tooltip_Description = "Alle anderen Vek heilen sich um 1 beim Start ihres Zuges.", 

----------------------------------------------------------------------------------------------------------------------------
------------------- BOSS WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

BeetleAtkB_Name = "Flammendes Abdomen",
BeetleAtkB_Description = "Lade und entz�nde alle Felder auf dem Pfa.",

SnowBossAtk_Name = "Vk8 Rockets Mark III",
SnowBossAtk_Description = "Starte Raketen auf 3 Felder.",

SnowBossAtk2_Name = "Vk8 Raketen Mark IV",
SnowBossAtk2_Description = "Starte Raketen auf 3 Felder.",

FireflyAtkB_Name = "Brennender Thorax",
FireflyAtkB_Description = "Starte goo Projektile in zwei Richtungen.",

BlobBossAtk_Name = "Goo Attacke",
BlobBossAtk_Description = "Versuche das angrenzende Feld zu zerquetschen.",

BlobBossAtkMed_Name = "Goo Attacke",
BlobBossAtkMed_Description = "Versuche das angrenzende Feld zu zerquetschen.",

BlobBossAtkSmall_Name = "Goo Attacke",
BlobBossAtkSmall_Description = "Versuche das angrenzende Feld zu zerquetschen.",

HornetAtkB_Name = "Super Stinger",
HornetAtkB_Description = "Stich drei Felder in einer Reihe.", 

ScorpionAtkB_Name = "Massiver Spinneret",
ScorpionAtkB_Description = "H�lt alle Feinde, bereitet sich auf massiven Schadensoutput an angrenzende Felder vor.",

SpiderBoss_Tooltip_Name = "Reichlich Nachkommen",
SpiderBoss_Tooltip_Description = "Wirf 2-3 Spinneneier.",

Jelly_Boss_Tooltip_Name = "�berlastet",
Jelly_Boss_Tooltip_Description = "Alle anderen Vek erhalten +1 HP, Regeneration und explodieren beim Tod.",



-------------------------------------------------------------------------------------------------------------------------
---------------- MECH PASSIVES ------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

Passive_FlameImmune_Name = "Gegen Flammen Immun",
Passive_FlameImmune_Description = "Alle Mechs sind Immun gegen Feuer.", 
Passive_FlameImmune_Upgrade1 = "",
Passive_FlameImmune_Upgrade2 = "",
Passive_FlameImmune_A_UpgradeDescription = "",
Passive_FlameImmune_B_UpgradeDescription = "",

Passive_Electric_Name = "Sturmgenerator",
Passive_Electric_Description = "Jeder Rauch f�gt alle Feinden in jedem Zug Schaden hinzu.", 
Passive_Electric_Upgrade1 = "+1 Schaden",
Passive_Electric_Upgrade2 = "",
Passive_Electric_A_UpgradeDescription = "Erh�ht Rauchschaden um 1.",
Passive_Electric_B_UpgradeDescription = "",

Passive_Leech_Name = "Viscera Nanobots",
Passive_Leech_Description = "Mechs heilen 1 Schaden, wenn sie einen t�dlichen Schlag ausf�hren.", 
Passive_Leech_Upgrade1 = "+1 Heilung",
Passive_Leech_Upgrade2 = "",
Passive_Leech_A_UpgradeDescription = "Erh�he die Heilung auf 2.",
Passive_Leech_B_UpgradeDescription = "",

Passive_Defenses_Name = "Vernetzte R�stung",
Passive_Defenses_Description = "Alle Mechs erhalten +1 HP.", 
Passive_Defenses_Upgrade1 = "+1 Gesundheit",
Passive_Defenses_Upgrade2 = "",
Passive_Defenses_A_UpgradeDescription = "Erh�ht den Gesundheitsbonus auf 2.",
Passive_Defenses_B_UpgradeDescription = "",

Passive_MassRepair_Name = "Reparaturfeld",
Passive_MassRepair_Description = "Die Reparatur eines Mechs wird alle Mechs betreffen.", 
Passive_MassRepair_Upgrade1 = "",
Passive_MassRepair_Upgrade2 = "",
Passive_MassRepair_A_UpgradeDescription = "",
Passive_MassRepair_B_UpgradeDescription = "",

Passive_AutoShields_Name = "Auto-Schilde",
Passive_AutoShields_Description = "Geb�ude erhalten einen Schild, nachdem sie Schaden genommen haben.", 
Passive_AutoShields_Upgrade1 = "",
Passive_AutoShields_Upgrade2 = "",
Passive_AutoShields_A_UpgradeDescription = "",
Passive_AutoShields_B_UpgradeDescription = "",

Passive_Burrows_Name = "Stabilisierer",
Passive_Burrows_Description = "Mechs erhalten keinen Schaden mehr, wenn sie Vek blockieren.", 
Passive_Burrows_Upgrade1 = "",
Passive_Burrows_Upgrade2 = "",
Passive_Burrows_A_UpgradeDescription = "",
Passive_Burrows_B_UpgradeDescription = "",

Passive_Psions_Name = "Psion Empf�nger",
Passive_Psions_Description = "Mechs benutzen Boni von Vek Psion.", 
Passive_Psions_Upgrade1 = "",
Passive_Psions_Upgrade2 = "",
Passive_Psions_A_UpgradeDescription = "",
Passive_Psions_B_UpgradeDescription = "",

Passive_Boosters_Name = "Kickoff-Booster",
Passive_Boosters_Description = "Mechs erhalten +1 Bewegung, wenn sie nebeneinander ihren Zug starten.", 
Passive_Boosters_Upgrade1 = "+1 Bewegung",
Passive_Boosters_Upgrade2 = "",
Passive_Boosters_A_UpgradeDescription = "Bewegungsbonus um 1 erh�ht.",
Passive_Boosters_B_UpgradeDescription = "",

Passive_Medical_Name = "Medizinische Versorgung",
Passive_Medical_Description = "Alle Piloten �berleben den Tod.", 
Passive_Medical_Upgrade1 = "",
Passive_Medical_Upgrade2 = "",
Passive_Medical_A_UpgradeDescription = "",
Passive_Medical_B_UpgradeDescription = "",

Passive_FriendlyFire_Name = "Vek Hormone",
Passive_FriendlyFire_Description = "Gegner f�gen +1 Schaden gegen andere Feinde zu.", 
Passive_FriendlyFire_Upgrade1 = "+1 Schaden",
Passive_FriendlyFire_Upgrade2 = "+1 Schaden",
Passive_FriendlyFire_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Passive_FriendlyFire_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Passive_ForceAmp_Name = "Kraft Amp",
Passive_ForceAmp_Description = "Alle Vek nehmen +1 Schaden von Unebenheiten und blockieren das auftauchende Vek.", 
Passive_ForceAmpPassive_ForceAmp_Upgrade1 = "",
Passive_ForceAmp_Upgrade2 = "",
Passive_ForceAmp_A_UpgradeDescription = "",
Passive_ForceAmp_B_UpgradeDescription = "",

Passive_Ammo_Name = "Munitionsgenerator",
Passive_Ammo_Description = "+1 F�r alle Waffen mit begrenzter Nutzung.", 
Passive_Ammo_Upgrade1 = "",
Passive_Ammo_Upgrade2 = "",
Passive_Ammo_A_UpgradeDescription = "",
Passive_Ammo_B_UpgradeDescription = "",

Passive_CritDefense_Name = "Kritische Schilde",
Passive_CritDefense_Description = "Wenn das Stromnetz auf 1 reduziert wird, erhalten alle Geb�ude einen Schild.", 
Passive_CritDefense_Upgrade1 = "",
Passive_CritDefense_Upgrade2 = "",
Passive_CritDefense_A_UpgradeDescription = "",
Passive_CritDefense_B_UpgradeDescription = "",

--[[
Passive_FastDecay_Name = "Forestry Nano",
Passive_FastDecay_Description = "Vek spawn Forest when they die on Ground.", 
Passive_FastDecay_Upgrade1 = "",
Passive_FastDecay_Upgrade2 = "",
Passive_FastDecay_A_UpgradeDescription = "",
Passive_FastDecay_B_UpgradeDescription = "",
]]--

----------------------------------------------------------------------------------------------------------------------------
------------------- PRIME MECH WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Prime_Punchmech_Name = "Titan Faust",
Prime_Punchmech_Description = "Schlage angrenzendes Feld, sch�digt und st��t es.", 
Prime_Punchmech_Upgrade1 = "Zerschlagen",
Prime_Punchmech_Upgrade2 = "+2 Schaden",
Prime_Punchmech_A_UpgradeDescription = "Lade jede Distanz auf, bevor du das Ziel lochst.",
Prime_Punchmech_B_UpgradeDescription = "Erh�ht Schaden um 2.",

Prime_Lightning_Name = "Elektrische Peitsche",
Prime_Lightning_Description = "Kettenschaden durch angrenzende Ziele.", 
Prime_Lightning_Upgrade1 = "Geb�udekette",
Prime_Lightning_Upgrade2 = "+1 Schaden",
Prime_Lightning_A_UpgradeDescription = "Springt durch Geb�udekette ohne Schaden zu erzeugen.",
Prime_Lightning_B_UpgradeDescription = "F�gt allen betroffenen Feldern +1 Schaden zu.",

Prime_Lasermech_Name = "Berststrahl",
Prime_Lasermech_Description = "Feuere einen durchdringenden Strahl ab, der immer weniger Schaden auf Distanz macht.", 
Prime_Lasermech_Upgrade1 = "Verb�ndete Immun",
Prime_Lasermech_Upgrade2 = "+1 Schaden",
Prime_Lasermech_A_UpgradeDescription = "Freundliche Einheiten werden durch diesen Angriff keinen Schaden erleiden.",
Prime_Lasermech_B_UpgradeDescription = "Erh�ht den Startschaden um 1.",

Prime_ShieldBash_Name = "Spartanisches Schild",
Prime_ShieldBash_Description = "Schlage den Feind und drehe seine Angriffsrichtung.", 
Prime_ShieldBash_Upgrade1 = "Schild erh�hen",
Prime_ShieldBash_Upgrade2 = "+1 Schaden",
Prime_ShieldBash_A_UpgradeDescription = "Erhalte beim Schlagen einen Schild.",
Prime_ShieldBash_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Prime_Rockmech_Name = "Rock Launcher",
Prime_Rockmech_Description = "Wirf einen Stein auf ein ausgew�hltes Ziel. Felsen bleiben als Hindernis.", 
Prime_Rockmech_Upgrade1 = "+1 Schaden",
Prime_Rockmech_Upgrade2 = "+1 Schaden",
Prime_Rockmech_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Prime_Rockmech_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Prime_RightHook_Name = "Sidewinder Faust",
Prime_RightHook_Description = "Schlage eine angrenzendes Feld, besch�dige es und st��t es nach links.", 
Prime_RightHook_Upgrade1 = "+1 Schaden",
Prime_RightHook_Upgrade2 = "+1 Schaden",
Prime_RightHook_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Prime_RightHook_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Prime_RocketPunch_Name = "Rocket-Faust",
Prime_RocketPunch_Description = "Schlage ein angrenzendes Feld. Upgrades zum Starten als Projektil.", 
Prime_RocketPunch_Upgrade1 = "Rakete",
Prime_RocketPunch_Upgrade2 = "+2 Schaden",
Prime_RocketPunch_A_UpgradeDescription = "Feure die Faust.",
Prime_RocketPunch_B_UpgradeDescription = "Erh�ht Schaden um 2.",

Prime_Shift_Name = "Vize-Faust",
Prime_Shift_Description = "Nimm eine Einheit und wirf sie hinter dich.", 
Prime_Shift_Upgrade1 = "Verb�ndete Immun",
Prime_Shift_Upgrade2 = "+2 Schaden",
Prime_Shift_A_UpgradeDescription = "F�gt Verb�ndeten keinen Schaden zu.",
Prime_Shift_B_UpgradeDescription = "Erh�ht Schaden um 2.",

Prime_Flamethrower_Name = "Flammenwerfer",
Prime_Flamethrower_Description = "St��t das Ziel und l��t es brennen. Besch�digt Einheiten die schon brennen.", 
Prime_Flamethrower_Upgrade1 = "+1 Reichweite",
Prime_Flamethrower_Upgrade2 = "+1 Reichweite",
Prime_Flamethrower_A_UpgradeDescription = "Verl�ngert den Flammenwerferbereich um 1 Feld.",
Prime_Flamethrower_B_UpgradeDescription = "Verl�ngert den Flammenwerferbereich um 1 Feld.",

Prime_Areablast_Name = "Explosive Entl�ftung",
Prime_Areablast_Description = "Sprengen Sie alle angrenzenden Felder.", 
Prime_Areablast_Upgrade1 = "+1 Schaden",
Prime_Areablast_Upgrade2 = "+1 Schaden",
Prime_Areablast_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Prime_Areablast_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Prime_Spear_Name = "Prime Speer", 				 
Prime_Spear_Description = "Triff mehrere Felder und sto�e das am weitesten entfernte Feld.", 
Prime_Spear_Upgrade1 = "S�uretip",
Prime_Spear_Upgrade2 = "+1 Reichweite",
Prime_Spear_A_UpgradeDescription = "F�gt S�ure den weitesten Feind hinzu.",
Prime_Spear_B_UpgradeDescription = "Erh�ht die maximale Anzahl der getroffenen Felder um 1.",

Prime_Leap_Name = "Hydraulische Beine",
Prime_Leap_Description = "Springe zu einem Feld, besch�dige es selbst und angrenzende Felder.", 
Prime_Leap_Upgrade1 = "+ 1 Schaden jeweils",
Prime_Leap_Upgrade2 = "+1 Schaden",
Prime_Leap_A_UpgradeDescription = "Erh�ht den Schaden an Selbst und Zielen um 1.",
Prime_Leap_B_UpgradeDescription = "Erh�ht den Schaden an Zielen um 1.",

Prime_SpinFist_Name = "Vortex-Faust",
Prime_SpinFist_Description = "Besch�dige und schiebe alle benachbarten Felder nach links.", 
Prime_SpinFist_Upgrade1 = "-1 Eigenschaden",
Prime_SpinFist_Upgrade2 = "+1 Schaden",
Prime_SpinFist_A_UpgradeDescription = "Verringert den Schaden, den der Mech erleidet, wenn er diese Waffe benutzt, um 1.",
Prime_SpinFist_B_UpgradeDescription = "Erh�ht den Schaden an Zielen um 1.",

Prime_Sword_Name = "Titanitklinge",
Prime_Sword_Description = "Schwinge ein massives Schwert um 3 Felder zu besch�digen und zu sto�en.", 
Prime_Sword_Upgrade1 = "+1 Verwendung",
Prime_Sword_Upgrade2 = "+2 Schaden",
Prime_Sword_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Prime_Sword_B_UpgradeDescription = "Erh�ht den Schaden auf jedem betroffenen Feld um 2.",


Prime_Smash_Name = "Merkur-Faust",
Prime_Smash_Description = "Kracht auf den Boden, f�gt hohen Schaden zu und st��t angrenzende Felder.", 
Prime_Smash_Upgrade1 = "+1 Verwendung",
Prime_Smash_Upgrade2 = "+1 Schaden",
Prime_Smash_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Prime_Smash_B_UpgradeDescription = "Erh�ht Schaden um 1.",


----------------------------------------------------------------------------------------------------------------------------
------------------------ BRUTE WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Brute_Tankmech_Name = "Stier-Kanone",
Brute_Tankmech_Description = "Feuert ein m�chtiges Projektil ab, das sein Ziel besch�digt und st��t.", 
Brute_Tankmech_Upgrade1 = "+1 Schaden",
Brute_Tankmech_Upgrade2 = "+1 Schaden",
Brute_Tankmech_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Brute_Tankmech_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Brute_Jetmech_Name = "Luftbomben",
Brute_Jetmech_Description = "Fliege �ber ein Ziel und lasse eine explosive Rauchbombe fallen.", 
Brute_Jetmech_Upgrade1 = "+1 Schaden",
Brute_Jetmech_Upgrade2 = "+1 Reichweite",
Brute_Jetmech_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Brute_Jetmech_B_UpgradeDescription = "Erm�glicht das �berspringen und Angreifen eines zus�tzlichen Ziels.",

Brute_Mirrorshot_Name = "Januskanone",
Brute_Mirrorshot_Description = "Feuere zwei Projektile in entgegengesetzte Richtungen.", 
Brute_Mirrorshot_Upgrade1 = "+1 Schaden",
Brute_Mirrorshot_Upgrade2 = "+1 Schaden",
Brute_Mirrorshot_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Brute_Mirrorshot_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Brute_PhaseShot_Name = "Phasenkanone",
Brute_PhaseShot_Description = "Schie�t ein Projektil durch Objekte hindurch.", 
Brute_PhaseShot_Upgrade1 = "Phasenschild",
Brute_PhaseShot_Upgrade2 = "+1 Schaden",
Brute_PhaseShot_A_UpgradeDescription = "Wendet ein Schild auf Geb�ude an, durch die der Schuss hindurchgeht.",
Brute_PhaseShot_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Brute_Grapple_Name = "Enterhaken",
Brute_Grapple_Description = "Benutze einen Greifer, um Mech zu Objekten oder Einheiten zum Mech zu ziehen.", 
Brute_Grapple_Upgrade1 = "Schilde Verb�ndete",
Brute_Grapple_Upgrade2 = "",
Brute_Grapple_A_UpgradeDescription = "Wenn es auf einer verb�ndeten Einheit benutzt wird, gibt es ihnen einen Schild.",
Brute_Grapple_B_UpgradeDescription = "",

Brute_Shrapnel_Name = "Def. Schrapnell",
Brute_Shrapnel_Description = "Feuere ein nicht besch�digendes Geschoss ab, das Felder run um das Ziel st��t.", 
Brute_Shrapnel_Upgrade1 = "",
Brute_Shrapnel_Upgrade2 = "",
Brute_Shrapnel_A_UpgradeDescription = "",
Brute_Shrapnel_B_UpgradeDescription = "",

Brute_Sniper_Name = "Rail-Kanone",
Brute_Sniper_Description = "Geschoss, das weiter entfernten Zielen mehr Schaden zuf�gt.", 
Brute_Sniper_Upgrade1 = "+1 Maximaler Schaden",
Brute_Sniper_Upgrade2 = "+1 Maximaler Schaden",
Brute_Sniper_A_UpgradeDescription = "Erh�ht den maximalen Schaden um 1.",
Brute_Sniper_B_UpgradeDescription = "Erh�ht den maximalen Schaden um 1.",

Brute_Shockblast_Name = "Schockkanone",
Brute_Shockblast_Description = "Feuere ein Projektil ab, das zwei Felder ??trifft und st��t sie in entgegengesetzte Richtungen.", 
Brute_Shockblast_Upgrade1 = "+1 Schaden",
Brute_Shockblast_Upgrade2 = "+1 Schaden",
Brute_Shockblast_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Brute_Shockblast_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Brute_Beetle_Name = "Rammende Motoren",
Brute_Beetle_Description = "Fliege in einer Linie und krache in das Ziel, st��t und verletzt sich selbst dabei.", 
Brute_Beetle_Upgrade1 = "+ 1 Schaden jeweils",
Brute_Beetle_Upgrade2 = "+1 Schaden",
Brute_Beetle_A_UpgradeDescription = "Erh�ht den Schaden an Selbst und Ziel um 1.",
Brute_Beetle_B_UpgradeDescription = "Erh�ht den Schaden am Ziel um 1.",

Brute_Unstable_Name = "Instabile Kanone",
Brute_Unstable_Description = "M�chtiges Projektil, das sowohl dem Sch�tzen als auch Zielen Schaden zuf�gt.", 
Brute_Unstable_Upgrade1 = "+ 1 Schaden jeweils",
Brute_Unstable_Upgrade2 = "+1 Schaden",
Brute_Unstable_A_UpgradeDescription = "Erh�ht den Schaden an Selbst und Ziel um 1.",
Brute_Unstable_B_UpgradeDescription = "Erh�ht den Zielschaden um 1.",

Brute_Heavyrocket_Name = "Schwere Rakete",
Brute_Heavyrocket_Description = "Feuere ein Projektil ab, das ein Ziel schwer besch�digt und benachbarte Felder st��t.", 
Brute_Heavyrocket_Upgrade1 = "+1 Verwendung",
Brute_Heavyrocket_Upgrade2 = "+2 Schaden",
Brute_Heavyrocket_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Brute_Heavyrocket_B_UpgradeDescription = "Erh�ht Schaden um 2.",

Brute_Splitshot_Name = "Schrapnellkanone",
Brute_Splitshot_Description = "Schie�e ein Projektil, dass das Ziel und das Feld rechts und links davon besch�digt und st��t.", 
Brute_Splitshot_Upgrade1 = "+1 Verwendung",
Brute_Splitshot_Upgrade2 = "+1 Schaden",
Brute_Splitshot_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Brute_Splitshot_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Brute_Bombrun_Name = "Astra-Bomben",
Brute_Bombrun_Description = "Springe �ber eine Distanz, wirft Bomben bei jedem Feld das du querst.", 
Brute_Bombrun_Upgrade1 = "+1 Verwendung",
Brute_Bombrun_Upgrade2 = "+2 Schaden",
Brute_Bombrun_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Brute_Bombrun_B_UpgradeDescription = "Erh�ht den Schaden an allen Feldern um 2.",

Brute_Sonic_Name = "Hermes-Motoren",
Brute_Sonic_Description = "Schie�e in eine Linie und sto�e angrenzende Felder??ab.", 
Brute_Sonic_Upgrade1 = "",
Brute_Sonic_Upgrade2 = "",
Brute_Sonic_A_UpgradeDescription = "",
Brute_Sonic_B_UpgradeDescription = "",


----------------------------------------------------------------------------------------------------------------------------
------------------- RANGED MECH WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Ranged_Artillerymech_Name = "Artemis Artillerie",
Ranged_Artillerymech_Description = "M�chtiger Artillerieschlag, der ein einzelnes Feld besch�digt und angrenzende Felder st��t.", 
Ranged_Artillerymech_Upgrade1 = "Geb�ude sind Immun",
Ranged_Artillerymech_Upgrade2 = "+2 Schaden",
Ranged_Artillerymech_A_UpgradeDescription = "Dieser Angriff wird Geb�ude nicht mehr besch�digen.",
Ranged_Artillerymech_B_UpgradeDescription = "Erh�ht Schaden um 2.",

Ranged_Rockthrow_Name = "Steinbeschleuniger",
Ranged_Rockthrow_Description = "Starte einen Steinen auf einem Feld, schiebe angrenzende Felder.", 
Ranged_Rockthrow_Upgrade1 = "+1 Schaden",
Ranged_Rockthrow_Upgrade2 = "",
Ranged_Rockthrow_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Ranged_Rockthrow_B_UpgradeDescription = "",

Ranged_Defensestrike_Name = "Clusterartillerie",
Ranged_Defensestrike_Description = "Sch�tze ein Feld indem du die angrezenden besch�digst und st��t.", 
Ranged_Defensestrike_Upgrade1 = "Geb�ude sind Immun",
Ranged_Defensestrike_Upgrade2 = "+1 Schaden",
Ranged_Defensestrike_A_UpgradeDescription = "Dieser Angriff wird Geb�ude nicht mehr besch�digen.",
Ranged_Defensestrike_B_UpgradeDescription = "Erh�ht Schaden an angrenzende Felder um 1.",

Ranged_Rocket_Name = "Raketenartillerie",
Ranged_Rocket_Description = "Feuert eine sto�ende Artillerie ab und erschafft Rauch hinter dem Sch�tzen.", 
Ranged_Rocket_Upgrade1 = "+1 Schaden",
Ranged_Rocket_Upgrade2 = "+1 Schaden",
Ranged_Rocket_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Ranged_Rocket_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Ranged_Ignite_Name = "Vulkanische Artillerie",
Ranged_Ignite_Description = "Entz�nde das Ziel und schiebe angrenzende Felder weg.", 
Ranged_Ignite_Upgrade1 = "Nachbrenner",
Ranged_Ignite_Upgrade2 = "+2 Schaden",
Ranged_Ignite_A_UpgradeDescription = "Z�nde das Feld hinter dem Mech an.",
Ranged_Ignite_B_UpgradeDescription = "F�gt ausgew�hlten Feldern 2 Schadenspunkte hinzu.",

Ranged_ScatterShot_Name = "Mikroartillerie",
Ranged_ScatterShot_Description = "Artillerie mit dem Potenzial, mehrere kleine Projektile zu starten.", 
Ranged_ScatterShot_Upgrade1 = "+2 Felder",
Ranged_ScatterShot_Upgrade2 = "+1 Schaden",
Ranged_ScatterShot_A_UpgradeDescription = "F�ge zus�tzliche Raketen hinzu, um benachbarte Felder zu treffen.",
Ranged_ScatterShot_B_UpgradeDescription = "Erh�ht Schaden an allen Feldern um 1.",

Ranged_BackShot_Name = "Aegon M�rser",
Ranged_BackShot_Description = "F�gt zwei Feldern Schaden zu und schiebt einen nach vorne und einen nach hinten.", 
Ranged_BackShot_Upgrade1 = "+1 Schaden",
Ranged_BackShot_Upgrade2 = "+1 Schaden",
Ranged_BackShot_A_UpgradeDescription = "Erh�ht den Schaden bei beiden Feldern um 1.",
Ranged_BackShot_B_UpgradeDescription = "Erh�ht den Schaden bei beiden Feldern um 1.",

Ranged_Ice_Name = "Kryo-Launcher",
Ranged_Ice_Description = "Frieren dich und das Ziel ein.", 
Ranged_Ice_Upgrade1 = "",
Ranged_Ice_Upgrade2 = "",
Ranged_Ice_A_UpgradeDescription = "",
Ranged_Ice_B_UpgradeDescription = "",

Ranged_SmokeBlast_Name = "Rauchm�rser",
Ranged_SmokeBlast_Description = "Artillerieschuss der Rauch hinterl��t und 2 angrenzende Felder st��t.", 
Ranged_SmokeBlast_Upgrade1 = "",
Ranged_SmokeBlast_Upgrade2 = "",
Ranged_SmokeBlast_A_UpgradeDescription = "",
Ranged_SmokeBlast_B_UpgradeDescription = "",

Ranged_Fireball_Name = "Brennende Granate",
Ranged_Fireball_Description = "Artillerieangriff, der 5 Felder in Brand setzt.", 
Ranged_Fireball_Upgrade1 = "Kein Eigenschaden",
Ranged_Fireball_Upgrade2 = "",
Ranged_Fireball_A_UpgradeDescription = "Dieser Angriff wird den Mech, der ihn benutzt, nicht mehr besch�digen.",
Ranged_Fireball_B_UpgradeDescription = "",

Ranged_RainingVolley_Name = "Regnerischer Tod",
Ranged_RainingVolley_Description = "Ein gef�hrliches Projektil, das alles besch�digt, was es passiert.", 
Ranged_RainingVolley_Upgrade1 = "Geb�ude sind Immun",
Ranged_RainingVolley_Upgrade2 = "+ 1 Schaden jeweils",
Ranged_RainingVolley_A_UpgradeDescription = "Dieser Angriff wird Geb�ude nicht mehr besch�digen.",
Ranged_RainingVolley_B_UpgradeDescription = "Erh�ht den Schaden an Selbst und Zielen um 1.",

Ranged_Wide_Name = "Schwere Artillerie",
Ranged_Wide_Description = "M�chtiger Angriff, der ein gro�es Gebiet besch�digt.", 
Ranged_Wide_Upgrade1 = "+1 Verwendung",
Ranged_Wide_Upgrade2 = "+1 Schaden",
Ranged_Wide_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Ranged_Wide_B_UpgradeDescription = "Erh�ht Schaden um 1.",

Ranged_Dual_Name = "Gemini-Raketen",
Ranged_Dual_Description = "Starte zwei Raketen, besch�dige und schiebe zwei Ziele", 
Ranged_Dual_Upgrade1 = "+1 Verwendung",
Ranged_Dual_Upgrade2 = "+1 Schaden",
Ranged_Dual_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Ranged_Dual_B_UpgradeDescription = "Erh�ht Schaden um 1.",

--[[
Ranged_Marksman_Name = "Marskman's Ord.",
Ranged_Marksman_Description = "TBD.", 
Ranged_Marksman_Upgrade1 = "+1 Maximaler Schaden",
Ranged_Marksman_Upgrade2 = "+1 Maximaler Schaden",
Ranged_Marksman_A_UpgradeDescription = "Erh�ht den maximalen Schaden um 1.",
Ranged_Marksman_B_UpgradeDescription = "Erh�ht den maximalen Schaden um 1.",
]]--
----------------------------------------------------------------------------------------------------------------------------
------------------- SCIENCE MECH WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Science_Pullmech_Name = "Attraktion Puls",
Science_Pullmech_Description = "Ziehe das Ziel um 1 Feld zu dir.", 
Science_Pullmech_Upgrade1 = "",
Science_Pullmech_Upgrade2 = "",
Science_Pullmech_A_UpgradeDescription = "",
Science_Pullmech_B_UpgradeDescription = "",

Science_Gravwell_Name = "Grav Well",
Science_Gravwell_Description = "Artilleriewaffe, die ihr Ziel zu dir zieht.", 
Science_Gravwell_Upgrade1 = "",
Science_Gravwell_Upgrade2 = "",
Science_Gravwell_A_UpgradeDescription = "",
Science_Gravwell_B_UpgradeDescription = "",

Science_Repulse_Name = "Abwehr",
Science_Repulse_Description = "Sto�e alle benachbarten Felder.", 
Science_Repulse_Upgrade1 = "Sch�tze selbst",
Science_Repulse_Upgrade2 = "Sch�tze Freunde",
Science_Repulse_A_UpgradeDescription = "Erzeugt ein pers�nliches Schild, wenn es benutzt wird.",
Science_Repulse_B_UpgradeDescription = "Schirme benachbarten Verb�ndeten oder Geb�ude.",

Science_Swap_Name = "Teleporter",
Science_Swap_Description = "Wechsle Orte mit nahegelegenen Feldern.", 
Science_Swap_Upgrade1 = "+1 Reichweite",
Science_Swap_Upgrade2 = "+2 Reichweite",
Science_Swap_A_UpgradeDescription = "Erweitert den Bereich des Wechsels um 1 Feld.",
Science_Swap_B_UpgradeDescription = "Erweitert den Bereich des Wechsels um 2 Felder.",
  
Science_AcidShot_Name = "S�ureprojektor",
Science_AcidShot_Description = "Feuere ein Projektil ab, das S�ure zuf�gt und st��t.", 
Science_AcidShot_Upgrade1 = "",
Science_AcidShot_Upgrade2 = "",
Science_AcidShot_A_UpgradeDescription = "",
Science_AcidShot_B_UpgradeDescription = "",

Science_Confuse_Name = "Verwirrschuss",
Science_Confuse_Description = "Feuere ein Projektil ab, das die Angriffsrichtung eines Ziels umdreht.", 
Science_Confuse_Upgrade1 = "",
Science_Confuse_Upgrade2 = "",
Science_Confuse_A_UpgradeDescription = "",
Science_Confuse_B_UpgradeDescription = "",

Science_SmokeDefense_Name = "Rauchpellets",
Science_SmokeDefense_Description = "Umgebe dich mit Rauch, um dich gegen Feinde in der N�he zu verteidigen.", 
Science_SmokeDefense_Upgrade1 = "Verb�ndete Immun",
Science_SmokeDefense_Upgrade2 = "+1 Verwendung",
Science_SmokeDefense_A_UpgradeDescription = "Blockiert rauch f�r sich selbst und Verb�ndete.",
Science_SmokeDefense_B_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",

Science_Shield_Name = "Schildprojektor",
Science_Shield_Description = "Sch�tzt Felder vor Schaden.", 
Science_Shield_Upgrade1 = "+1 Verwendung",
Science_Shield_Upgrade2 = "+3 Bereich",
Science_Shield_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Science_Shield_B_UpgradeDescription = "Schirmt 3 weitere Felder ab.",

Science_FireBeam_Name = "Feuerstrahl",
Science_FireBeam_Description = "Feuere einen Strahl, der Feuer in einer Linie anwendet.", 
Science_FireBeam_Upgrade1 = "+1 Verwendung",
Science_FireBeam_Upgrade2 = "",
Science_FireBeam_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Science_FireBeam_B_UpgradeDescription = "",

Science_FreezeBeam_Name = "Froststrahl",
Science_FreezeBeam_Description = "Feuere einen Strahl, der alles in einer Linie einfriert.", 
Science_FreezeBeam_Upgrade1 = "+1 Verwendung",
Science_FreezeBeam_Upgrade2 = "",
Science_FreezeBeam_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Science_FreezeBeam_B_UpgradeDescription = "",

Science_LocalShield_Name = "Schildarray",
Science_LocalShield_Description = "Wende einen Schild auf nahegelegene Felder an.", 
Science_LocalShield_Upgrade1 = "+1 Gr��e",
Science_LocalShield_Upgrade2 = "+1 Verwendung",
Science_LocalShield_A_UpgradeDescription = "Wirkungsbereich um 2 Felder erh�ht.",
Science_LocalShield_B_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",

Science_PushBeam_Name = "Beamschlag",
Science_PushBeam_Description = "Schl�gt alle Einheiten in einer Linie.", 
Science_PushBeam_Upgrade1 = "Unbegrenzte Nutzung",
Science_PushBeam_Upgrade2 = "",
Science_PushBeam_A_UpgradeDescription = "Entfernt Nutzungsbeschr�nkungen in K�mpfen.",
Science_PushBeam_B_UpgradeDescription = "",


----------------------------------------------------------------------------------------------------------------------------
------------------- SUPPORT WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Skill_Repair_Name = "Mech Reparatur",
Skill_Repair_Description = "Repariere 1 Schaden und entferne Feuer, Eis und S�ure.",

Skill_Repair_Power_Name = "Energiereparatur",
Skill_Repair_Power_Description = "Repariere Mech und sto�e benachbarte Felder.",

Skill_Repair_Punch_Name = "Mantis Slash",
Skill_Repair_Punch_Description = "Sch�digt und st��t angrenzende Felder.\nFliehe vom Eis.",

Support_Boosters_Name = "Booster",
Support_Boosters_Description = "Springe vorw�rts und schiebe angrenzende Felder weg.", 
Support_Boosters_Upgrade1 = "",
Support_Boosters_Upgrade2 = "",
Support_Boosters_A_UpgradeDescription = "",
Support_Boosters_B_UpgradeDescription = "",

Support_Smoke_Name = "Rauchbomben",
Support_Smoke_Description = "Fliege �ber die Ziele, w�hrend du Rauch fallen l�sst.", 
Support_Smoke_Upgrade1 = "+1 Reichweite",
Support_Smoke_Upgrade2 = "+1 Reichweite",
Support_Smoke_A_UpgradeDescription = "Erh�ht den m�glichen Bewegungsbereich um 1.",
Support_Smoke_B_UpgradeDescription = "Erh�ht den m�glichen Bewegungsbereich um 1.",

Support_Refrigerate_Name = "W�rmekonverter",
Support_Refrigerate_Description = "Friert das Feld vorne, verbrennt das Feld hinterbei.", 
Support_Refrigerate_Upgrade1 = "+1 Verwendung",
Support_Refrigerate_Upgrade2 = "",
Support_Refrigerate_A_UpgradeDescription = "Erh�ht gebrauch pro Kampf um 1.",
Support_Refrigerate_B_UpgradeDescription = "",

Support_Destruct_Name = "Selbstzerst�rung",
Support_Destruct_Description = "Mech explodiert und t�tet sich selbst und alles, was am Mech angrenzt.", 
Support_Destruct_Upgrade1 = "",
Support_Destruct_Upgrade2 = "",
Support_Destruct_A_UpgradeDescription = "",
Support_Destruct_B_UpgradeDescription = "",

Support_Force_Name = "Pr�ventivschlag",
Support_Force_Description = "Rufe einen Luftangriff auf ein einzelnes Feld irgendwo auf der Karte an.", 
Support_Force_Upgrade1 = "",
Support_Force_Upgrade2 = "",
Support_Force_A_UpgradeDescription = "",
Support_Force_B_UpgradeDescription = "",

Support_SmokeDrop_Name = "Rauchabwurf",
Support_SmokeDrop_Description = "L�sst Rauch auf 5 Felder �berall auf der Karte fallen.", 
Support_SmokeDrop_Upgrade1 = "",
Support_SmokeDrop_Upgrade2 = "",
Support_SmokeDrop_A_UpgradeDescription = "",
Support_SmokeDrop_B_UpgradeDescription = "",

Support_Repair_Name = "Reparatur",
Support_Repair_Description = "Heile alle Spielereinheiten (einschlie�lich deaktivierter Mechs).", 
Support_Repair_Upgrade1 = "",
Support_Repair_Upgrade2 = "",
Support_Repair_A_UpgradeDescription = "",
Support_Repair_B_UpgradeDescription = "",

Support_Missiles_Name = "Sperrfeuer",
Support_Missiles_Description = "Feuert eine Sperrfeuer ab, die jeden Gegner auf der Karte trifft.", 
Support_Missiles_Upgrade1 = "+1 Schaden",
Support_Missiles_Upgrade2 = "",
Support_Missiles_A_UpgradeDescription = "Erh�ht Schaden um 1.",
Support_Missiles_B_UpgradeDescription = "",

Support_Wind_Name = "Windstrom",
Support_Wind_Description = "Sto�e alle Einheiten in eine Richtung.", 
Support_Wind_Upgrade1 = "Unbegrenzte Verwendung",
Support_Wind_Upgrade2 = "",
Support_Wind_A_UpgradeDescription = "Entfernt Nutzungsbeschr�nkungen in K�mpfen.",
Support_Wind_B_UpgradeDescription = "",

Support_Blizzard_Name = "Eis Regeneration",
Support_Blizzard_Description = "Friere dich und in der N�he liegende Felder ein.", 
Support_Blizzard_Upgrade1 = "+1 Gr��e",
Support_Blizzard_Upgrade2 = "+1 Gr��e",
Support_Blizzard_A_UpgradeDescription = "Effektbereich ums 1 vergr��ert.",
Support_Blizzard_B_UpgradeDescription = "Effektbereich ums 1 vergr��ert.",

----------------------------------------------------------------------------------------------------------------------------
-------------- DEPOLOYABLE WEAPONS -----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------
--------------------------
Deploy_TankShot_Name = "Stock Kanone",
Deploy_TankShot_Description = "Feuere ein Projektil ab, das das Ziel verschiebt.", 
Deploy_TankShot_Upgrade1 = "",
Deploy_TankShot_Upgrade2 = "",
Deploy_TankShot_A_UpgradeDescription = "",
Deploy_TankShot_B_UpgradeDescription = "",

Deploy_TankShot2_Name = "Stock Kanone",
Deploy_TankShot2_Description = "Feuere ein Projektil ab, das das Ziel verschiebt und besch�digt.", 
Deploy_TankShot2_Upgrade1 = "",
Deploy_TankShot2_Upgrade2 = "",
Deploy_TankShot2_A_UpgradeDescription = "",
Deploy_TankShot2_B_UpgradeDescription = "",

DeploySkill_Tank_Name = "Leichter Panzer",
DeploySkill_Tank_Description = "Setze einen kleinen Panzer ein, um im Kampf zu helfen.", 
DeploySkill_Tank_Upgrade1 = "+2 Gesundheit",
DeploySkill_Tank_Upgrade2 = "+2 Schaden",
DeploySkill_Tank_A_UpgradeDescription = "Erh�ht die maximale Gesundheit des Panzers auf 3.",
DeploySkill_Tank_B_UpgradeDescription = "Erh�ht den Angriffsschaden des Panzers auf 2.",

--------------------
Deploy_ShieldTankShot_Name = "Schildschuss",
Deploy_ShieldTankShot_Description = "Sch�tzt ein einzelnes Feld.", 
Deploy_ShieldTankShot_Upgrade1 = "",
Deploy_ShieldTankShot_Upgrade2 = "",
Deploy_ShieldTankShot_A_UpgradeDescription = "",
Deploy_ShieldTankShot_B_UpgradeDescription = "",

Deploy_ShieldTankShot2_Name = "Schildschuss",
Deploy_ShieldTankShot2_Description = "Feuert ein Projektil ab, das ein einzelnes Feld abschirmt.", 
Deploy_ShieldTankShot2_Upgrade1 = "",
Deploy_ShieldTankShot2_Upgrade2 = "",
Deploy_ShieldTankShot2_A_UpgradeDescription = "",
Deploy_ShieldTankShot2_B_UpgradeDescription = "",

DeploySkill_ShieldTank_Name = "Schild-Tank",
DeploySkill_ShieldTank_Description = "Stelle einen Schild-Panzer auf, der Verb�ndeten Schilde geben kann.", 
DeploySkill_ShieldTank_Upgrade1 = "+2 Gesundheit",
DeploySkill_ShieldTank_Upgrade2 = "Projektil",
DeploySkill_ShieldTank_A_UpgradeDescription = "Erh�ht die maximale Gesundheit des Schild-Panzers auf 3.",
DeploySkill_ShieldTank_B_UpgradeDescription = "Der Schild-Panzer feuert ein Projektil das entfernte Ziele abschirmt.",


------------------

Deploy_AcidTankShot_Name = "S�ureschuss",
Deploy_AcidTankShot_Description = "Feuere ein Projektil ab, das S�ure auf ein Feld wirken l�sst.", 
Deploy_AcidTankShot_Upgrade1 = "",
Deploy_AcidTankShot_Upgrade2 = "",
Deploy_AcidTankShot_A_UpgradeDescription = "",
Deploy_AcidTankShot_B_UpgradeDescription = "",

Deploy_AcidTankShot2_Name = "S�ureschuss",
Deploy_AcidTankShot2_Description = "Feuere ein Projektil ab, das S�ure auf ein Feld wirken l�sst.", 
Deploy_AcidTankShot2_Upgrade1 = "",
Deploy_AcidTankShot2_Upgrade2 = "",
Deploy_AcidTankShot2_A_UpgradeDescription = "",
Deploy_AcidTankShot2_B_UpgradeDescription = "",

DeploySkill_AcidTank_Name = "S�urepanzer",
DeploySkill_AcidTank_Description = "Stelle einen Panzer bereit, der S�ure auf Ziele wirken l�sst.", 
DeploySkill_AcidTank_Upgrade1 = "+2 Gesundheit",
DeploySkill_AcidTank_Upgrade2 = "+Sto�en",
DeploySkill_AcidTank_A_UpgradeDescription = "Erh�ht die maximale Gesundheit des Panzers auf 3.",
DeploySkill_AcidTank_B_UpgradeDescription = "Der Angriff des Panzers st��t auch sein Ziel.",

--------------------
Deploy_PullTankShot_Name = "Ziehschuss",
Deploy_PullTankShot_Description = "Zieht ein einzelnes Feld.", 
Deploy_PullTankShot_Upgrade1 = "",
Deploy_PullTankShot_Upgrade2 = "",
Deploy_PullTankShot_A_UpgradeDescription = "",
Deploy_PullTankShot_B_UpgradeDescription = "",

DeploySkill_PullTank_Name = "Pull-Tank",
DeploySkill_PullTank_Description = "Setze einen Pull-Tank, der Ziele mit einem Projektil ziehen kann.", 
DeploySkill_PullTank_Upgrade1 = "+2 Gesundheit",
DeploySkill_PullTank_Upgrade2 = "Fliegt",
DeploySkill_PullTank_A_UpgradeDescription = "Erh�ht die maximale Gesundheit des Pull-Tanks auf 3.",
DeploySkill_PullTank_B_UpgradeDescription = "Verleiht dem Pull-Tank die F�higkeit zu fliegen.",


------------------

------ FOR OBSOLETE VERSIONS -------

DeploySkill_SGenerator_Name = "Schild-Tank",
DeploySkill_SGenerator_Description = "Stelle einen Schild-Panzer auf, der Verb�ndeten Schilde geben kann.", 
DeploySkill_SGenerator_Upgrade1 = "+2 Gesundheit",
DeploySkill_SGenerator_Upgrade2 = "Projektil",
DeploySkill_SGenerator_A_UpgradeDescription = "Erh�ht die HP des Schild-Panzers auf 3.",
DeploySkill_ShieldTank_B_UpgradeDescription = "Der Shield-Tank feuert stattdessen ein Projektil ab, mit dem du entfernte Ziele abschirmen kannst.",
--[[
Deploy_IceTankShot_Name = "Ice Shot",
Deploy_IceTankShot_Description = "Fire a projectile that freezes a single enemy.", 
Deploy_IceTankShot_Upgrade1 = "",
Deploy_IceTankShot_Upgrade2 = "",
Deploy_IceTankShot_A_UpgradeDescription = "",
Deploy_IceTankShot_B_UpgradeDescription = "",

Deploy_IceTankShot2_Name = "Ice Shot",
Deploy_IceTankShot2_Description = "Fire a projectile that freezes a single enemy.", 
Deploy_IceTankShot2_Upgrade1 = "",
Deploy_IceTankShot2_Upgrade2 = "",
Deploy_IceTankShot2_A_UpgradeDescription = "",
Deploy_IceTankShot2_B_UpgradeDescription = "",

DeploySkill_IceTank_Name = "Ice-Tank",
DeploySkill_IceTank_Description = "Deploy an Ice-Tank to that can freeze its targets.", 
DeploySkill_IceTank_Upgrade1 = "+1 Gesundheit",
DeploySkill_IceTank_Upgrade2 = "+1 Gesundheit",
DeploySkill_IceTank_A_UpgradeDescription = "Increases the Ice-Tank's Health by 1.",
DeploySkill_IceTank_B_UpgradeDescription = "Increases the Ice-Tank's Health by 1.",
]]--
--[[
SGenerator1_Attack_Name = "Shield Emitter",
SGenerator1_Attack_Description = "Shield the adjacent tiles.", 
SGenerator1_Attack_Upgrade1 = "",
SGenerator1_Attack_Upgrade2 = "",
SGenerator1_Attack_A_UpgradeDescription = "",
SGenerator1_Attack_B_UpgradeDescription = "",

DeploySkill_SGenerator_Name = "Schildgenerator",
DeploySkill_SGenerator_Description = "Launch a generator that will shield adjacent tiles.", 
DeploySkill_SGenerator_Upgrade1 = "Ignore Enemies",
DeploySkill_SGenerator_Upgrade2 = "+2 Gesundheit",
DeploySkill_SGenerator_A_UpgradeDescription = "The Shield Generator will not give shields to enemies.",
DeploySkill_SGenerator_B_UpgradeDescription = "Increases the Shield Generator's max health by 2.",]]


----------------------------------------------------------------------------------------------------------------------------
------------------- TECHNOVEK WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

-----
Vek_Beetle_Name = "Rammgeschwindigkeit",
Vek_Beetle_Description = "St��t �ber die Map, besch�digt und st��t das Ziel.", 
Vek_Beetle_Upgrade1 = "Rauch hinterbei",
Vek_Beetle_Upgrade2 = "+2 Schaden",
Vek_Beetle_A_UpgradeDescription = "Das Feld hinter wird zu Rauch.",
Vek_Beetle_B_UpgradeDescription = "Erh�ht Schaden um 2.",
-----
Vek_Hornet_Name = "Nadelschuss",
Vek_Hornet_Description = "Wird Nadeln auf die Feinde, st��t das entferntest getroffene Ziel.", 
Vek_Hornet_Upgrade1 = "Reichweite & Schaden",
Vek_Hornet_Upgrade2 = "Reichweite & Schaden",
Vek_Hornet_A_UpgradeDescription = "Erh�ht potentiell getroffene Feld um 1 und Schaden an allen Felder um 1.",
Vek_Hornet_B_UpgradeDescription = "Erh�ht potentiell getroffene Feld um 1 und Schaden an allen Felder um 1.",
-----
Vek_Scarab_Name = "Explosiver Goo",
Vek_Scarab_Description = "Artillerieattacke die ein Feld sch�digt und die angrenzenden Felder st��t.", 
Vek_Scarab_Upgrade1 = "+1 Feld",
Vek_Scarab_Upgrade2 = "+2 Schaden",
Vek_Scarab_A_UpgradeDescription = "Erh�ht Trefferbereich um 1 Feld.",
Vek_Scarab_B_UpgradeDescription = "Erh�ht Schaden um 2.",
----------------------------------------------------------------------------------------------------------------------------
------------------- MISSION WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

Acid_Tank_Attack_Name = "S�urekanone",
Acid_Tank_Attack_Description = "Schie�t ein Projektil das S�ure zuf�gt.", 

Acid_Death_Tooltip_Name = "S�ure versch�tten",
Acid_Death_Tooltip_Description = "Das aktuelle Feld wird ein Pool von S�ure.", 

Disposal_Attack_Name = "Disintegrator",
Disposal_Attack_Description = "L�se alle Zielfelder mit S�ure auf", 

Archive_ArtShot_Name = "Alter Erde Atillerie",
Archive_ArtShot_Description = "Schwach gegen moderne Artillerie, aber noch immer hilfreich.", 

Rocket_Launch_Name = "Satellitenabschuss",
Rocket_Launch_Description = "Schie�t einen Satelliten ins Weltall, zerst�rt den angrenzende Bereich.", 
	
Filler_Attack_Name = "Erdbeweger",
Filler_Attack_Description = "Verwandelt nahe Abgr�nde in normalen Grund.",

Terraformer_Attack_Name = "Terraformer",
Terraformer_Attack_Description = "L�scht alles Leben vor dem Terraformer aus.", 


----------------------------------------------------------------------------------------------------------------------------
------------------- SNOW BOT WEAPONS -------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

SnowtankAtk1_Name = "Cannon 8R Mark I",
SnowtankAtk1_Description = "Projektil das Ziel brennen l�sst.", 

SnowtankAtk2_Name = "Cannon 8R Mark II",
SnowtankAtk2_Description = "Schweres Projektil das Ziel brennen l�sst.", 

SnowlaserAtk1_Name = "BKR Beam Mark I",
SnowlaserAtk1_Description = "Durschlagender Schuss, Schaden nimmt auf Entfernung ab.", 

SnowlaserAtk2_Name = "BKR Beam Mark II",
SnowlaserAtk2_Description = "Durschlagender Schuss, Schaden nimmt auf Entfernung ab.", 

SnowartAtk1_Name = "Vk8 Rockets Mark I",
SnowartAtk1_Description = "Starte Raketen auf 3 Felder.", 

SnowartAtk2_Name = "Vk8 Rockets Mark II",
SnowartAtk2_Description = "Starte Raketen auf 3 Felder.", 

SnowmineAtk1_Name = "Minenleger",
SnowmineAtk1_Description = "Legt eine Eismine.", 


}