
local Global_Texts = {

-----COMBAT TUTORIAL
	Tutorial_InfoButton_Text = "Quando incontri nuovi nemici, assicurati di imparare le loro abilit�. \n\nTieni premuto $1 mentre muovi il mouse su di loro per esaminarle",
	Tutorial_InfoButton_Title = "Ispeziona unit�",

	Tutorial_CombatPower_Text = "Questa � la rete elettrica. Ogni volta che un edificio viene danneggiato, verr� ridotta. \n\nSe raggiunge lo zero, perderai la partita.",
	Tutorial_CombatPower_Title = "Rete elettrica",

    Tutorial_CombatAiming_Text = "Quando miri con un'arma, le caselle ARANCIONI ti mostrano dove puoi sparare.",
    Tutorial_CombatAiming_Title = "Obbiettivi validi",

	Tutorial_CombatMonster_Text = "Ogni attacco nemico viene mostrato prima che accada. Nel prossimo turno, questo nemico attaccher� gli edifici.\n\nSposta il mouse su un nemico per vedere i dettagli sul suo attacco.", 
	Tutorial_CombatMonster_Title = "Attacchi Nemici",

	Tutorial_CombatMech_Text = "Questo � il tuo Mech da Combattimento. Pu� sferrare un pugno su una qualsiasi casella adiacente.\n\nClicca sul tuo Mech, muovilo vicino al nemico, e colpiscilo con un pugno.", 
	Tutorial_CombatMech_Title = "Mech da Combattimento",
	
	Tutorial_DeadTutorial_Title = "Squadra Disabilitata",
	Tutorial_DeadTutorial_Text = "Tutti i tuoi Mech sono stati disabilitati. In una battaglia normale, i Vek procederebbero con i loro attacchi e la missione finirebbe.\n\nPer questo tutorial, i tuoi Mech sono stati completamente riparati.",

	Tutorial_CombatGameover_Text = "La tua Rete Elettrica � stata ridotta a zero. Normalmente questo significherebbe la fine del gioco.\n\nDato che questa � una simulazione, puoi continuare a combattere i Vek.", 
	Tutorial_CombatGameover_Title = "Fine della partita",

	Tutorial_CombatUndo_Text = "Non puoi colpire il nemico da questa posizione. Usa 'Annulla spostamento' per riposizionare il Mech!",
	Tutorial_CombatUndo_Title = "Annulla Spostamento",

	Tutorial_CombatPunch_Text = "Dai un pugno a questo nemico!",
	Tutorial_CombatPunch_Title = "",

	Tutorial_CombatPush_Text = "Il pugno del tuo Mech ha SPOSTATO questa unit�. Adesso attaccher� una nuova posizione!\n\nGli spostamenti possono salvare gli edifici dagli attacchi dei nemici, o anche fare in modo che i nemici si colpiscano a vicenda.", 
	Tutorial_CombatPush_Title = "Spostare Nemici",

	Tutorial_CombatTank_Text = "Questo � il tuo Mech Tank.\n\nSpara proiettili che viaggiano in una linea retta finch� non colpiscono un altro oggetto.",
	Tutorial_CombatTank_Title = "Mech Tank",

	Tutorial_CombatComplete_Text = "In ogni missione, si vince sconfiggendo i Mech o combattendoli finch� non fuggono.",
	Tutorial_CombatComplete_Title = "Completare le Missioni",

	Tutorial_CombatBonus_Text = "Le Missioni hanno anche obbiettivi bonus.\n\nCompletare questi ultimi ti far� guadagnare risorse aggiuntive alla fine della battaglia.",
	Tutorial_CombatBonus_Title = "Obbiettivi Bonus",

	Tutorial_CombatWeapon_Text = "Clicca su un'arma per usarla. I tasti numerici funzionano da scorciatoia.\n\nNon potrai muoverti dopo aver usato un'arma.", 
	Tutorial_CombatWeapon_Title = "Uso dell'arma",

	Tutorial_CombatEnd_Text = "Quando tutti i tuoi Mech hanno effettuato un'azione o non ci sono altre mosse da effettuare, premi questo tasto per finire il tuo turno.",
	Tutorial_CombatEnd_Title = "Fine Turno",

--- MISSION TUTORIALS 

	Tutorial_Tanks_Text = "I carri armati sono online e ora possono essere controllati!",
	Tutorial_Tanks_Title = "Carri armati della Vecchia Terra",

	Tutorial_Terraform_Text = "Questa unit� Terraformer � sotto il tuo controllo durante questa missione.\n\nUsala per trasformare le caselle Erba in caselle Sabbia.",
	Tutorial_Terraform_Title = "Terraformer",

	Tutorial_VolatileVek_Text = "Il tuo obbiettivo bonus in questa missione � quello di non uccidere questo Vek.",
	Tutorial_VolatileVek_Title = "Volatile Vek",

---- STANDARTD TUTORIALS 

--	Tutorial_FinalIsland_Title = "Missione Finale",
	--Tutorial_FinalIsland_Text = "You may attempt the Final Mission now that you've completed two Islands. Alternatively, you can continue to secure more Islands. \n\nYour --choice should depend on how long you would like to play this timeline. The difficulty will always scale to your current progress.",
	
	Warning_Final = "Attenzione: Questa missione finale � ancora in sviluppo.\n\n� meno rifinita ed � ancora in fase di design.\n\nDovrebbe comunque essere giocabile. Buona fortuna!",
	
	Warning_OldSave = "Questo salvataggio � stato creato da una versione precedente di Into the Breach.\n\nDato che il gioco � ancora in sviluppo, non possiamo garantire una completa retrocompatibilit� per ogni aggiornamento e potresti riscontrare problemi con questo salvataggio\n\nDetto questo, c'� una buona probabilit� che non avrai nessun problema. Ci scusiamo per i possibili errori!",

	Tutorial_PoweredPilot_Title = "Pilota Attivo",
	Tutorial_PoweredPilot_Text = "Questo pilota � una macchina Senziente e richiede un Nucleo d'Energia per attivare la sua abilit� speciale.",

	Tutorial_Acid_Title = "A.C.I.D.",
	Tutorial_Acid_Text = "Questa unit� � affetta dall'A.C.I.D. Con le sue difese corrose, il Danno da Armi sar� raddoppiato\n\nTutti gli altri danni (Spinta, Fuoco, Blocco, etc.) non sono interessati.",

	Tutorial_Frozen_Text = "Questa unit� � CONGELATA. Non pu� muoversi o attaccare e rester� Congelata fino a che non ricever� danno.",
	Tutorial_Frozen_Title = "Unit� Congelata",

	Tutorial_Frozen_Mech_Text = "Questo Mech pu� usare la sua abilit� di Riparazione per liberarsi dal ghiaccio, ma non potr� poi muoversi o attaccare.",
	Tutorial_Frozen_Mech_Title = "Mech Congelato",
	
	Tutorial_Shield_Title = "Scudi d'Energia",
	Tutorial_Shield_Text = "Questo � uno scudo. Bloccher� il danno e ogni tipo di effetto negativo(Fuoco, Congelamento, A.C.I.D., etc.)\n\nSolo il danno diretto rimuover� lo scudo. Effetti negativi che non danneggiano non avranno alcun effetto.", 
	
	Tutorial_Armor_Title = "Unit� Corazzata",
	Tutorial_Armor_Text = "Questa unit� � Corazzata. Tutto il danno da armi verr� ridotto di 1\n\nTutti gli altri danni(Spinta, Fuoco, Blocco, etc.) non sono influenzati.",

	Tutorial_Environment_Text = "Questa missione ha un effetto speciale che accadr� ad ogni turno. \n\nSposta il mouse sull'icona nell'ambiente per ottenere pi� informazioni.",
	Tutorial_Environment_Title = "Effetto d'Ambiente",

	Tutorial_PowerGrid_Text = "La Rete Elettrica collega ogni Isola della corporazione. Ogni danno subito nelle missioni persiste tra le Isole.\n\nI Vek hanno causato danni prima che tu arrivassi, ma ci saranno opportunit� per ripristinare energia.",
	Tutorial_PowerGrid_Title = "Rete Elettrica Danneggiata",

	Tutorial_Overpower_Text = "Se la tua Rete Elettrica � piena quando riceve energia in pi�, la tua Difesa della Rete aumenter� permanentemente.",
	Tutorial_Overpower_Title = "Rete Elettrica Sovraccaricata",
	
	Tutorial_FullOverpower_Text = "Puoi Sovraccaricare la tua Rete Elettrica per ottenere solo un +25 di Difesa.",
	Tutorial_FullOverpower_Title = "Rete di Difesa Massimizzata",

	Tutorial_GridDefense_Text = "Questo edificio ha resistito al danno!\n\nLe possibilit� di un edificio di resistere al danno sono mostrate a destra della Barra d'Energia.",
	Tutorial_GridDefense_Title = "Difesa della Rete",

	Tutorial_Jelly_Text = "Questo Psion nemico procura un bonus passivo a tutti i Vek. Ucciderlo rimuove il bonus.\n\nSeleziona lo Psion e passa il mouse sul suo ritratto in basso a sinistra per ulteriori informazioni.",
	Tutorial_Jelly_Title = "Vek Psion",

	Tutorial_Webbed_Text = "Questa unit� � stata IMMOBILIZZATA! \n\nSposta il mouse sulle icone di status in basso a sinistra per scoprire cosa significa.",
	Tutorial_Webbed_Title = "Mech Immobilizzato",

	Tutorial_IslandNewGame_Text = "Puoi tentare di completare le isole che hai sbloccato nell'ordine che preferisci.\n\nLa difficolt� dei Vek cambier� in base a quante isole hai completato in questa partita.",
	Tutorial_IslandNewGame_Title = "Isole di Corporazione",

	Tutorial_Spawning_Text = "Una unit� nemica emerger� da qua nel prossimo turno!\n\nPuoi temporaneamente bloccare lo spuntare dei nemici, ma ci� dannegger� l'unit� che blocca.",
	Tutorial_Spawning_Title = "Nemici Emergenti",

	Tutorial_Forest_Text = "La FORESTA su questa casella ha preso danno, facendola diventare FUOCO.\n\nSe un'unit� sosta sul Fuoco, andr� a fuoco e prender� danno ad ogni turno.",
	Tutorial_Forest_Title = "Foresta Incendiata",

	Tutorial_Fire_Text = "Questo Mech sta andando a FUOCO! Prender� un danno ad ogni turno. \n\nI Mech possono RIPARARE gli effetti di stato, ma non possono attaccare nello stesso turno in cui si riparano.",
	Tutorial_Fire_Title = "Mech a Fuoco",

	Tutorial_DamagedMech_Text = "I tuoi Mech ripareranno automaticamente tutti i danni dopo un combattimento,\n\nSe un Mech � ridotto a 0 HP , il Pilota muore e il Mech viene disabilitato per il resto di quella battaglia.",
	Tutorial_DamagedMech_Title = "Mech Danneggiati",

	Tutorial_Corroded_Text = "Questo Mech � afflitto dall'A.C.I.D.! Corrode l'armatura dell'unit�, causando il raddoppio di ogni danno ricevuto.\n\nI Mech possono RIPARARE i loro effetti di stato, ma non possono attaccare nello stesso turno in cui si riparano.",
	Tutorial_Corroded_Title = "Mech Acidi",

	Tutorial_Pod_Text = "Questa Capsula contiene equipaggiamento dal futuro!\n\nPuoi raccoglierla col tuo Mech, o semplicemente difenderla fino alla fine della battaglia.",
	Tutorial_Pod_Title = "Capsule del Tempo",

	Tutorial_PodDestroyed_Title = "Capsule del Tempo Distrutte",
	Tutorial_PodDestroyed_Text = "La Capsula del Tempo su questa casella � stata distrutta!\n\nLe Capsule del Tempo vengono distrutte prendendo danno o se un nemico prende danno mentre si trova su di esse.",
		
	Tutorial_Water_Text = "I Mech non possono usare le loro armi mentre sono nell'Acqua.",
	Tutorial_Water_Title = "Robot Sommersi",
	
	Tutorial_WaterUndo_Text = "I Mech non possono usare le loro armi mentre sono nell'Acqua. \n\nPuoi usare Annulla Mossa se vuoi riposizionarlo.",
	Tutorial_WaterUndo_Title = "Robot Sommersi",

	Tutorial_DeadPilot_Text = "Il tuo Mech � stato disabilitato! Il suo Pilota � stato ucciso e il Mech non sar� in grado di agire per il resto della missione.",
	Tutorial_DeadPilot_Title = "Mech Disabilitati",

	Tutorial_Drowning_Text = "Questa unit� � caduta in Acqua, morendo all'istante!",
	Tutorial_Drowning_Title = "Unit� in Affogamento",

	Tutorial_PushDamage_Text = "Spingere le unit� nelle cose danneggia ulteriormente di 1 entrambi gli oggetti!",
	Tutorial_PushDamage_Title = "Spinta negli Oggetti",

	Tutorial_PushDeath_Text = "Spingere le unit� nelle cose danneggia ulteriormente di 1 entrambi gli oggetti!\n\nIn questo caso, il danno extra ha ucciso l'unit�!",
	Tutorial_PushDeath_Title = "Spinta negli Oggetti",
	
	Tutorial_TouchAgain_Title = "Tap to Confirm",
	Tutorial_TouchAgain_Text = "After selecting a location to shoot, if you're using a touch screen tap the same location again to confirm the shot",

	Tutorial_BuildingDamage_Text = "Questa casella con edificio � stata danneggiata, quindi la Rete Elettrica della tua citt� � stata ridotta.\n\nIl tuo obbiettivo principale � evitare che ci� accada!",
	Tutorial_BuildingDamage_Title = "Danno Edifici",

	Tutorial_Combat_Title = "Simulazione di Combattimento",
	Tutorial_Combat_Text = "C'� una Simulazione di Combattimento disponibile per tenere i nuovi Commanders aggiornati col combattimento meccanizzato.\n\nVorresti lanciare la simulazione?",

	Tutorial_Money_Title = "Reputazione di Corporazione",
	Tutorial_Money_Text = "Completando le regioni e gli obbiettivi bonus, la tua reputazione con la Corporazione locale aumenter�.\n\nPuoi spendere la tua reputazione su scorte alla fine dell'isola.",

	Tutorial_Cores_Title = "Nuclei di Energia",
	Tutorial_Cores_Text = "Adesso hai un Nucleo di Energia! Apri la Schermata di Potenziamento di un Mech e installalo.",

	Tutorial_Cores2_Title = "Installazione Nucleo",
	Tutorial_Cores2_Text = "Puoi usare questo tasto per installare un Nucleo di Energia in un Mech\n\nOgni Nucleo aumenter� il numero massimo di nuclei del Mech di uno.",

	Tutorial_Cores3_Title = "Modifiche all'Arma",
	Tutorial_Cores3_Text = "Puoi usare i Nuclei d'energia per attivare le modifiche alle armi.\n\nClicca su una modifica per alimentarla. Puoi sempre cliccare ancora per rimuovere il nucleo se vuoi utilizzarlo da qualche altra parte.",

	Tutorial_Weapon_Title = "Nuova Arma",
	Tutorial_Weapon_Text = "Hai appena ottenuto una nuova arma! Puoi equipaggiarla nella Schermata di Potenziamento.",

	Tutorial_Pilot_Title = "Nuovo Pilota",
	Tutorial_Pilot_Text = "Hai appena ottenuto un nuovo Pilota! Puoi assegnarlo nella Schermata di Potenziamento.",
	
	---Beta warning for squad unlock change
	
	Tutorial_OldProfile_Title = "Vecchio Profilo",
	Tutorial_OldProfile_Text = "Questo gioco � stato aggiornato e vecchi profili in beta potrebbero incontrare alcune stranezze dopo questi cambiamenti.\n\nIl tuo totale delle Monete Achievement potrebbe essere negativo ora a causa di alcuni cambiamenti nel prezzo dei Mech precedentemente sbloccati. Il gioco � funzionante, ti serviranno solo pi� achievements per metterti in pari.\n\nSe hai una partita in corso, potrebbe non essere caricata correttamente. Spero funzioni ancora, ma chiedo scusa se non sar� cos�.", 
		
	---Tutorial Large Screens
	Tutorial_Weapons = "EFFETTI DELLE ARMI",
	Tutorial_WeaponsText = "Quando si mira con un'arma o si esamina un attacco nemico, delle icone ti mostreranno esattamente cosa succeder�.",
	Tutorial_Weapons_Push = "SPINTA",
	Tutorial_Weapons_PushText = "Una freccia su una casella significa che un'unit� su quella casella verr� spinta",
	Tutorial_Weapons_Damage = "DANNO",
	Tutorial_Weapons_DamageText = "Un numero su una casella significa che l'unit� su quella casella verr� danneggiata",
	Tutorial_Weapons_PushDamage = "SPINTA + DANNO",
	Tutorial_Weapons_PushDamageText = "Alcune armi possono causare multipli effetti su una singola casella",
	
	Tutorial_Art = "MECH D'ARTIGLIERIA",
	Tutorial_ArtText = "Le armi d'Artiglieria possono sparare oltre ostacoli come le montagne, ma non possono sparare nelle caselle adiacenti al Mech.",
	Tutorial_ArtExtra = "L'arma del Mech di Artiglieria dannegger� solo l'unit� nella casella CENTRALE, mentre le unit� adiacenti verranno spostate.",
	
	Tutorial_Rewards = "PREMI MISSIONE",
	Tutorial_RewardsText = "Ogni missione ha diversi premi ottenibili dopo aver completato obbiettivi bonus\n   Non sarai in grado di completare ogni missione sull'Isola, quindi scegli attentamente!",
	Tutorial_Rewards_Cores = "NUCLEI DI ENERGIA: Usati per potenziare i tuoi Mech.",
	Tutorial_Rewards_Power = "ENERGIA ELETTRICA: Ripristina la tua Rete Elettrica. Se la tua Rete Elettrica raggiunge lo zero, perdi.",
	Tutorial_Rewards_Reputation = "REPUTAZIONE CON CORP.: Usata per acquistare oggetti una volta che l'isola � completata.",
	Tutorial_Rewards_Difficulty = "ATTENZIONE: Missioni con pi� potenziali premi avranno pericoli aggiuntivi!",
	Tutorial_RegionName = "Safeguard Valley",
	
	Tutorial_Final = "MISSIONE FINALE",
	Tutorial_FinalText = "Dopo aver completato due isole, la Missione Finale � disponibile per essere completata.",
	Tutorial_Final_ScalingTitle = "Difficolt�",
	Tutorial_Final_Scaling = "La difficolt� di questa battaglia cambia in base al tuo attuale progresso. Combattere ora sar� una sfida ora tanto quanto lo sar� dopo aver completato altre isole",
	Tutorial_Final_ScoringTitle = "Popolazione",
	Tutorial_Final_Scoring = "Completare pi� isole prima della Missione Finale ti permetter� di salvare pi� persone e aumentare il tuo punteggio finale.",
	
	Tutorial_StartCombat = "Inizia simulazione",
	Tutorial_DeclineCombat = "Rifiuta",
	Tutorial_DeclineAll = "No, so cosa sto facendo (Nascondi TUTTI gli aiuti futuri)",
	
	Tutorial_Dismiss = "(Clicca per chiudere)",
	
	--tooltips
	TipTitle_FinalMission = "Missione Finale",
	TipText_FinalMission = "Puoi completare la Missione Finale in qualsiasi momento dopo aver completato due Isole.\n\nLa difficolt� della missione si adatta al tuo progresso corrente.", 

	
	TipTitle_Reputation = "Reputazione di Corporazione",
	TipText_Reputation = "Usa i punti di reputazione per acquistare risorse una volta che l'Isola � completata.",
	TipTitle_Cores = "Nuclei di Energia",
	TipText_Cores = "Usati per potenziare i tuoi Mech\n\nApri il men� di potenziamento dei Mech cliccando sul ritratto di un Mech a sinistra.",
	
	TipTitle_Order = "Ordine di Attacco",
	TipText_Order = "Passa il mouse qui o premi il tasto ALT per mostrare l'ordine di attacco dei nemici.",
	TipText_Menu = "Men� di Gioco[ESC]",
	TipTitle_Menu = "Apri il Men� di Gioco",
	
	TipText_Overlay = "Mostra l'ordine in cui le azioni verranno eseguite nel turno nemico. Scorciatoia: [$1]",
	TipTitle_Overlay = "Ordine di Attacco",
	
	TipText_TimerBattle = "Da quanto tempo � in corso la partita corrente.\n\nPuoi nascondere questo timer nel men� delle Opzioni.",
	TipTitle_TimerBattle = "Tempo di Gioco",
	
	TipText_ResetTurn = "Torna indietro all'inizio del turno corrente. Disponibile dopo aver eseguito almeno un'azione.\n\nPuoi usare questa opzione solo una volta per ogni battaglia.",
	TipTitle_ResetTurn = "Resetta Turno",
	
	TipText_ResetTurnUsed = "Puoi usarlo solo una volta per battaglia.",
	TipTitle_ResetTurnUsed = "Reset del Turno Usato",
	
	TipText_ResetTurnExtra = "Torna indietro all'inizio del turno corrente. Disponibile dopo aver eseguito almeno un'azione.\n\nIl tuo Pilota ti concede un Reset extra per ogni battaglia. Te ne restano 2.",
	TipTitle_ResetTurnExtra = "Resetta Turno",
	
	TipText_ResetTurnFinal = "Torna indietro all'inizio del turno corrente. Disponibile dopo aver eseguito almeno un'azione.\n\nTe ne resta 1.",
	TipTitle_ResetTurnFinal = "Resetta Turno",
	
	TipText_CombatSpeed = "Modifica quanto velocemente le unit� nemiche eseguono il suo turno. \n\nRallentalo se sei nuovo e hai problemi nel seguire le azioni del nemico, velocizzalo se hai esperienza e ti trovi comodo col combattimento.",
	TipTitle_CombatSpeed = "Velocit� di Combattimento",
	
	TipText_Abandon = "Termina questo tentativo e manda un Pilota indietro nel tempo per riprovare.",
	TipTitle_Abandon = "Abbandona Timeline",	
	
	TipTitle_TutorialTips = "Suggerimenti",
	TipText_TutorialTips = "Mostra dei Suggerimenti durante il gioco.\n\nEstremamente consigliato per i nuovi giocatori.",
	
	TipTitle_BoardScale = "Massima Scala del Tabellone",
	TipText_BoardScale = "Modifica la Scala di rendering del tabellone.\n\nPu� essere utile per diminuire la scala per monitor pi� grandi.\n\nLa scala corrente � : $1",
	
	TipTitle_DefaultRes = "Finestra di Default",
	TipText_DefaultRes = "Ripristina il gioco alla sua finestra di default da 720p. Raccomandato per lo streaming.",
	
	TipTitle_AudioMuted = "",
	TipText_AudioMuted = "L'audio � correntemente muto",
		
	TipTitle_Timer = "Timer di Gioco",
	TipText_Timer = "Aggiunge un Timer di Gioco all'Interfaccia.\n\nUtile per ottenere l'achievement 'Lightning War' o per fare speedrun",
	
	TipTitle_Colorblind = "Modalit� per Daltonici",
	TipText_Colorblind = "Cambia alcuni colori e aggiunge icone addizionali per aiutare i giocatori daltonici.\n\nFacci sapere se vorresti migliorare qualcosa di questa impostazione.",
	
	TipTitle_LargeFont = "Caratteri pi� grandi",
	TipText_LargeFont = "Aumenta la dimensione dei suggerimenti, i dialoghi e altri importanti messaggi.",
	
	TipTitle_NoLargeFont = "Caratteri pi� grandi non disponibili",
	TipText_NoLargeFont = "La tua finestra attuale � troppo piccola per supportare caratteri pi� grandi.",
	
	TipTitle_Confirm = "Conferma di Fine Turno",
	TipText_Confirm = "Ricevi una conferma quando tenti di finire il tuo turno e hai ancora azioni disponibili.",
	
	TipTitle_Stretch = "Adatta Scaling",
	TipText_Stretch = "Adatta la grafica a risoluzioni maggiori. \n\nUtile per monitor alte risoluzioni (1440p o pi�) se l'interfaccia � troppo piccola, ma potrebbe rendere i messaggi e l'arte poco definita.",
	
	TipTitle_Limit = "Limite di Frame",
	TipText_Limit = "Limita gli FPS a 60.\n\nRaccomandato per la maggior parte dei sistemi.",
	
	TipTitle_Shake = "Disabilita l'Agitazione di Schermo",
	TipText_Shake = "Disattiva l'agitazione dell'Interfaccia.\n\nL'agitamento � comunque durante il combattimento quando qualcuno arreca danno.",
	
	TipTitle_Coords = "Overlay Griglia Coordinate",
	TipText_Coords = "Aggiunge le Coordinate al tabellone.\n\nBuono per lo streaming, o per altre forme di condivisione del gioco.",
	
	TipTitle_NoStretch = "Adattamento dello Scaling non disponibile",
	TipText_NoStretch = "I tuoi Driver Video non supportano i requisiti necessari per questo. \n\nPerfavore aggiornali o contatta il supporto se necessiti di questa feature.",
	
	TipTitle_BattleVictory = "Vittoria",
	TipText_BattleVictory = "Tutti i nemici si ritireranno in $1 turni",
	TipText_BattleVictory_One = "Tutti i nemici si ritireranno in 1 turno",
	
	TipTitle_BattleVictory_Final = "Vittoria Finale",
	TipText_BattleVictory_Final = "La bomba esploder� in $1 turni",
	TipText_BattleVictory_One_Final = "La bomba esploder� in 1 turno",
	
	TipTitle_RepObj = "Obbiettivo Reputazione",
	TipText_RepObj = "Premia con Reputazione di Corporazione, usata per comprare equipaggiamento.",
	TipTitle_PodObj = "Capsula del Tempo",
	TipText_PodObj = "I contenuti di una Capsula del Tempo potrebbero essere utili per le battaglie future.",
	TipTitle_PowerObj = "Obbiettivo Energia",
	TipText_PowerObj = "Ristora Energia alla Rete Elettrica",
	TipTitle_CoreObj = "Obbiettivo Nucleo d'Energia",
	TipText_CoreObj = "Premia con un Nucleo d'Energia, usato per potenziare i Mech.",
	TipTitle_Saved = "Persone salvate",
	TipText_Saved = "Il numero di persone che hai salvato in questa linea del tempo\n\nAlte difficolt� hanno pi� persone negli edifici durante una battaglia.",
	TipTitle_UpgradeReactor = "Reattore Mech",
	TipText_UpgradeReactor = "Puoi usare l'Energia dei Nuclei per migliorare le tue armi, o aggiungerne altre. \n\nInstalla i Nuclei d'Energia per potenziare il reattore di un Mech.",
	TipTitle_UndoCore = "Annulla installazione Nucleo",
	TipText_UndoCore = "Annulla le recenti installazioni di Nuclei.",
	TipTitle_Health = "Vita del Mech",
	TipText_Health = "",
	TipTitle_Move = "Movimento del Mech",
	TipText_Move = "",
	
	TipTitle_ZoltanHealth = "Vita Zoltan",
	TipText_ZoltanHealth = "Il Pilota Zoltan annulla l'incremento di HP di questo Mech",
	
	TipTitle_MechClass = "Classe Mech",
	TipText_MechClass = "La Classe del Mech determina che tipo di arma pu� usare in modo efficacie. \n\nLe armi che non sono della stessa classe costeranno 1 Nucleo d'Energia extra.",
	
	TipTitle_Cyborg = "Classe Cyborg",
	TipText_Cyborg = "La classe Cyborg richiede 1 Nucleo d'Energia extra per usare una qualsiasi arma non-Cyborg.",
	
	TipText_RenamePilot = "Clicca per rinominare questo Pilota.",
	TipTitle_RenamePilot = "Rinomina Pilota",
	TipText_RenameMech = "Clicca per rinominare questo Mech.",
	TipTitle_RenameMech = "Rinomina Mech",
	
	TipTitle_PilotMax = "Livello Massimo",
	TipText_PilotMax = "Questo pilota ha sbloccato tutte le sue abilit�!",
	TipTitle_PilotExperience = "Esperienza Pilota",
	TipText_PilotExperience = "Quando questo pilota guadagner� pi� esperienza nel combattimento, sbloccher� ulteriori abilit�.",
	TipTitle_PilotAI = "Pilota AI di Base",
	TipText_PilotAI = "Le AI di Base operano gi� alla loro massima efficienza e non guadagnano esperienza in combattimento. \n\nTrova Piloti umani superiori, o AI Avanzate, per sostituire questa AI di Base.",
	
	TipText_GridDefense = "La possibilit� in percentuale che un edificio qualsiasi resista del danno. \n\nAumenta la percentuale guadagnando Energia quando la Rete Elettrica � piena.",
	TipTitle_GridDefense = "Difesa della Rete",
	TipText_PowerGrid = "Perdi se questa raggiunge lo zero. \n\nRidotta ogni volta che un Edificio viene danneggiato in combattimento.",
	TipTitle_PowerGrid = "Rete elettrica",
	
	TipTitle_BuyCore = "Nuclei d'Energia",
	TipText_BuyCore = "I Nuclei d'Energia sono usati per potenziare i tuoi Mech tra le missioni.",
	TipTitle_BuyPower = "Energia Elettrica",
	TipText_BuyPower = "Ripara il danno alla tua Rete Elettrica. \n\nSe la tua Rete Elettrica � piena, questo aumenter� permanentemente la tua percentuale di Difesa della Rete.",
	
	TipTitle_BuyPower_Grid = "Sovraccarica Rete",
	TipText_BuyPower_Grid = "La tua Rete Elettrica � satura. Ulteriore Energia potenzier� permanentemente la tua Difesa di Rete. \n\nIl bonus diminuir� all'aumentare della tua Difesa, fino ad un massimo di +25.",
	
	TipTitle_BuyPower_Full = "Rete Satura",
	TipText_BuyPower_Full = "Sia la tua Rete che la tua Difesa di Rete sono al loro massimo valore. \n\nNon puoi acquistare ulteriore Energia.",
	
	TipTitle_Mission_Normal = "Minaccia Vek Standard",
	TipText_Mission_Normal = "Nessuna caratteristica speciale per questa missione",
	TipTitle_Mission_Hard = "Alta Minaccia Vek",
	TipText_Mission_Hard = "Un ulteriore Vek Alpha sar� presente all'inizio della missione",
	TipTitle_Mission_Easy = "Difesa di Rete Attiva",
	TipText_Mission_Easy = "Alcuni edifici partono con uno Scudo gratuito",
	
	------ ENVIRONMENTS ---------
	
	TipTitle_Env_BeltLine = "Nastri Trasportatori",
	TipText_Env_BeltLine = "I nastri trasportatori spostano le unit� nella mappa",
	TipTitle_Env_BeltRandom = "Nastri Trasportatori",
	TipText_Env_BeltRandom = "I nastri trasportatori spostano le unit� nella mappa",
	TipTitle_Env_Airstrike = "Attacchi Aerei",
	TipText_Env_Airstrike = "Un bombardiere colpir� periodicamente alcune aree della mappa",
	TipTitle_Env_Tides = "Maremoti",
	TipText_Env_Tides = "La mappa sar� lentamente inondata dall'acqua",
	TipTitle_Env_Cataclysm = "Terremoti catastrofici",
	TipText_Env_Cataclysm = "La mappa si aprir� in un enorme abisso",
	TipTitle_Env_Seismic = "Attivit� Sismica",
	TipText_Env_Seismic = "Le caselle di Terra sprofonderanno in un abisso periodicamente, portando qualsiasi unit� con loro",
	TipTitle_Env_Lightning = "Tempesta di Fulmini",
	TipText_Env_Lightning = "Dei pericolosi Tuoni minacceranno la mappa, uccidendo qualsiasi cosa colpiranno",
	TipTitle_Env_SnowStorm = "Tempesta di Ghiaccio",
	TipText_Env_SnowStorm = "Grandi aree della mappa si congeleranno periodicamente",	
	
	---------- Island Descriptions
	
		
	Corp_Grass_Description = "Questa Isola-Museo ricrea la Vecchia Terra com'era prima che l'oceano si innalzasse e cancellasse quasi completamente l'umanit�.",
	Corp_Desert_Description = "Terraforming specialists, R.S.T. turned the environment against the Vek and nearly destroyed their Island in the process.",
	Corp_Snow_Description = "La Pinnacle Robotics combatte una guerra su due fronti, una contro i Vek, l'altra contro le sue stesse Armi Senzienti.",
	Corp_Factory_Description = "La tecnologia Detritus pu� scomporre qualsiasi materia nei suoi elementi base. Le loro citt�-fabbriche sono dedicate alla rimozione di rifiuti e al riciclo.",
	
	--Order Texts
	Order_Fire = "Danno Fuoco",
	Order_Psion = "Rigenerazione Psion",
	Order_Tentacle = "Tentacolo Psion",
	Order_Actions = "Azioni Nemiche",
	Order_NPC = "Azioni NPC",
	Order_NPC_Bots = "Azioni Bot NPC",
	Order_Emerge = "Nemici Emergono",
	Order_Env = "Ambiente",
	Order_Smoke = "Fumo di Tempesta",
	
	---Combat Texts
	Deploying_Mech = "Rilasciando $1",
	Deploying_Instructions = "Seleziona una casella nella Zona gialla di Rilascio",
	Deploying_Complete = "Rilascio completato",
	Deploying_Confirm = "Puoi cambiare i tuoi posizionamenti prima di confermare",
	Combat_Deployment = "RILASCIO",
	Deploy_Remaining = "Unit� Rimanenti:",
	Button_Deployment_Done = "CONFERMA",
	Button_Button_Pawnlist = "    Lista Unit�",
	Button_Button_Objectives = "Obbiettivi Bonus     ",
	
	Skip_Units = "Hai ancora unit� che possono agire. Perderanno il loro turno.",
	Reset_Turn = "Torni indietro nel tempo all'inizio del tuo turno?\n\nLimitazioni di Energia ti permettono di farlo solo una volta per battaglia.",
	Reset_TurnExtra = "Torni indietro nel tempo all'inizio del tuo turno?\n\nIl tuo Pilota con \"Reset Temporale\" ti permette di farlo 2 volte.",
	Reset_TurnFinal = "Torni indietro nel tempo all'inizio del tuo turno?\n\nTi resta solo un Reset.",
	Button_EndTurn = "Fine Turno",
	Button_Undo = "ANNULLA\nMOSSA",
	Button_UndoTurn = "RESET TURNO",
	Button_UndoTurnUsed = "RESET USATO",
	
	Active_Units = "Unit� Attive:",
	
	Objective_EnemyRetreat = "Vittoria in",
	Objective_EnemyRetreat2 = "turni",
	Objective_EnemyRetreat3 = "turno",
	
	Button_Editor_Exit = "MODIFICA MAPPA",
	Button_Done_Testing = "FINE TESTING",
	
	Disarm_Info = "[ Tasto Destro ]\noppure\n[ $1 ]\nper Disarmare",
	
	-- Skill Info
	Skill_Passive = "PASSIVO",
	Skill_ClassAny = "Qualsiasi",
	Skill_ClassTechnoVek = "Cyborg",
	Skill_ClassPassive = "Passiva",
	Skill_ClassPrime = "Prime",
	Skill_ClassDeath = "Alla Morte",
	Skill_ClassBrute = "Brute",
	Skill_ClassRanged = "Ranged",
	Skill_ClassScience = "Scienza",
	Skill_ClassEnemy = "Nemico",
	Skill_ClassString = "Arma di Classe $1",
	Skill_ClassPassString = "Effetto Passivo",
	Skill_Damage = "Danno:",
	Skill_SelfDamage = "Auto-Danno:",
	Skill_Limited = "Usi per battaglia:",
	
	Skill_WrongClass = "Nessuna Classe Mech compatibile. \nSi applica 1 Energia di penalit�.",
	Skill_CyborgOnly = "Arma Non-Cyborg",
	
	--- Pilot Info
	Pilot_Special = "Speciale",
	Pilot_PowerReq = "Richiede $1 energia",
	Pilot_Powered = "Alimentata",
	Pilot_None = "Nessuna",
	Pilot_Max = "Livello Massimo",
	Pilot_XP = "$1 / $2 xp",
	Pilot_Unknown = "Abilit� Sconosciuta",
	Pilot_UnknownText = "Ottieni esperienza per sbloccare questa abilit�.",
	Pilot_Skills = "Abilit�",
	Pilot_Experience = "Esperienza",
	Pilot_History = "Storia",
	Pilot_History_Timelines = "Linee del Tempo Precedenti: $1",
	Pilot_History_Final = "Battaglie Finali: $1",
	
	Pilot_HealthName = "Bonus Vita",
	Pilot_HealthShort = "+2 HP Mech",
	Pilot_HealthDesc = "La vita del Mech pilotato � aumentata di 2.",
	
	Pilot_MoveName = "Bonus Movimento",
	Pilot_MoveShort = "+1 Movimento Mech",
	Pilot_MoveDesc = "Il movimento del Mech pilotato aumenta di 1",
	
	Pilot_GridName = "Bonus Difesa Rete",
	Pilot_GridShort = "+3 DIF Rete",
	Pilot_GridDesc = "Difesa di Rete aumentata di 3. Questo influenza la possibilit� di resistere al Danno Edifici in combattimento.",
	
	Pilot_ReactorName = "Nucleo Bonus",
	Pilot_ReactorShort = "+1 Nucleo Mech",
	Pilot_ReactorDesc = "Reattore Mech pilotato aumenta di 1.",
	
	Pilot_XpString = "$1 / $2 xp",
	Pilot_XpMax = "Livello Massimo",
	Pilot_XpAI = "I Mech possono pilotarsi da soli, ma � meglio avere un Pilota specializzato",
	
	-- Gamepad instructions`
	Gamepad_SelectUnit = "Seleziona Unit�",
	Gamepad_PlaceUnit = "Posiziona Unit�",
	Gamepad_MoveUnit = "Muovi Unit�",
	Gamepad_FireWeapon = "Usa Arma",
	Gamepad_Cancel = "Annulla Tiro",
	
	--Combat State Labels
	State_Tutorial = "SIMULAZIONE INIZIATA",
	State_Gameover = "GAME OVER",
	State_Player = "TURNO GIOCATORE",
	State_Enemy = "TURNO NEMICO",
	State_Start = "INIZIO MISSIONE",
	State_Complete = "MISSIONE COMPLETATA",
	State_Disabled = "MECH DISABILITATO",
	State_Turns = "$1 Turni Restanti",
	State_LastTurn = "Ultimo Turno",
	
	--Upgrade Screen
	
	Upgrade_MoveLabel = "+1 Movimento",
	Upgrade_HealthLabel = "+2 Vita",
	Upgrade_Install = "INSTALLA",
	Upgrade_Max = "MASSIMO",
	Upgrade_Class = "Classe Mech: $1",
	Upgrade_Test = "Usa il Simulatore Virtuale per testare gli Equipaggiamenti dei Mech",
	Upgrade_Armory = "MAGAZZINO",
	Upgrade_Pilot = "PILOTA",
	Upgrade_Stats = "STATISTICHE",
	Upgrade_Reactor = "REATTORE",
	Upgrade_Move = "Movimento:",
	Upgrade_Health = "Vita:",
	Upgrade_Weapons = "ARMI ",
	Button_Upgrade_Test = "TESTA MECH",
	Button_Upgrade_Undo = "ANNULLA",
	Wrong_Cost = "Costa 1 energia \n          in pi� per usare",
	Wrong_Class = "Classe Sbagliata",
	Upgrade_Page = "Pagina $1 di $2",
	Upgrade_New = "NUOVO!",
	
	--Victory Screen
	Victory_RegionLost = "Regione Persa",
	Victory_FailedRewards = "Nessun premio per una missione fallita.",
	Victory_Simulation = "Simulazione Completa",
	Victory_SimulationText = "Congratulazioni per la tua prima missione di successo, Comandante! Sono fiducioso nella tua abilit� di salvare il pianeta dopo un allenamento cos� intensivo.",
	Objective_Title = "Obbiettivi Bonus",
	Objective_Title_One = "Obbiettivo Bonus",
	Objective_Title_Final = "Obbiettivo Primario",
	Victory_Civilians = "Civili Protetti",
	Victory_Title = "Regione Protetta",
	Pod_Title = "CAPSULA RECUPERATA",
	Pod_Contents = "Contenuti Capsula:",
	
	---Store
	Store_Core = "Nuclei d'Energia",
	Store_Cost = "Costo:  $1",
	Store_Equipped = "Equipaggiata",
	Store_Purchase = "Compra equipaggiamento usando       Reputazione", -- star image goes in here
	Store_Sell = "Dona armi e piloti per       Reputazione", --star image goes in here
	Store_SellTitle = "DONA",
	Store_BuyTitle = "ACQUISTA",
	Store_Weapons = "Armi",
	Store_Pilots = "Piloti",
	Leave_Confirm = "La tua Reputazione di Corporazione andr� persa se lasci l'isola ora.",
	SellPilot_Confirm = "Sei sicuro di voler assegnare questo pilota permanentemente a quest'Isola?\n(Guadagni Reputazione)",
	SellWeapon_Confirm = "Sei sicuro di voler donare quest'arma?\n(Guadagni Reputazione)",
	Buy_Confirm = "Are you sure you want to purchase this?",
	
	--Rewards
	Reward_Title = "Isola Perfetta!",
	Reward_Subheading = "Seleziona un premio gratuitamente",
	
	--- Misc
	Pod_Objective = "Proteggi la Capsula del tempo",
	Secret_Objective = "Proteggi la Capsula Strana",
	Secret_Objective_Failed = "Proteggi la Capsula Strana (Fallito)",
	Pod_Detected = "Capsula del Tempo Identificata",
	Pod_Failed = "Proteggi la Capsula del Tempo(Fallito)",
	Toggle_NeverAgain = "Non Chiedere Ancora",
	Mission_Map_Deploy = "Inizia Missione",
	Pawn_Box_Water = "\nSommerso",
	Pawn_Box_Acid = "\nSommerso",
	Pawn_Box_Smoke = "Fumo \nBlocco",
	Pawn_Box_Ice = "Ghiaccio \nBlocco",
	Pawn_Box_Shot = "Movimento Bonus \nSolo",
	Pawn_Box_Lava = "Lava \nBlocco",
	Boss_Title = "Attenzione: Offensiva Vek",
	Boss_Text = "I Vek stanno dominando 2 regioni sull'Isola. \nLe regioni che non salvi andranno perse per sempre.",
	Top_Power = "ENERGIA",
	Top_Grid = "RETE",
	Top_Defense = "DIFESA",
	Pilot_TurnOver = "Fine Turno",
	Pilot_Disabled = "Disabilitato",
	Pilot_EnemyDead = "Ucciso",
	
	--Office
	Island_Office = "$1 Capo Ufficio",
	
	--Mission Texts
	Mission_Normal = "Minaccia Vek Identificata!",
	Mission_Easy = "Scudi Difensivi Attivi!",
	Mission_Hard = "Altra Minaccia Identificata!",
	Mission_Final = "Ultima Sfida",
	Mission_Failed = "Regione Distrutta dai Vek",
	Mission_None = "Nessun Vek Identificato",
	
	--Confirm Box
	Button_Confirm_No = "NO",
	Button_Confirm_Yes = "S�",
	Confirm_Question = "Continua?",
	Button_Confirm_Ok = "OK",
	
	-- Pilot News
	PilotNews_Dead = "DECEDUTO",
	PilotNews_Revived = "RIANIMATO",
	PilotNews_ReviveText = "Le Scorte Medicinali d'Emergenza hanno salvato $1 da morte certa!",
	PilotNews_Vek = "RIGENERATO",
	PilotNews_VekText = "$1 si � ripreso da morte certa! Lo sforzo richiesto � costato XP.",
	PilotNews_DeadText = "$1 � morto dopo aver preso danno nella battaglia contro le creature.",
	PilotNews_Promoted = "PROMOSSO",
	PilotNews_Skill = "Nuova Abilit� Sbloccata:",
	Button_Pilot_News_Done = "Capito",
	
	
	--Buttons
	Button_Continue = "CONTINUA",
	Button_Wait = "ASPETTA",
	Button_Create = "CREA",
	
	--Main Menu
	Button_Profile = "Crea Nuovo Profilo",
	Button_MainContinue = "Continua",
	Button_MainCredits = "Riconoscimenti",
	Button_MainNew = "Nuova Partita",
	Button_MainOptions = "Opzioni",
	Button_MainProgress = "Progresso",
	Button_MainStats = "Statistiche",
	Button_MainAchievs = "Achievements",
	Button_MainSquads = "Squadre",
	Button_MainQuit = "Esci",
	Button_MainProfile = "Profilo",
	Toggle_EnableTips = "Attiva Suggerimenti di Gioco",
	NewGame_Confirm = "Hai una partita in corso. Iniziarne una ora la canceller� definitivamente.",
	Delete_Confirm = "Perderai tutti i progressi e le cose sbloccate. Non pu� essere annullato.",
	Warning_NoSave = "'Into the Breach' non sembra avere accesso ai file per salvare i progressi. \n\nPer favore chiudi e controlla se il tuo Anti-Virus lo sta bloccando. \n\nSe il problema persiste mandaci una mail a contact@subsetgames.com",
	Warning_FileWriteIssue = "'Into the Breach' � incapace di salvare i progressi. \n\nPer favore chiudi e controlla se il tuo Anti-Virus lo sta bloccando. \n\nSe il problema persiste mandaci una mail a contact@subsetgames.com",
	Warning_SaveFileCorrupted = "Il tuo Salvataggio sembra essere corrotto. Per favore scrivici a contact@subsetgames.com se vorresti recuperare i tuoi dati.\nMolto dispiaciuti del problema!",
	Warning_ProfileCorrupted = "Il tuo Profilo sembra essere corrotto. Per favore scrivici a contact@subsetgames.com se vorresti recuperare i tuoi dati.\nMolto dispiaciuti del problema!",
	Menu_NoSave = "ATTENZIONE: C'� un problema di scrittura del file e i tuoi progressi non possono essere salvati.",
	Confirm_Header = "Conferma Azione",
	Warn_Header = "Attenzione!",
	Profile_Delete_Failed = "Il tuo Profilo non � stato cancellato completamente. Potrebbe essere di sola lettura, o potrebbe avere file extra nella cartella. Puoi cancellarlo manualmente da qua: \n\n",
	Profile_Delete_Failed_OSX = "Il tuo Profilo non � stato cancellato completamente. Questo � un problema noto in OS X. \n\nPuoi cancellarlo manualmente da qua: \n\n",
	
	
	Stats_Header = "Statistiche",
	Stats_TotalVictory = "Vittorie:",
	Stats_TotalLost = "Linee del Tempo perse:",
	Stats_TotalGames = "Partite Totali:",
	
	Stats_TotalTravelers = "Viaggiatori del Tempo Totali:",
	Stats_TotalKills = "Uccisioni Nemici Totali:",
	Stats_TotalSaved = "Totale Civili Salvati:",
	Stats_TotalIsland = "Totale Isole Protette:",
	Stats_TotalPods = "Capsule Recuperate:",
	
	Stats_ScoreDefeat = "Sconfitto",
	Stats_ScoreVictory = "$1 Vittoria Isola!",
	Stats_ScoreScore = "Civili Salvati:",
	Stats_ScoreKills = "Uccisioni Totali:",
	Stats_ScoreFailed = "Obbiettivi Falliti:",
	Stats_ScoreTimer = "Tempo di Gioco:",
	
	Stats_SquadGames = "Partite Totali:",
	Stats_SquadScore = "Punteggio Massimo:",
	Stats_SquadKills = "Uccisioni Totali:",
	
	Stats_PilotBattles = "Battaglie:",
	Stats_PilotJumps = "Salti Temporali:",
	Stats_PilotKills = "Uccisioni Totali:",
	Stats_Pilot_Deaths = "Morti Totali:",
	
	Stats_VekDeadliest = "Nemico pi� Mortale",
	Stats_VekDeadliestStat = "Mech Uccisi:",
	Stats_VekWeakest = "Il pi� debole",
	Stats_VekWeakestStat = "Uccisioni",
	Stats_VekDestruction = "Pi� Distruttivo",
	Stats_VekDestructionStat = "Danno Rete:",
	
	
	Stats_ListButton = "Indietro a Lista",
	Stats_SquadButton = "Cambia Squadra",
	Stats_PilotButton = "Cambia Pilota",
	Stats_Done = "Chiudi",
	
	Stats_ToggleGlobal = "Filtra per Squadra Selezionata",
	
	--Hangar
	Toggle_Easy = "Facile",
	Toggle_Hard = "Difficile",
	Toggle_Normal = "Normale",
	Hangar_None = "Nessuna",
	Hangar_CustomSquad = "Selezione finale:",
	Hangar_Traveler_Heading = "Viaggiatore del Tempo",
	Hangar_Island_Victory = "Le Medaglie sono conferite in base a quante Isole sono protette prima di completare l'Isola Finale.",
	Hangar_Island_Victory_2 = "Vittoria 2 Isole: $1",
	Hangar_Island_Victory_3 = "Vittoria 3 Isole: $1",
	Hangar_Island_Victory_4 = "Vittoria 4 Isole: $1",
	Hangar_Island_Victory_Title = "Medaglie Vittorie",
	Hangar_Ach_Coins = "Nota: Gli achievements ti fan guadagnare Monete per sbloccare nuove Squadre Mech!",
	Hangar_Locked = "Bloccato",
	Hangar_Randomized = "Squadra Random",
	Hangar_Custom = "Squadra Personalizzata",
	Hangar_Complete = "Completa pi� Isole per sbloccare!",
	Hangar_Achievements = "Guadagna pi� Monete!",
	Hangar_Buy = "Clicca per Acquistare!",
	Hangar_Buy_Gamepad = "Purchase now!",
	Button_Hangar_Squad = "Cambia Squadra",
	Button_Hangar_Pilot = "Cambia Viaggiatore del Tempo",
	Button_Hangar_Random_Pilot = "Randomizza ",
	Button_Hangar_Reroll = "Roll Bilanciato",
	Button_Hangar_RandomRoll = "Roll Caotico",
	Button_Hangar_Ach = "Guarda tutti gli Achievements",
	Button_Hangar_Secret = "Compra Squadra Segreta       ",
	Hangar_Total_Ach = "Monete Totali Guadagnate",
	Button_Hangar_Recustom = "Modifica Squadra",
	Hangar_Custom_Locked = "Sblocca la Squadra \"$1\" per usare questo Mech",
	Hangar_Custom_Locked_Title = "Mech Bloccato",
	Button_Hangar_Start = "Inizia Partita",
	Button_Hangar_Back = "Back",
	Hangar_Random = "Mech Casuale",
	Hangar_Select = "Selezione Squadra",
	Hangar_Achievements_Title = "Achievements",
	
	Ach_Squad = "Basato sulla Squadra",
	Ach_Global = "Globale",
	
	Hangar_Custom = "Personalizza Squadra",
	Hangar_Coins = "Guadagna Monete completando Achievements! Usale per sbloccare nuove Squadre!",
	Hangar_Pilot_Unlock = "Trova nuovi Piloti giocando per sbloccarli qua!",
	Hangar_Pilot = "Selezione Pilota",
	Hangar_Traveler = "Ultimo \nViaggiatore",
	Hangar_NoAbility = "Nessuna Abilit� Speciale",
	Hangar_NoTraveler = "Ultimo Pilota Non Disponibile",
	Randomized = "Crea una squadra casuale usando Mech sbloccati.",
	Customized = "Crea una squadra personale usando Mech sbloccati.",
	RandomizedLocked = "Sblocca pi� Mech per usare questa funzione!",
	No_Weapon = "Nessuna Arma",
	
	TipTitle_MechColor = "",
	TipText_MechColor = "Clicca per cambiare Colore Mech",
	TipTitle_MechName = "",
	TipText_MechName = "Clicca per rinominare Mech",
	TipTitle_PilotName = "",
	TipText_PilotName = "Clicca per Rinominare Pilota",
	TipTitle_PilotMech = "",
	TipText_PilotMech = "Clicca per cambiare il Mech iniziale per il Crononauta",
	TipTitle_HangarMovement = "Movimento",
	TipText_HangarMovement = "Quante caselle pu� muoversi questo Mech ogni turno.",
	TipTitle_HangarHealth = "Salute",
	TipText_HangarHealth = "Quanto danno pu� sopportare questo Mech prima di essere disabilitato",
	TipTitle_HangarClass = "Classe Mech",
	TipText_HangarClass = "La Classe Mech determina quali armi pu� usare senza una penalit� d'energia.",
	TipTitle_HangarFlying = "Volo",
	TipText_HangarFlying = "Le Unit� Volanti possono muovere su ogni tipo di casella.",
	TipTitle_HangarArmor = "Corazzato",
	TipText_HangarArmor = "Il danno a questa unit� � ridotto di 1. Tutti gli altri danni(Spinta, Blocco, Fuoco, etc.) non sono influenzati.",
	
	TipTitle_HangarNormal = "Normal Mode",
	TipText_HangarNormal = "Progettato per dare una sfida interessante a nuovi e vecchi giocatori.",
	TipTitle_HangarEasy = "Modalit� Facile",
	TipText_HangarEasy = "Ridotto la frequenza di spawn.\n\nIl punteggio � ridotto del 50%.",
	TipTitle_HangarHard = "Modalit� Difficile",
	TipText_HangarHard = "Aumenta la frequenza di Spawn e gli Alpha Vek.\n\nScore is increased by 50%.",
	
	
	TipText_LockedColor = "Sblocca la Squadra '$1' per usare questo colore",
	TipTitle_LockedColor = "Colore Bloccato",
	
	TipTitle_GenericColors = "Locked Colors",
	TipText_GenericColors = "Unlock additional Squads to unlock more color options",
	
	TipTitle_Repeat = "Ripeti Equipaggiamento Passivo",
	TipText_Repeat = "La tua Squadra Mech non pu� avere copie multiple dello stesso Equipaggiamento Passivo\n\nPuoi comunque giocare con la Squadra, ma le copie extra dell'Equipaggiamento saranno rimosse.",
	
	TipTitle_ChaosRoll = "Roll Caotico",
	TipText_ChaosRoll = "Squadre puramente casuali. Nessuna restrizione di Classe, armi o Mech.",
	
	TipTitle_BalancedRoll = "Roll Bilanciato",
	TipText_BalancedRoll = "Squadra random leggermente limitata.\n\nTutti i Mech saranno unici e non dalla stessa classe. I Mech avranno non pi� di 4 armi in tutto.",
	
	--Options
	Toggle_Fullscreen = "Schermo Intero",
	Toggle_Framelimit = "Limite di Frame",
	Toggle_Screenshake = "Disabilita l'Agitazione di Schermo",
	Toggle_Grid = "Coordinate Griglia",
	Toggle_Stretch = "Adatta Scaling",
	Toggle_Timer = "Timer di Gioco",
	Button_Options_Hotkeys = "Modifica Scorciatoie",
	Button_Options_Default = "Default Finestra",
	Button_Options_Scale = "Scala Massima Tabellone: $1",
	Toggle_Mute = "Muta Audio",
	Toggle_Colorblind = "Modalit� per Daltonici",
	Toggle_Large = "Caratteri pi� grandi",
	Toggle_Tips = "Suggerimenti",
	Abandon_Confirm = "Manderai un Pilota in una nuova linea del tempo e perderai tutti i progressi.",
	Escape_Title = "MENU",
	Escape_Info = "INFO",
	Escape_Sound = "Volume Effetti",
	Escape_Music = "Volume Musica",
	Escape_Speed = "Velocit� di Combattimento",
	Toggle_Confirm = "Conferma di Fine Turno",
	Escape_Gameplay = "Gioco",
	Escape_Video = "Audio + Video",
	Button_Escape_Menu = "MENU PRINCIPALE",
	Button_Escape_Exit_Editmode = "EDITOR MAPPA",
	Button_Escape_Exit_Editor = "CHIUDI EDITOR",
	Button_Escape_Options = "OPZIONI",
	Button_Escape_Ach = "ACHIEVEMENTS",
	Button_Escape_Quit = "SALVA e CHIUDI",
	Button_Escape_Abandon = "ABBANDONA TIMELINE",
	Button_Escape_Continue = "CONTINUA",
	
	Mouse_Middle = "Mouse Centrale",
	Mouse_X1 = "Mouse 4",
	Mouse_X2 = "Mouse 5",
	
	--Opening Sequence
	Opening_1 = "Umanit�: Distrutta      ",
	Opening_2 = "Minaccia Vek: Inarrestabile",
	Opening_3 = "Missione: Fallita              ",
	Opening_4 = "Apri una breccia.        ",
	Opening_5 = "Tempo di tornare indietro e riprovare.",
	
	--Game Over
	Button_Victory_Pilot = "MANDA PILOTA",
	Button_Victory_Quit = "MENU PRINCIPALE",
	Button_Victory_Done = "CONTINUA",
	
	--End of Island
	Button_Select_Mission_Leave = "ABBANDONA ISOLA",
	Button_Select_Mission_Store = "SPENDI REPUTAZIONE",
	Button_Select_Mission_Reward = "PREMIO REPUTAZIONE!",
	
	--Island Stuff
	Island_Environment = "AMBIENTE",
	Island_CEO = "CEO",
	Island_Vek = "VEK:",
	Island_Boss = "LEADER:",
	Island_Unlock = "Completa $1 $2 per sbloccare!",
	Island_Unlock_Single = "Isola",
	Island_Unlock_Mult = "Isole",
	Island_UnlockTitle = "Isola Bloccata",
	
	Island_UnlockTitle = "Isola Sbloccata!",
	Island_1 = "UNA Isola",
	Island_2 = "DUE Isole",
	Island_3 = "TRE Isole",
	Island_Text = "Completando $1 hai sbloccato \n\n\n\n\nNelle partite future, sarai in grado di visitare le Isole sbloccare in qualsiasi ordine.",
	Island_Squad = "Nuova Squadra disponibile all'inizio di una partita!",
	
	--Alerts
	Alert_Cleared = "ATTACCO ANNULLATO",
	Alert_Fire = "DANNO DA FUOCO",
	Alert_Elec = "DANNO ELETTRICO",
	Alert_Blocked = "NEMICO BLOCCATO",
	Alert_Attacking = "NON ATTACCA",
	Alert_PodDestroyed = "CAPSULA DISTRUTTA",
	Alert_PodSecured = "CAPSULA PROTETTA",
	Alert_Threat = "MINACCIATO",
	Alert_Healed = "UNITA' RIPARATA",
	Alert_BlobSpawn = "SPLIT SOPPRESSO",
	Alert_Regen = "RIGENERAZIONE PSION",
	Alert_Tentacle = "ATTACCO PSION",
	Alert_Action = "AZIONE DISPONIBILE",
	Alert_Level = "AUMENTO LIVELLO!",
	Alert_Warning = "ATTENZIONE!",
	Alert_Incoming = "CAPSULA IN ARRIVO",
	Alert_Passive = "BONUS PASSIVO",
	Alert_Resisted = "RESISTITO",
	Alert_Power = "ENERGIA PERSA",
	Alert_Casualties = "Perdite",
	Alert_Unused = "ENERGIA DISPONIBILE",
	Alert_NoWeapon = "NESSUNA ARMA ALIMENTATA",
	Alert_Open = "APRI PORTA",
	Alert_Pilot = "PILOTA DISPONIBILE",
	Alert_Lost = "REGIONE PERSA",
	Alert_Secured = "REGIONE PROTETTA",
	Alert_Cores = "NUCLEI DISPONIBILI",
	Alert_PilotCores = "PILOTI & ENERGIE DISPONIBILI",
	Alert_Overflow = "AUMENTO DIFESA!",
	Alert_FullOverflow = "RETE MASSIMA!",
	Alert_Smoke = "FUMO BLOCCANTE!",
	Alert_Water = "MECH SOMMERSO!",
	Alert_NoTarget = "NESSUN TARGET DISPONIBILE!",
	
	Status_Full = "Alcuni effetti non elencati per mancanza di spazio",
	
	SquadName_Filler = "Viaggiatori del Tempo",
	
	TipTitle_Archive_A = "Rift Walkers",
	TipText_Archive_A = "Sono stati i primi Mech a combattare contro i Mech. Sono affidabili ed efficienti.",
	
	TipTitle_Archive_B = "Steel Judoka",
	TipText_Archive_B = "Questi Mech sono specializzati nella manipolazione di posizione per mandare i Vek contro loro stessi",
	
	TipTitle_Rust_A = "Rusting Hulks",
	TipText_Rust_A = "La manipolazione del clima R.S.T. permette a questi Mech di usare tempeste di fumo ovunque.",
	
	TipTitle_Rust_B = "Flame Behemoths",
	TipText_Rust_B = "Invulnerabili al fuoco, questi Mech mirano a incenerire qualsiasi minaccia.",
	
	TipTitle_Pinnacle_A = "Zenith Guard",
	TipText_Pinnacle_A = "La tecnologia dei Raggi Detritus e quella degli Scudi Pinnacle creano una potente combinazione.",
	
	TipTitle_Pinnacle_B = "Frozen Titans",
	TipText_Pinnacle_B = "I Titans si affidano solamente al Lanciatore Cryo, una potente arma che richiede un Pilota esperto.",
	
	TipTitle_Detritus_A = "Blitzkrieg",
	TipText_Detritus_A = "Gli ingegneri R.S.T. hanno creato questa Squadra basandosi sulle capacit� distruttive dei fulmini.",
	
	TipTitle_Detritus_B = "Hazardous Mechs",
	TipText_Detritus_B = "Questi Mech hanno un danno molto alto ma si affidano a dei nanobot che mangiano le carcasse dei Vek per sopravvivere.",
	
	TipTitle_Random = "Squadra Casuale",
	TipText_Random = "Crea una Squadra casuale da tutti i Mech che hai sbloccato.",
	
	TipTitle_Custom = "Squadra Personalizzata",
	TipText_Custom = "Crea una Squadra Personale da tutti i Mech che hai sbloccato.",
	
	TipTitle_Secret = "Squadra Segreta",
	TipText_Secret = "L'ultima speranza dell'umanit� � una combinazione di Macchine e Vek creata per difendere la Terra.",
	
	---Achievements
	Achievement_Completed = "Completato a Difficolt� $1",
	Achievement_Header = "Achievement!",
	Achievement_Header_Pilot = "Pilota Trovato!",
	Achievement_Text_Pilot = "Sbloccato nell'Hangar",
	
	-----hotkeys
	Mute_Title = "Silenzia Volume",
	Mute_Description = "Disabilita tutti i suoni",
	
	Undo_Title = "Annulla Mossa",
	Undo_Description = "Annulla l'ultima mossa che hai fatto con un Mech",
	
	Reset_Title = "Resetta Turno",
	Reset_Description = "Se disponibile, riporta all'inizia del Turno Giocatore",
	
	SelectMech1_Title = "Seleziona Mech 1 ",
	SelectMech1_Description = "Seleziona il tuo primo Mech (basato sull'ordine della lista)",
	
	SelectMech2_Title = "Seleziona Mech 2",
	SelectMech2_Description = "Seleziona il tuo secondo Mech (basato sull'ordine della lista)",
	
	SelectMech3_Title = "Seleziona Mech 3",
	SelectMech3_Description = "Seleziona il tuo terzo Mech (basato sull'ordine della lista)",
	
	SelectDeploy1_Title = "Seleziona Rilascio 1",
	SelectDeploy1_Description = "Seleziona il primo Mech da rilasciare",
	
	SelectDeploy2_Title = "Seleziona Rilascio 2",
	SelectDeploy2_Description = "Seleziona il secondo Mech da rilasciare",
	
	SelectDeploy3_Title = "Seleziona Rilascio 3",
	SelectDeploy3_Description = "Seleziona il primo Mech da rilasciare",
	
	SelectMission1_Title = "Seleziona Missione Unit� 1",
	SelectMission1_Description = "Seleziona l'unit di missione che controlli in questo momento (se disponibile)",
	
	SelectMission2_Title = "Seleziona Unit Missione 2",
	SelectMission2_Description = "Seleziona la seconda unit di missione che controlli (se disponibile)",
	
	Cycle_Title = "Scorri unit",
	Cycle_Description = "Passa alla prossima unit attiva e controllata",
	
	Deselect_Title = "Deseleziona / Disarma Arma",
	Deselect_Title = "Deseleziona / Disarma Arma",
	Deselect_Description = "Resetta l'unit correntemente selezionata",
	
	Info_Title = "Finestra informazioni",
	Info_Description = "Scorri il mouse per ispezionare una qualsiasi unit sotto il tuo mouse",
	
	Overlay_Title = "Finestra Ordini d'Attacco",
	Overlay_Description = "Passa il mouse per vedere l'attuale ordine di attacco dei nemici",
	
	Weapon1_Title = "Arma 1",
	Weapon1_Description = "Arma o disarma la prima arma equipaggiata da un'unit",
	
	Weapon2_Title = "Arma 2",
	Weapon2_Description = "Arma o disarma la seconda arma equipaggiata da un'unit",
	
	Repair_Title = "Ripara",
	Repair_Description = "Attiva l'Abilit di Riparazione Mech (se disponibile)",
	
	EndTurn_Title = "Fine Turno",
	EndTurn_Description = "Finisci il tuo turno, o conferma l'ordine di rilascio",
	
	Fullscreen_Title = "Imposta Schermo Intero",
	Fullscreen_Description = "Imposta Schermo Intero",
	
	
	---------- CREDITS + VICTORY TEXT
	
	Credits_Studio = "Un gioco di:",
	Credits_StudioName = "SUBSET GAMES",
	Credits_Created = "Creato da:",
	Credits_CreatedName = "Justin Ma e Matthew Davis",
	Credits_Music = "Musica:",
	Credits_MusicName = "Ben Prunty",
	Credits_Sound = "Suono:",
	Credits_SoundName = "Power Up Audio",
	
	Credits_SoundSub1 = "Designer del Suono:",
	Credits_SoundSub1Name = "Joey Godard\nJeff Tangsoc\nKevin Regamey\nCole Verderber",
	
	Credits_SoundSub2 = "Libreria del Suono:",
	Credits_SoundSub2Name = "",

	Credits_Writing = "Testi:",
	Credits_WritingName = "Chris Avellone",
	Credits_Editing = "Editing Aggiuntivo:",
	Credits_EditingName = "Alison Waller",
	Credits_Community = "Gestione Community:",
	Credits_CommunityName = "Isla Schanuel",
	Credits_Portraits = "Concept Art Ritratti:",
	Credits_PortraitsName = "Polina Hristova",
	Credits_Mechs = "Concept Art Mech:",
	Credits_MechsName = "Gareth Davies",
	Credits_QA = "Testing Qualit :",
	Credits_QAName = "The Research Centaur UX+QA",
	
	Credits_QASub1 = "Test Manager:",
	Credits_QASub1Name = "Jay Fernandes",
	Credits_QASub2 = "Specialista QA:",
	Credits_QASub2Name = "Matthew Barnes\nLucia Aldana",
	
	Credits_Testers = "Grazie ai nostri fantastici tester:",
	Credits_TestersName = "5thHorseman\nAlfie275\nchewbacca77\nDarthcaboose\nDiscord\nFynn\nJoni\nKieve\nLem\nNick Patrick\nRick Edmonds\nSleeper Service\nVeritas\n",
	Credits_Thanks = "Un grazie speciale per i loro consigli e supporto:",
	Credits_ThanksName = "Maria\nAlison\nMichael Nielsen\nEstelle Tigani\nAllison Thrower\nBryan\nIlona Koleda\nEsther Oh",
	Credits_ThanksExtra = "e al resto della nostra famiglia, amici,\ne ai nostri amici sviluppatori indie",
	Credits_Babies = "Production Babies:",
	Credits_BabiesName = "Fox and Willow",
	Credits_FinalThanks = "Grazie per aver giocato!",
	
}

function GetText(id)
	if Global_Texts[id] ~= nil then
		return Global_Texts[id]
	end
	
	if Weapon_Texts[id] ~= nil then
		return Weapon_Texts[id]
	end
	
	if Achievement_Texts[id] ~= nil then
		return Achievement_Texts[id]
	end
	
	return "no string found"
end